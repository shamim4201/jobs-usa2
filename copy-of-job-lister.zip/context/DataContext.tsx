
import React, { createContext, useContext, useState, useEffect } from 'react';
import type { Job, User, Country, AppSettings, PaymentTransaction, UserAdRequest, UserNotification, JobComment, ChatMessage } from '../types';
import { api } from '../services/api';

interface DataContextType {
  jobs: Job[];
  users: User[];
  countries: Country[];
  settings: AppSettings;
  payments: PaymentTransaction[];
  adRequests: UserAdRequest[];
  notifications: UserNotification[];
  jobComments: JobComment[];
  chats: ChatMessage[]; // New
  isLoading: boolean;
  addJob: (job: Job) => Promise<void>;
  updateJob: (job: Job) => Promise<void>;
  deleteJob: (job: Job) => Promise<void>;
  addUser: (user: User) => Promise<void>;
  updateUser: (user: User) => Promise<void>;
  deleteUser: (user: User) => Promise<void>;
  addCountry: (country: Country) => Promise<void>;
  updateCountry: (country: Country) => Promise<void>;
  deleteCountry: (country: Country) => Promise<void>;
  updateSettings: (settings: AppSettings) => Promise<void>;
  addPayment: (payment: Omit<PaymentTransaction, 'id' | 'date' | 'status'>) => Promise<void>;
  updatePaymentStatus: (id: number, status: 'approved' | 'rejected') => Promise<void>;
  submitAdRequest: (adData: Omit<UserAdRequest, 'id' | 'submittedDate' | 'status'>) => Promise<void>;
  updateAdRequestStatus: (id: number, status: 'approved' | 'rejected') => Promise<void>;
  deleteAdRequest: (id: number) => Promise<void>;
  sendNotification: (data: Omit<UserNotification, 'id' | 'date' | 'isRead'>) => Promise<void>;
  deleteNotification: (id: number) => Promise<void>;
  addJobComment: (comment: Omit<JobComment, 'id' | 'date' | 'status'>) => Promise<void>;
  updateJobCommentStatus: (id: number, status: 'approved' | 'rejected') => Promise<void>;
  deleteJobComment: (id: number) => Promise<void>;
  sendChatMessage: (message: Omit<ChatMessage, 'id' | 'timestamp' | 'isRead'>) => Promise<void>; // New
  refreshData: () => Promise<void>;
  seedDatabase: () => Promise<void>; // Exposed seed function
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [countries, setCountries] = useState<Country[]>([]);
  const [settings, setSettings] = useState<AppSettings>({ googleAnalyticsId: '', siteTitle: 'Job Lister' });
  const [payments, setPayments] = useState<PaymentTransaction[]>([]);
  const [adRequests, setAdRequests] = useState<UserAdRequest[]>([]);
  const [notifications, setNotifications] = useState<UserNotification[]>([]);
  const [jobComments, setJobComments] = useState<JobComment[]>([]);
  const [chats, setChats] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const refreshData = async () => {
    try {
        const [fetchedJobs, fetchedUsers, fetchedCountries, fetchedSettings, fetchedPayments, fetchedAds, fetchedNotifs, fetchedComments, fetchedChats] = await Promise.all([
            api.getJobs(),
            api.getUsers(),
            api.getCountries(),
            api.getSettings(),
            api.getPayments(),
            api.getAdRequests(),
            api.getNotifications(),
            api.getJobComments(),
            api.getChatMessages()
        ]);
        setJobs(fetchedJobs);
        setUsers(fetchedUsers);
        setCountries(fetchedCountries);
        setSettings(fetchedSettings);
        setPayments(fetchedPayments);
        setAdRequests(fetchedAds);
        setNotifications(fetchedNotifs);
        setJobComments(fetchedComments);
        setChats(fetchedChats);
        
        // Push notification logic (Existing)
        const unreadNotifs = fetchedNotifs.filter(n => !n.isRead);
        if (unreadNotifs.length > 0 && Notification.permission === 'granted') {
             // Logic to show notifications
        }

    } catch (error) {
        console.error("Failed to fetch data:", error);
    }
  };

  useEffect(() => {
    const initData = async () => {
        setIsLoading(true);
        await refreshData();
        setIsLoading(false);
    };
    initData();
  }, []);

  // Listen for changes in other tabs to sync data instantly (Demo feature)
  useEffect(() => {
    const handleStorageChange = async (e: StorageEvent) => {
      if (['app_jobs', 'app_users', 'app_countries', 'app_settings', 'app_payments', 'app_ad_requests', 'app_notifications', 'app_job_comments', 'app_chats'].includes(e.key || '')) {
         await refreshData();
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  // Job Actions
  const addJob = async (job: Job) => {
    setIsLoading(true);
    const newJob = await api.addJob(job);
    setJobs(prev => [...prev, newJob]);
    
    await api.sendNotification({
        userId: 0,
        message: `New Job Posted: ${job.title}`,
        type: 'info',
        link: `/?page=job-details&jobId=${newJob.id}`
    });
    
    setIsLoading(false);
  };

  const updateJob = async (updatedJob: Job) => {
    setIsLoading(true);
    await api.updateJob(updatedJob);
    setJobs(prev => prev.map(job => (job.id === updatedJob.id ? updatedJob : job)));
    setIsLoading(false);
  };

  const deleteJob = async (jobToDelete: Job) => {
    setIsLoading(true);
    await api.deleteJob(jobToDelete.id);
    setJobs(prev => prev.filter(job => job.id !== jobToDelete.id));
    setIsLoading(false);
  };

  // User Actions
  const addUser = async (user: User) => {
    setIsLoading(true);
    const newUser = await api.addUser(user);
    setUsers(prev => [...prev, newUser]);
    setIsLoading(false);
  };

  const updateUser = async (updatedUser: User) => {
    setIsLoading(true);
    await api.updateUser(updatedUser);
    setUsers(prev => prev.map(user => (user.id === updatedUser.id ? updatedUser : user)));
    setIsLoading(false);
  };

  const deleteUser = async (userToDelete: User) => {
    setIsLoading(true);
    await api.deleteUser(userToDelete.id);
    setUsers(prev => prev.filter(user => user.id !== userToDelete.id));
    setIsLoading(false);
  };

  // Country Actions
  const addCountry = async (country: Country) => {
    setIsLoading(true);
    const newCountry = await api.addCountry(country);
    setCountries(prev => [...prev, newCountry]);
    setIsLoading(false);
  };

  const updateCountry = async (updatedCountry: Country) => {
    setIsLoading(true);
    await api.updateCountry(updatedCountry);
    setCountries(prev => prev.map(country => (country.id === updatedCountry.id ? updatedCountry : country)));
    setIsLoading(false);
  };

  const deleteCountry = async (countryToDelete: Country) => {
    setIsLoading(true);
    await api.deleteCountry(countryToDelete.id);
    setCountries(prev => prev.filter(country => country.id !== countryToDelete.id));
    setIsLoading(false);
  };

  // Settings Actions
  const updateSettings = async (newSettings: AppSettings) => {
    setIsLoading(true);
    const saved = await api.updateSettings(newSettings);
    setSettings(saved);
    setIsLoading(false);
  }

  // Payment Actions
  const addPayment = async (paymentData: Omit<PaymentTransaction, 'id' | 'date' | 'status'>) => {
      const newPayment = await api.addPayment(paymentData);
      setPayments(prev => [...prev, newPayment]);
      await refreshData();
  };

  const updatePaymentStatus = async (id: number, status: 'approved' | 'rejected') => {
      setIsLoading(true);
      await api.updatePaymentStatus(id, status);
      
      const payment = payments.find(p => p.id === id);
      if (payment && payment.userId) {
          await api.sendNotification({
              userId: payment.userId,
              message: `Your payment of ${payment.amount} has been ${status}.`,
              type: status === 'approved' ? 'success' : 'error'
          });
      }

      await refreshData();
      setIsLoading(false);
  };

  // Ad Request Actions
  const submitAdRequest = async (adData: Omit<UserAdRequest, 'id' | 'submittedDate' | 'status'>) => {
      const newAd = await api.submitAdRequest(adData);
      setAdRequests(prev => [...prev, newAd]);
      await refreshData();
  };

  const updateAdRequestStatus = async (id: number, status: 'approved' | 'rejected') => {
      setIsLoading(true);
      await api.updateAdRequestStatus(id, status);
      
      const request = adRequests.find(r => r.id === id);
      if (request) {
           await api.sendNotification({
              userId: request.userId,
              message: `Your ad request "${request.title}" has been ${status}.`,
              type: status === 'approved' ? 'success' : 'error'
          });
      }

      await refreshData();
      setIsLoading(false);
  };

  const deleteAdRequest = async (id: number) => {
      setIsLoading(true);
      await api.deleteAdRequest(id);
      await refreshData();
      setIsLoading(false);
  };

  // Notification Actions
  const sendNotification = async (data: Omit<UserNotification, 'id' | 'date' | 'isRead'>) => {
      setIsLoading(true);
      const newNotif = await api.sendNotification(data);
      setNotifications(prev => [...prev, newNotif]);
      setIsLoading(false);
  };

  const deleteNotification = async (id: number) => {
      setIsLoading(true);
      await api.deleteNotification(id);
      setNotifications(prev => prev.filter(n => n.id !== id));
      setIsLoading(false);
  };

  // Comment Actions
  const addJobComment = async (comment: Omit<JobComment, 'id' | 'date' | 'status'>) => {
      setIsLoading(true);
      // @ts-ignore
      const newComment = await api.addJobComment(comment);
      setJobComments(prev => [...prev, newComment]);
      setIsLoading(false);
  };

  const updateJobCommentStatus = async (id: number, status: 'approved' | 'rejected') => {
      setIsLoading(true);
      await api.updateJobCommentStatus(id, status);
      setJobComments(prev => prev.map(c => c.id === id ? { ...c, status } : c));
      setIsLoading(false);
  };

  const deleteJobComment = async (id: number) => {
      setIsLoading(true);
      await api.deleteJobComment(id);
      setJobComments(prev => prev.filter(c => c.id !== id));
      setIsLoading(false);
  };

  // Chat Actions
  const sendChatMessage = async (message: Omit<ChatMessage, 'id' | 'timestamp' | 'isRead'>) => {
      // Don't show loading for chat to keep it smooth, just optimistic update or wait for refresh
      const newMsg = await api.sendChatMessage(message);
      setChats(prev => [...prev, newMsg]);
  };

  const seedDatabase = async () => {
      setIsLoading(true);
      try {
          await api.seedDatabase();
          alert('Demo data uploaded successfully! The page will refresh.');
          await refreshData();
      } catch (e) {
          alert('Failed to seed database. Check if Firebase is connected correctly.');
          console.error(e);
      } finally {
          setIsLoading(false);
      }
  };

  return (
    <DataContext.Provider value={{
      jobs, users, countries, settings, payments, adRequests, notifications, jobComments, chats, isLoading,
      addJob, updateJob, deleteJob,
      addUser, updateUser, deleteUser,
      addCountry, updateCountry, deleteCountry,
      updateSettings,
      addPayment, updatePaymentStatus,
      submitAdRequest, updateAdRequestStatus, deleteAdRequest,
      sendNotification, deleteNotification,
      addJobComment, updateJobCommentStatus, deleteJobComment,
      sendChatMessage,
      refreshData,
      seedDatabase
    }}>
      {children}
    </DataContext.Provider>
  );
};
