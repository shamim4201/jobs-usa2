
import type { User } from '../types';

export const users: User[] = [
    { 
      id: 1, 
      name: 'Admin', 
      email: 'admin@example.com', 
      password: 'password', // Default password
      role: 'admin', 
      countryId: 1,
      joinedDate: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })
    },
];
