import type { Advertisement } from '../types';

export const advertisements: Advertisement[] = [];