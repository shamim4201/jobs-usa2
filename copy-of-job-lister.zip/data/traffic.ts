export interface TrafficData {
  country: string;
  flag: string; // Emoji flags
  visitors: number;
  percentage: number;
}

export const trafficData: TrafficData[] = [
  { country: 'United States', flag: '🇺🇸', visitors: 12542, percentage: 45 },
  { country: 'Canada', flag: '🇨🇦', visitors: 6890, percentage: 25 },
  { country: 'United Kingdom', flag: '🇬🇧', visitors: 3412, percentage: 12 },
  { country: 'Australia', flag: '🇦🇺', visitors: 2210, percentage: 8 },
  { country: 'Germany', flag: '🇩🇪', visitors: 1530, percentage: 5 },
  { country: 'Others', flag: '🌍', visitors: 1104, percentage: 5 },
];
