import type { Job } from '../types';

export const jobs: Job[] = [
  { id: 1, title: 'Dollar General CPL', description: 'Texas, Get your Dollar General job USA | 💵 JobsHiringNear', salary: '$40-125/hr', imageUrl: 'https://i.imgur.com/7bQ5b2S.png', company: 'Dollar General', applyUrl: '#', clicks: 1254 },
  { id: 2, title: 'Waste Management', description: 'Find your next job at Waste Management | 💵 OnlyGreatJobs', salary: '$10-90/hr', imageUrl: 'https://i.imgur.com/7bQ5b2S.png', company: 'Waste Management', applyUrl: '#', clicks: 832 },
  { id: 3, title: 'Driver Jobs', description: 'Sign up and start working as a driver USA | 💵 HigherIncomeJobs', salary: '$10-150/hr', imageUrl: 'https://i.imgur.com/7bQ5b2S.png', company: 'Logistics Inc.', applyUrl: '#', clicks: 2109 },
  { id: 4, title: 'FedEx Jobs', description: 'Message up and find FedEx jobs USA | 💵 StartACareerToday', salary: '$40/hr', imageUrl: 'https://i.imgur.com/7bQ5b2S.png', company: 'FedEx', applyUrl: '#', clicks: 1560 },
  { id: 5, title: 'Amazon From Home', description: 'Texas, Sign up and find Amazon jobs from home USA | 💵 HigherIncomeJobs', salary: '$30/hr', imageUrl: 'https://i.imgur.com/7bQ5b2S.png', company: 'Amazon', applyUrl: '#', clicks: 3480 },
  { id: 6, title: 'Apple Jobs', description: 'Start your day looking for Apple USA | 💵 StartACareerToday', salary: '$45-55/hr', imageUrl: 'https://i.imgur.com/7bQ5b2S.png', company: 'Apple', applyUrl: '#', clicks: 1982 },
  { id: 7, title: 'Cleaning Jobs', description: 'Find your next cleaning jobs USA | 💵 StartACareerToday', salary: '$18000', imageUrl: 'https://i.imgur.com/7bQ5b2S.png', company: 'Clean Co.', applyUrl: '#', clicks: 745 },
  { id: 8, title: 'Best Buy Jobs', description: 'Sign up for Best Buy USA | 💵 StartACareerToday', salary: '$50/hr', imageUrl: 'https://i.imgur.com/7bQ5b2S.png', company: 'Best Buy', applyUrl: '#', clicks: 1123 },
  { id: 9, title: 'Remote Data Entry', description: 'Flexible work from home opportunities.', salary: '$25-35/hr', imageUrl: 'https://i.imgur.com/7bQ5b2S.png', company: 'DataEntry Solutions', applyUrl: '#', clicks: 4201 },
  { id: 10, title: 'Customer Service Rep', description: 'Assist customers with inquiries and issues.', salary: '$18-22/hr', imageUrl: 'https://i.imgur.com/7bQ5b2S.png', company: 'Support Services Ltd.', applyUrl: '#', clicks: 956 },
];