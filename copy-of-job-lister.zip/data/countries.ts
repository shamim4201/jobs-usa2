import type { Country } from '../types';

export const countries: Country[] = [
  { id: 1, name: 'United States', flag: '🇺🇸' },
  { id: 2, name: 'Canada', flag: '🇨🇦' },
  { id: 3, name: 'United Kingdom', flag: '🇬🇧' },
  { id: 4, name: 'Australia', flag: '🇦🇺' },
  { id: 5, name: 'Germany', flag: '🇩🇪' },
  { id: 6, name: 'France', flag: '🇫🇷' },
  { id: 7, name: 'Japan', flag: '🇯🇵' },
  { id: 8, name: 'India', flag: '🇮🇳' },
  { id: 9, name: 'Brazil', flag: '🇧🇷' },
  { id: 10, name: 'South Africa', flag: '🇿🇦' },
];