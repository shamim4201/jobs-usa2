import type { AdCompany } from '../types';

export const adCompanies: AdCompany[] = [];