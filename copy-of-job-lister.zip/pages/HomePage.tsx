
import React from 'react';
import { useData } from '../context/DataContext';
import type { Job, Page, User } from '../types';
import LoadingSpinner from '../components/LoadingSpinner';
import AdBanner from '../components/AdBanner';
import SiteLogo from '../components/SiteLogo';
import PricingPlans from '../components/PricingPlans';

interface HomePageProps {
    onNavigate: (page: Page) => void;
    onJobClick: (id: number) => void;
    user: User | null;
}

const JobGridItem: React.FC<{ job: Job; onClick: () => void }> = ({ job, onClick }) => (
  <div 
    onClick={onClick}
    className="bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-lg flex flex-col cursor-pointer hover:bg-white transition-colors border border-white/50"
  >
    {/* Image Container */}
    <div className="bg-white h-32 mb-3 rounded-md flex items-center justify-center flex-shrink-0 p-2 border border-gray-100">
        <img src={job.imageUrl} alt={job.title} className="w-full h-full object-contain" />
    </div>
    <div className="flex-grow text-center">
        <h3 className="font-bold truncate text-sm text-gray-900">{job.title}</h3>
        <p className="text-xs text-blue-600 font-semibold truncate">{job.company}</p>
        <p className="text-xs text-red-600 font-bold mt-1 bg-red-50 border border-red-100 inline-block px-2 py-0.5 rounded">{job.salary}</p>
    </div>
  </div>
);

const HomePage: React.FC<HomePageProps> = ({ onNavigate, onJobClick, user }) => {
  const { jobs, isLoading, settings } = useData();
  
  // Filter jobs explicitly marked for Home
  let featuredJobs = jobs.filter(j => j.showOnHome).reverse();

  // Fallback: If no jobs are marked, show latest 8
  if (featuredJobs.length === 0) {
      featuredJobs = [...jobs].reverse().slice(0, 8);
  }
  
  // Split jobs for middle ad placement (4 jobs then ad then remaining)
  const firstBatch = featuredJobs.slice(0, 4);
  const secondBatch = featuredJobs.slice(4); // Show remaining chosen jobs

  return (
    <div className="min-h-screen p-4 bg-transparent">
      <header className="text-center mb-6 flex flex-col items-center">
        {/* Logo Replacement */}
        <div className="mb-2 flex flex-col items-center">
            <SiteLogo className="h-16 w-auto drop-shadow-sm" />
            <h2 className="text-red-600 text-xl font-bold mt-2">Best Job</h2>
        </div>
        
        {/* Top Ad Banner */}
        {settings.homeTopAdCode && (
            <div className="mt-4 w-full">
                <AdBanner code={settings.homeTopAdCode} />
            </div>
        )}
      </header>
      <main>
        {isLoading ? (
            <LoadingSpinner />
        ) : (
            <>
                {/* First 4 Jobs */}
                <div className="grid grid-cols-2 gap-4">
                  {firstBatch.map(job => (
                    <JobGridItem key={job.id} job={job} onClick={() => onJobClick(job.id)} />
                  ))}
                </div>

                {/* Middle Ad Banner */}
                {settings.homeMiddleAdCode && (
                    <div className="my-6">
                        <AdBanner code={settings.homeMiddleAdCode} />
                    </div>
                )}

                {/* Remaining Jobs */}
                {secondBatch.length > 0 && (
                     <div className="grid grid-cols-2 gap-4 mt-4">
                        {secondBatch.map(job => (
                            <JobGridItem key={job.id} job={job} onClick={() => onJobClick(job.id)} />
                        ))}
                     </div>
                )}

                {featuredJobs.length === 0 && <p className="text-gray-600 text-center mt-10 bg-white/50 p-4 rounded-lg">No jobs available.</p>}
                
                {/* Bottom Ad Banner */}
                {settings.homeBottomAdCode && (
                    <div className="my-6">
                        <AdBanner code={settings.homeBottomAdCode} />
                    </div>
                )}

                <div className="text-center mt-8">
                    <button 
                        onClick={() => onNavigate('jobs')}
                        className="bg-yellow-400 text-slate-900 font-bold py-2 px-6 rounded-md hover:bg-yellow-500 transition-colors shadow-md"
                    >
                        More Jobs
                    </button>
                </div>

                {/* Pricing & FAQ Section displayed directly on Home Page */}
                <PricingPlans user={user} onNavigate={onNavigate} />
            </>
        )}
      </main>
    </div>
  );
};

export default HomePage;