
import React, { useState } from 'react';
import type { User, Country } from '../types';
import UserFormModal from '../components/admin/UserFormModal';
import DeleteConfirmationModal from '../components/admin/DeleteConfirmationModal';
import UserDetailsModal from '../components/admin/UserDetailsModal';

interface UserManagementPageProps {
  users: User[];
  countries: Country[];
  onSave: (user: User) => void;
  onDelete: (user: User) => void;
}

const UserManagementPage: React.FC<UserManagementPageProps> = ({ users, countries, onSave, onDelete }) => {
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [viewingUser, setViewingUser] = useState<User | null>(null);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);

  const handleOpenAddModal = () => {
    setEditingUser(null);
    setIsFormModalOpen(true);
  };

  const handleEdit = (user: User) => {
    setEditingUser(user);
    setIsFormModalOpen(true);
  };

  const handleView = (user: User) => {
    setViewingUser(user);
    setIsDetailsModalOpen(true);
  };

  const handleOpenDeleteModal = (user: User) => {
    setUserToDelete(user);
  };

  const handleConfirmDelete = () => {
    if (userToDelete) {
      onDelete(userToDelete);
      setUserToDelete(null);
    }
  };

  const handleCloseModal = () => {
    setIsFormModalOpen(false);
    setEditingUser(null);
  };

  const handleCloseDetailsModal = () => {
    setIsDetailsModalOpen(false);
    setViewingUser(null);
  };

  const handleSaveUser = (userData: User) => {
    onSave(userData);
    handleCloseModal();
  };
  
  const getCountryName = (countryId: number) => {
      return countries.find(c => c.id === countryId)?.name || 'N/A';
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-semibold text-gray-800">User Management</h1>
        <button
          onClick={handleOpenAddModal}
          className="bg-purple-500 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-600 transition-colors"
        >
          Add New User
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-gray-100 border-b">
              <th className="p-4 font-semibold">Name</th>
              <th className="p-4 font-semibold">Email</th>
              <th className="p-4 font-semibold">Type</th>
              <th className="p-4 font-semibold">Country</th>
              <th className="p-4 font-semibold">Role</th>
              <th className="p-4 font-semibold text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map(user => (
              <tr key={user.id} className="border-b hover:bg-gray-50 transition-colors">
                <td className="p-4 font-medium">{user.name}</td>
                <td className="p-4 text-gray-600">{user.email}</td>
                <td className="p-4">
                    {user.accountType === 'employer' ? (
                        <span className="bg-purple-100 text-purple-700 text-xs px-2 py-1 rounded font-bold">Employer</span>
                    ) : (
                        <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded font-bold">Seeker</span>
                    )}
                </td>
                <td className="p-4">{getCountryName(user.countryId)}</td>
                <td className="p-4 capitalize">
                  <span className={`px-2 py-1 rounded text-xs font-semibold ${user.role === 'admin' ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'}`}>
                    {user.role}
                  </span>
                </td>
                <td className="p-4 text-center">
                  <div className="flex justify-center items-center space-x-3">
                    <button 
                      onClick={() => handleView(user)} 
                      className="text-gray-500 hover:text-purple-600 transition-colors p-1"
                      title="View Details"
                    >
                      <i className="mdi mdi-eye text-xl"></i>
                    </button>
                    <button 
                      onClick={() => handleEdit(user)} 
                      className="text-gray-500 hover:text-blue-600 transition-colors p-1"
                      title="Edit"
                    >
                      <i className="mdi mdi-pencil text-xl"></i>
                    </button>
                    <button 
                      onClick={() => handleOpenDeleteModal(user)} 
                      className="text-gray-500 hover:text-red-600 transition-colors p-1"
                      title="Delete"
                    >
                      <i className="mdi mdi-delete text-xl"></i>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {/* Add/Edit Modal */}
      {isFormModalOpen && (
        <UserFormModal
          user={editingUser}
          countries={countries}
          isOpen={isFormModalOpen}
          onClose={handleCloseModal}
          onSave={handleSaveUser}
        />
      )}
      
      {/* View Details Modal */}
      {viewingUser && (
        <UserDetailsModal
            user={viewingUser}
            countries={countries}
            isOpen={isDetailsModalOpen}
            onClose={handleCloseDetailsModal}
        />
      )}

      {/* Delete Confirmation Modal */}
      {userToDelete && (
        <DeleteConfirmationModal
            isOpen={!!userToDelete}
            onClose={() => setUserToDelete(null)}
            onConfirm={handleConfirmDelete}
            title="Confirm User Deletion"
            message={`Are you sure you want to delete the user: "${userToDelete.name}"? This action cannot be undone.`}
        />
      )}
    </div>
  );
};

export default UserManagementPage;
