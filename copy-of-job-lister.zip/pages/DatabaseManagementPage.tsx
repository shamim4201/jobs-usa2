
import React, { useState, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { isFirebaseConfigured, validateFirebaseConfig } from '../services/api';

const DatabaseManagementPage: React.FC = () => {
  const { settings, updateSettings, isLoading, seedDatabase } = useData();
  
  // Firebase States
  const [enableFirebase, setEnableFirebase] = useState(false);
  const [firebaseApiKey, setFirebaseApiKey] = useState('');
  const [firebaseAuthDomain, setFirebaseAuthDomain] = useState('');
  const [firebaseProjectId, setFirebaseProjectId] = useState('');
  const [firebaseStorageBucket, setFirebaseStorageBucket] = useState('');
  const [firebaseMessagingSenderId, setFirebaseMessagingSenderId] = useState('');
  const [firebaseAppId, setFirebaseAppId] = useState('');

  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [testStatus, setTestStatus] = useState<'idle' | 'testing' | 'success' | 'failed'>('idle');
  const [testMsg, setTestMsg] = useState('');
  
  const isHardcoded = isFirebaseConfigured();

  useEffect(() => {
      if(settings) {
          setEnableFirebase(settings.enableFirebase || false);
          setFirebaseApiKey(settings.firebaseApiKey || '');
          setFirebaseAuthDomain(settings.firebaseAuthDomain || '');
          setFirebaseProjectId(settings.firebaseProjectId || '');
          setFirebaseStorageBucket(settings.firebaseStorageBucket || '');
          setFirebaseMessagingSenderId(settings.firebaseMessagingSenderId || '');
          setFirebaseAppId(settings.firebaseAppId || '');
      }
  }, [settings]);

  const handleTestConnection = async () => {
      setTestStatus('testing');
      setTestMsg('');
      setError(null);

      // Validate required fields locally first
      if (!firebaseApiKey.trim() || !firebaseProjectId.trim()) {
          setTestStatus('failed');
          setTestMsg('Error: API Key and Project ID are required.');
          return;
      }

      const config = {
          apiKey: firebaseApiKey.trim(),
          authDomain: firebaseAuthDomain.trim(),
          projectId: firebaseProjectId.trim(),
          storageBucket: firebaseStorageBucket.trim(),
          messagingSenderId: firebaseMessagingSenderId.trim(),
          appId: firebaseAppId.trim(),
      };

      try {
          await validateFirebaseConfig(config);
          setTestStatus('success');
          setTestMsg('Connection Successful!');
      } catch (err: any) {
          setTestStatus('failed');
          setTestMsg(`Connection Failed: ${err.message || 'Unknown error'}`);
      }
  };

  const handleSave = async (e: React.FormEvent) => {
      e.preventDefault();
      setError(null);

      // Validation: If enabling, ensure API Key and Project ID are present
      if (enableFirebase) {
          if (!firebaseApiKey.trim() || !firebaseProjectId.trim()) {
              setError("API Key and Project ID are required to enable Firebase.");
              return;
          }
      }

      await updateSettings({
          ...settings,
          enableFirebase,
          firebaseApiKey: firebaseApiKey.trim(),
          firebaseAuthDomain: firebaseAuthDomain.trim(),
          firebaseProjectId: firebaseProjectId.trim(),
          firebaseStorageBucket: firebaseStorageBucket.trim(),
          firebaseMessagingSenderId: firebaseMessagingSenderId.trim(),
          firebaseAppId: firebaseAppId.trim(),
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
      
      // Reload page to re-initialize API with new settings
      if(window.confirm("Settings saved. The page needs to reload to apply database changes. Reload now?")) {
          window.location.reload();
      }
  };

  const handleSeed = async () => {
      if (!window.confirm("Are you sure? This will upload demo data (Jobs, Users, etc.) to your Firebase database. Existing data with same IDs might be overwritten.")) {
          return;
      }
      await seedDatabase();
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h1 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
          <i className="mdi mdi-database mr-2 text-purple-600"></i>
          Database Management
      </h1>

      {isHardcoded && (
          <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded shadow-sm">
              <p className="font-bold">✅ Live Mode Active</p>
              <p className="text-sm">Firebase is configured directly in the code (Hardcoded). You don't need to change settings here.</p>
          </div>
      )}

      {/* Initialize Database Section */}
      <div className="mb-8 bg-blue-50 p-6 rounded-lg border border-blue-200">
          <h2 className="text-lg font-bold text-blue-800 mb-2">Initialize Database</h2>
          <p className="text-sm text-blue-600 mb-4">
              If your Firebase database is empty (showing no jobs/users), click the button below to upload demo data.
          </p>
          <button 
              onClick={handleSeed}
              disabled={isLoading || !enableFirebase && !isHardcoded}
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded shadow-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
              {isLoading ? 'Uploading...' : 'Upload Demo Data'}
          </button>
      </div>

      <form onSubmit={handleSave} className="border-t pt-6">
          <h2 className="text-lg font-bold text-gray-700 mb-4">Firebase Configuration</h2>
          
          {error && <p className="bg-red-100 text-red-700 p-3 rounded mb-4 border border-red-200">{error}</p>}

          <div className="mb-4">
              <label className="flex items-center cursor-pointer">
                  <input 
                      type="checkbox" 
                      checked={enableFirebase} 
                      onChange={(e) => setEnableFirebase(e.target.checked)}
                      className="form-checkbox h-5 w-5 text-purple-600 rounded focus:ring-purple-500"
                  />
                  <span className="ml-2 text-gray-800 font-bold">Enable Realtime Database (Firebase)</span>
              </label>
              <p className="text-xs text-gray-500 mt-1 ml-7">
                  Enable this to sync data across all devices. If disabled, data is stored locally on your device only.
              </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="mb-4">
                  <label className="block text-gray-700 text-xs font-bold mb-1">API Key (Required)</label>
                  <input 
                      type="text" 
                      value={firebaseApiKey} 
                      onChange={(e) => setFirebaseApiKey(e.target.value)} 
                      className="w-full border rounded px-3 py-2 text-sm focus:outline-none focus:border-purple-500"
                      placeholder="AIzaSy..."
                  />
              </div>
              <div className="mb-4">
                  <label className="block text-gray-700 text-xs font-bold mb-1">Auth Domain</label>
                  <input 
                      type="text" 
                      value={firebaseAuthDomain} 
                      onChange={(e) => setFirebaseAuthDomain(e.target.value)} 
                      className="w-full border rounded px-3 py-2 text-sm focus:outline-none focus:border-purple-500"
                      placeholder="project-id.firebaseapp.com"
                  />
              </div>
              <div className="mb-4">
                  <label className="block text-gray-700 text-xs font-bold mb-1">Project ID (Required)</label>
                  <input 
                      type="text" 
                      value={firebaseProjectId} 
                      onChange={(e) => setFirebaseProjectId(e.target.value)} 
                      className="w-full border rounded px-3 py-2 text-sm focus:outline-none focus:border-purple-500"
                      placeholder="project-id"
                  />
              </div>
              <div className="mb-4">
                  <label className="block text-gray-700 text-xs font-bold mb-1">Storage Bucket</label>
                  <input 
                      type="text" 
                      value={firebaseStorageBucket} 
                      onChange={(e) => setFirebaseStorageBucket(e.target.value)} 
                      className="w-full border rounded px-3 py-2 text-sm focus:outline-none focus:border-purple-500"
                      placeholder="project-id.appspot.com"
                  />
              </div>
              <div className="mb-4">
                  <label className="block text-gray-700 text-xs font-bold mb-1">Messaging Sender ID</label>
                  <input 
                      type="text" 
                      value={firebaseMessagingSenderId} 
                      onChange={(e) => setFirebaseMessagingSenderId(e.target.value)} 
                      className="w-full border rounded px-3 py-2 text-sm focus:outline-none focus:border-purple-500"
                  />
              </div>
              <div className="mb-4">
                  <label className="block text-gray-700 text-xs font-bold mb-1">App ID</label>
                  <input 
                      type="text" 
                      value={firebaseAppId} 
                      onChange={(e) => setFirebaseAppId(e.target.value)} 
                      className="w-full border rounded px-3 py-2 text-sm focus:outline-none focus:border-purple-500"
                  />
              </div>
          </div>

          <div className="flex items-center justify-between mt-6">
              {/* Test Connection Section */}
              <div className="flex items-center gap-3">
                  <button 
                      type="button"
                      onClick={handleTestConnection}
                      disabled={testStatus === 'testing'}
                      className="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded shadow-md transition-colors disabled:opacity-50 text-sm"
                  >
                      {testStatus === 'testing' ? 'Checking...' : 'Test Connection'}
                  </button>
                  {testStatus === 'success' && <span className="text-green-600 font-bold text-sm">✅ {testMsg}</span>}
                  {testStatus === 'failed' && <span className="text-red-600 font-bold text-sm">❌ {testMsg}</span>}
              </div>

              <div className="flex items-center">
                  {saved && <span className="text-green-600 font-bold mr-4 text-sm animate-pulse flex items-center">Settings Saved!</span>}
                  <button 
                      type="submit" 
                      disabled={isLoading}
                      className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-6 rounded shadow-md transition-colors disabled:opacity-50"
                  >
                      {isLoading ? 'Saving...' : 'Save & Reload'}
                  </button>
              </div>
          </div>
      </form>
    </div>
  );
};

export default DatabaseManagementPage;
