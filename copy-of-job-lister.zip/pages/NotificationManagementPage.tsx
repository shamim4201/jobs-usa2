


import React, { useState } from 'react';
import { useData } from '../context/DataContext';

const NotificationManagementPage: React.FC = () => {
    const { users, jobs, notifications, sendNotification, deleteNotification } = useData();
    const [recipientId, setRecipientId] = useState<number>(0); // 0 = All Users
    const [message, setMessage] = useState('');
    const [type, setType] = useState<'info' | 'success' | 'warning' | 'error'>('info');
    const [selectedJobId, setSelectedJobId] = useState<string>(''); // For job attachment
    const [isSending, setIsSending] = useState(false);

    // Filter notifications for display (sorted by date)
    const sortedNotifications = [...notifications].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    const handleSend = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSending(true);

        // Construct Link if a job is selected
        let link = undefined;
        if (selectedJobId) {
            link = `/?page=job-details&jobId=${selectedJobId}`;
        }

        await sendNotification({
            userId: recipientId,
            message: message,
            type: type,
            link: link
        });

        setMessage('');
        setSelectedJobId('');
        setIsSending(false);
        alert('Notification Sent!');
    };

    const handleDelete = async (id: number) => {
        if(window.confirm('Are you sure you want to delete this notification?')) {
            await deleteNotification(id);
        }
    };

    const getUserName = (id: number) => {
        if (id === 0) return 'All Users (সবাই)';
        const user = users.find(u => u.id === id);
        return user ? user.name : 'Unknown User';
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-lg">
             <h1 className="text-2xl font-semibold text-gray-800 mb-6 flex items-center">
                <i className="mdi mdi-bell-ring-outline mr-2 text-blue-600"></i>
                Notification Management (নোটিফিকেশন)
            </h1>

            {/* Send Notification Form */}
            <div className="bg-blue-50 p-6 rounded-lg border border-blue-100 mb-8">
                <h2 className="text-lg font-bold text-gray-800 mb-4">Send New Notification (নতুন মেসেজ পাঠান)</h2>
                <form onSubmit={handleSend}>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                            <label className="block text-gray-700 text-sm font-bold mb-2">Recipient (প্রাপক)</label>
                            <select 
                                value={recipientId}
                                onChange={(e) => setRecipientId(parseInt(e.target.value))}
                                className="w-full border rounded px-3 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                                <option value={0}>All Users (সবাই)</option>
                                {users.map(user => (
                                    <option key={user.id} value={user.id}>{user.name} ({user.email})</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label className="block text-gray-700 text-sm font-bold mb-2">Type (ধরণ)</label>
                            <select 
                                value={type}
                                onChange={(e) => setType(e.target.value as any)}
                                className="w-full border rounded px-3 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                                <option value="info">Info (নীল)</option>
                                <option value="success">Success (সবুজ)</option>
                                <option value="warning">Warning (হলুদ)</option>
                                <option value="error">Error (লাল)</option>
                            </select>
                        </div>
                    </div>

                    <div className="mb-4">
                        <label className="block text-gray-700 text-sm font-bold mb-2">Attach Job (জব লিংক যুক্ত করুন - ঐচ্ছিক)</label>
                        <select 
                            value={selectedJobId}
                            onChange={(e) => {
                                setSelectedJobId(e.target.value);
                                // Optional: Auto-fill message if empty
                                if (!message && e.target.value) {
                                    const job = jobs.find(j => j.id.toString() === e.target.value);
                                    if(job) setMessage(`New Job Opportunity: ${job.title} at ${job.company}`);
                                }
                            }}
                            className="w-full border rounded px-3 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                            <option value="">-- No Job Attached --</option>
                            {jobs.map(job => (
                                <option key={job.id} value={job.id}>
                                    {job.title} - {job.company}
                                </option>
                            ))}
                        </select>
                        <p className="text-xs text-gray-500 mt-1">
                            Selecting a job will make the notification clickable. It will take the user directly to the job details.
                        </p>
                    </div>

                    <div className="mb-4">
                        <label className="block text-gray-700 text-sm font-bold mb-2">Message (মেসেজ)</label>
                        <textarea
                            value={message}
                            onChange={(e) => setMessage(e.target.value)}
                            required
                            rows={3}
                            className="w-full border rounded px-3 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Write your message here..."
                        />
                    </div>

                    <div className="flex justify-end">
                        <button 
                            type="submit"
                            disabled={isSending}
                            className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded shadow-md transition-colors disabled:opacity-50"
                        >
                            {isSending ? 'Sending...' : 'Send Notification'}
                        </button>
                    </div>
                </form>
            </div>

            {/* Notification History */}
            <div>
                <h2 className="text-lg font-bold text-gray-800 mb-4">Sent History (মেসেজ হিস্ট্রি)</h2>
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead>
                            <tr className="bg-gray-100 border-b">
                                <th className="p-3 font-semibold text-sm">Date</th>
                                <th className="p-3 font-semibold text-sm">Recipient</th>
                                <th className="p-3 font-semibold text-sm">Message</th>
                                <th className="p-3 font-semibold text-sm">Attached Link</th>
                                <th className="p-3 font-semibold text-sm">Type</th>
                                <th className="p-3 font-semibold text-sm text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {sortedNotifications.length === 0 ? (
                                <tr>
                                    <td colSpan={6} className="p-8 text-center text-gray-400">
                                        No notifications sent yet.
                                    </td>
                                </tr>
                            ) : (
                                sortedNotifications.map(notif => (
                                    <tr key={notif.id} className="border-b hover:bg-gray-50 transition-colors">
                                        <td className="p-3 text-xs text-gray-500 whitespace-nowrap">{notif.date}</td>
                                        <td className="p-3 font-medium text-gray-800 text-sm">{getUserName(notif.userId)}</td>
                                        <td className="p-3 text-sm text-gray-600 max-w-md truncate">{notif.message}</td>
                                        <td className="p-3 text-xs">
                                            {notif.link ? (
                                                <span className="text-blue-600 bg-blue-50 px-2 py-1 rounded">Job Linked</span>
                                            ) : (
                                                <span className="text-gray-400">-</span>
                                            )}
                                        </td>
                                        <td className="p-3">
                                            <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${
                                                notif.type === 'success' ? 'bg-green-100 text-green-700' :
                                                notif.type === 'error' ? 'bg-red-100 text-red-700' :
                                                notif.type === 'warning' ? 'bg-yellow-100 text-yellow-700' :
                                                'bg-blue-100 text-blue-700'
                                            }`}>
                                                {notif.type}
                                            </span>
                                        </td>
                                        <td className="p-3 text-center">
                                            <button 
                                                onClick={() => handleDelete(notif.id)}
                                                className="text-red-500 hover:text-red-700 p-1 hover:bg-red-50 rounded"
                                                title="Delete"
                                            >
                                                <i className="mdi mdi-delete text-xl"></i>
                                            </button>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default NotificationManagementPage;