import React, { useState } from 'react';
import type { Job } from '../types';
import EditJobModal from '../components/admin/EditJobModal';
import DeleteConfirmationModal from '../components/admin/DeleteConfirmationModal';

interface JobManagementPageProps {
  jobs: Job[];
  onSave: (job: Job) => void;
  onDelete: (job: Job) => void;
}

const JobManagementPage: React.FC<JobManagementPageProps> = ({ jobs, onSave, onDelete }) => {
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingJob, setEditingJob] = useState<Job | null>(null);
  const [jobToDelete, setJobToDelete] = useState<Job | null>(null);

  const handleOpenAddModal = () => {
    setEditingJob(null);
    setIsEditModalOpen(true);
  };

  const handleEdit = (job: Job) => {
    setEditingJob(job);
    setIsEditModalOpen(true);
  };

  const handleOpenDeleteModal = (job: Job) => {
    setJobToDelete(job);
  };

  const handleConfirmDelete = () => {
    if (jobToDelete) {
      onDelete(jobToDelete);
      setJobToDelete(null);
    }
  };

  const handleCloseEditModal = () => {
    setIsEditModalOpen(false);
    setEditingJob(null);
  };

  const handleSaveJob = (updatedJob: Job) => {
    onSave(updatedJob);
    handleCloseEditModal();
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-semibold text-gray-800">Job Management</h1>
        <button 
          onClick={handleOpenAddModal}
          className="bg-purple-500 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-600 transition-colors"
        >
            Add New Job
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-gray-100 border-b">
              <th className="p-4 font-semibold">Image</th>
              <th className="p-4 font-semibold">Title</th>
              <th className="p-4 font-semibold">Company</th>
              <th className="p-4 font-semibold">Salary</th>
              <th className="p-4 font-semibold">Clicks</th>
              <th className="p-4 font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            {jobs.map(job => (
              <tr key={job.id} className="border-b hover:bg-gray-50">
                <td className="p-4">
                  <img src={job.imageUrl} alt={job.title} className="w-10 h-10 object-contain rounded" />
                </td>
                <td className="p-4">{job.title}</td>
                <td className="p-4">{job.company}</td>
                <td className="p-4">{job.salary}</td>
                <td className="p-4">{job.clicks.toLocaleString()}</td>
                <td className="p-4">
                  <button onClick={() => handleEdit(job)} className="text-blue-500 hover:underline mr-4">Edit</button>
                  <button onClick={() => handleOpenDeleteModal(job)} className="text-red-500 hover:underline">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {isEditModalOpen && (
        <EditJobModal
          job={editingJob}
          isOpen={isEditModalOpen}
          onClose={handleCloseEditModal}
          onSave={handleSaveJob}
        />
      )}
      {jobToDelete && (
        <DeleteConfirmationModal
            isOpen={!!jobToDelete}
            onClose={() => setJobToDelete(null)}
            onConfirm={handleConfirmDelete}
            title="Confirm Job Deletion"
            message={`Are you sure you want to delete the job: "${jobToDelete.title}"? This action cannot be undone.`}
        />
      )}
    </div>
  );
};

export default JobManagementPage;