
import React, { useState, useEffect } from 'react';
import { useData } from '../context/DataContext';

const SettingsPage: React.FC = () => {
  const { settings, updateSettings, users, updateUser, isLoading } = useData();
  const [gaId, setGaId] = useState('');
  const [logoUrl, setLogoUrl] = useState('');
  const [siteTitle, setSiteTitle] = useState('');
  const [inviteUrl, setInviteUrl] = useState('');
  
  // Admin Profile States
  const [adminName, setAdminName] = useState('');
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  
  // SEO States
  const [seoTitle, setSeoTitle] = useState('');
  const [seoDescription, setSeoDescription] = useState('');
  const [seoKeywords, setSeoKeywords] = useState('');

  const [saved, setSaved] = useState(false);
  const [profileSaved, setProfileSaved] = useState(false);

  useEffect(() => {
      if(settings) {
          setGaId(settings.googleAnalyticsId);
          setLogoUrl(settings.siteLogoUrl || '');
          setSiteTitle(settings.siteTitle);
          setInviteUrl(settings.inviteReferralUrl || '');
          
          setSeoTitle(settings.seoTitle || '');
          setSeoDescription(settings.seoDescription || '');
          setSeoKeywords(settings.seoKeywords || '');
      }
  }, [settings]);

  // Load Admin User Data (Assuming User ID 1 is always Admin)
  useEffect(() => {
      const admin = users.find(u => u.id === 1);
      if (admin) {
          setAdminName(admin.name);
          setAdminEmail(admin.email);
          setAdminPassword(admin.password || 'password');
      }
  }, [users]);

  const handleSaveSettings = async (e: React.FormEvent) => {
      e.preventDefault();
      await updateSettings({
          ...settings,
          googleAnalyticsId: gaId,
          siteLogoUrl: logoUrl,
          siteTitle: siteTitle,
          inviteReferralUrl: inviteUrl,
          seoTitle: seoTitle,
          seoDescription: seoDescription,
          seoKeywords: seoKeywords,
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
      e.preventDefault();
      const admin = users.find(u => u.id === 1);
      if (admin) {
          await updateUser({
              ...admin,
              name: adminName,
              email: adminEmail,
              password: adminPassword
          });
          setProfileSaved(true);
          setTimeout(() => setProfileSaved(false), 3000);
      }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-2xl">
      <h1 className="text-2xl font-semibold text-gray-800 mb-6">General Settings</h1>
      
      {/* --- Admin Profile Section --- */}
      <div className="mb-8 bg-purple-50 p-4 rounded-lg border border-purple-200">
          <h2 className="text-lg font-bold text-purple-700 mb-3 border-b border-purple-200 pb-2 flex items-center">
              <i className="mdi mdi-account-cog mr-2"></i>
              Admin Profile Settings (অ্যাডমিন তথ্য)
          </h2>
          <form onSubmit={handleUpdateProfile}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                      <label className="block text-gray-700 text-xs font-bold mb-1">Admin Name</label>
                      <input 
                          type="text" 
                          value={adminName} 
                          onChange={(e) => setAdminName(e.target.value)} 
                          className="w-full border rounded px-3 py-2 text-sm"
                      />
                  </div>
                  <div>
                      <label className="block text-gray-700 text-xs font-bold mb-1">Admin Email</label>
                      <input 
                          type="email" 
                          value={adminEmail} 
                          onChange={(e) => setAdminEmail(e.target.value)} 
                          className="w-full border rounded px-3 py-2 text-sm"
                      />
                  </div>
                  <div className="md:col-span-2">
                      <label className="block text-gray-700 text-xs font-bold mb-1">New Password (পাসওয়ার্ড)</label>
                      <input 
                          type="text" 
                          value={adminPassword} 
                          onChange={(e) => setAdminPassword(e.target.value)} 
                          className="w-full border rounded px-3 py-2 text-sm font-mono bg-white"
                          placeholder="Set new password"
                      />
                  </div>
              </div>
              <div className="flex justify-end mt-4">
                  {profileSaved && <span className="text-green-600 font-bold mr-4 text-sm animate-pulse flex items-center"><i className="mdi mdi-check mr-1"></i> Profile Updated!</span>}
                  <button 
                      type="submit" 
                      disabled={isLoading}
                      className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded text-sm shadow-md transition-colors disabled:opacity-50"
                  >
                      Update Profile
                  </button>
              </div>
          </form>
      </div>

      <form onSubmit={handleSaveSettings}>
        
        {/* Branding Section */}
        <div className="mb-6">
            <h2 className="text-lg font-medium text-gray-700 mb-3 border-b pb-2">Branding (লোগো ও নাম)</h2>
            
            <div className="mb-4">
                <label htmlFor="siteTitle" className="block text-gray-700 text-sm font-bold mb-2">
                    App Name / Title
                </label>
                <input
                    type="text"
                    id="siteTitle"
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    value={siteTitle}
                    onChange={(e) => setSiteTitle(e.target.value)}
                />
            </div>

            <div className="mb-4">
                <label htmlFor="logoUrl" className="block text-gray-700 text-sm font-bold mb-2">
                    Logo URL (Image Link)
                </label>
                <div className="flex gap-4 items-center">
                    <input
                        type="text"
                        id="logoUrl"
                        className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        placeholder="https://example.com/logo.png"
                        value={logoUrl}
                        onChange={(e) => setLogoUrl(e.target.value)}
                    />
                    {logoUrl && (
                        <div className="w-12 h-12 border p-1 rounded bg-gray-50 flex items-center justify-center">
                            <img src={logoUrl} alt="Preview" className="max-w-full max-h-full" />
                        </div>
                    )}
                </div>
                <p className="text-xs text-gray-400 mt-1">
                    Paste a direct link to your logo image (PNG/JPG).
                </p>
            </div>
        </div>

        {/* Invite Page Settings */}
        <div className="mb-6">
            <h2 className="text-lg font-medium text-gray-700 mb-3 border-b pb-2">Invite Page Settings (ইনভাইট লিংক)</h2>
            <div className="mb-4">
                <label htmlFor="inviteUrl" className="block text-gray-700 text-sm font-bold mb-2">
                    Referral / Invite Link (Telegram Bot or Website)
                </label>
                <input
                    type="text"
                    id="inviteUrl"
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="https://t.me/YourBot"
                    value={inviteUrl}
                    onChange={(e) => setInviteUrl(e.target.value)}
                />
                <p className="text-xs text-gray-400 mt-1">
                    This link will be copied when users click "Copy" on the Invite page.
                </p>
            </div>
        </div>

        {/* SEO Section */}
        <div className="mb-6">
            <h2 className="text-lg font-medium text-gray-700 mb-3 border-b pb-2 flex items-center">
                <i className="mdi mdi-magnify-scan mr-2 text-blue-500"></i>
                SEO Settings (সার্চ ইঞ্জিন অপ্টিমাইজেশন)
            </h2>
            
            <div className="mb-4">
                <label htmlFor="seoTitle" className="block text-gray-700 text-sm font-bold mb-2">
                    Meta Title (সার্চ টাইটেল)
                </label>
                <input
                    type="text"
                    id="seoTitle"
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="Best Job - Find Online Jobs"
                    value={seoTitle}
                    onChange={(e) => setSeoTitle(e.target.value)}
                />
            </div>

            <div className="mb-4">
                <label htmlFor="seoDescription" className="block text-gray-700 text-sm font-bold mb-2">
                    Meta Description (বিবরণ)
                </label>
                <textarea
                    id="seoDescription"
                    rows={3}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="A brief description of your website..."
                    value={seoDescription}
                    onChange={(e) => setSeoDescription(e.target.value)}
                />
            </div>

            <div className="mb-4">
                <label htmlFor="seoKeywords" className="block text-gray-700 text-sm font-bold mb-2">
                    Meta Keywords (কি-ওয়ার্ড)
                </label>
                <input
                    type="text"
                    id="seoKeywords"
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="jobs, online work, data entry, freelancing"
                    value={seoKeywords}
                    onChange={(e) => setSeoKeywords(e.target.value)}
                />
            </div>
        </div>

        {/* Analytics Section */}
        <div className="mb-6">
            <h2 className="text-lg font-medium text-gray-700 mb-3 border-b pb-2">Google Analytics</h2>
            <p className="text-sm text-gray-500 mb-4">
                Enter your Google Analytics Measurement ID (starting with <code>G-</code>).
            </p>
            <label htmlFor="gaId" className="block text-gray-700 text-sm font-bold mb-2">
                Measurement ID
            </label>
            <input
                type="text"
                id="gaId"
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                placeholder="G-XXXXXXXXXX"
                value={gaId}
                onChange={(e) => setGaId(e.target.value)}
            />
        </div>

        <div className="flex items-center justify-end">
             {saved && <span className="text-green-600 font-bold mr-4 animate-pulse">Settings Saved!</span>}
            <button
                type="submit"
                disabled={isLoading}
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded focus:outline-none focus:shadow-outline transition-colors disabled:opacity-50"
            >
                {isLoading ? 'Saving...' : 'Save Settings'}
            </button>
        </div>
      </form>
    </div>
  );
};

export default SettingsPage;
