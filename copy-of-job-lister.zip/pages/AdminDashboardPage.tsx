
import React from 'react';
import StatCard from '../components/admin/StatCard';
import TrafficByCountry from '../components/admin/TrafficByCountry';
import type { Job, User, Country, PaymentTransaction, ChatMessage } from '../types';
import LoadingSpinner from '../components/LoadingSpinner';
import { isFirebaseConfigured } from '../services/api';

interface AdminDashboardPageProps {
    jobs: Job[];
    users: User[];
    countries: Country[];
    payments?: PaymentTransaction[];
    chats?: ChatMessage[];
    isLoading?: boolean;
    onNavigate: (page: string) => void;
}

const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({ jobs, users, countries, payments = [], chats = [], isLoading, onNavigate }) => {
  const totalUsers = users.length;
  const totalJobs = jobs.length;
  const totalCountries = countries.length;

  const calculateTrafficData = () => {
    if (!users.length || !countries.length) return [];

    const countryMap = new Map<number, { name: string; flag: string }>(
        countries.map(c => [c.id, { name: c.name, flag: c.flag }] as [number, { name: string; flag: string }])
    );
    const userCounts = new Map<number, number>();

    users.forEach(user => {
        if(user.countryId) {
            userCounts.set(user.countryId, (userCounts.get(user.countryId) || 0) + 1);
        }
    });

    const sortedTraffic = Array.from(userCounts.entries())
        .map(([countryId, count]) => {
            const countryInfo = countryMap.get(countryId);
            return {
                country: countryInfo?.name || 'Unknown',
                flag: countryInfo?.flag || '🌍',
                visitors: count,
                percentage: totalUsers > 0 ? Math.round((count / totalUsers) * 100) : 0,
            };
        })
        .sort((a, b) => b.visitors - a.visitors);

    const maxVisibleCountries = 5;
    if (sortedTraffic.length > maxVisibleCountries) {
        const visible = sortedTraffic.slice(0, maxVisibleCountries);
        const others = sortedTraffic.slice(maxVisibleCountries);
        const othersCount = others.reduce((acc, curr) => acc + curr.visitors, 0);
        if (othersCount > 0) {
            visible.push({
                country: 'Others',
                flag: '🌍',
                visitors: othersCount,
                percentage: totalUsers > 0 ? Math.round((othersCount / totalUsers) * 100) : 0,
            });
        }
        return visible;
    }

    return sortedTraffic;
  };

  const trafficData = calculateTrafficData();

  // Get last 5 users for the "Recent Users" table
  const recentUsers = [...users].reverse().slice(0, 5);

  // Get last 5 payments
  const recentPayments = [...payments].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 5);
  const pendingCount = payments.filter(p => p.status === 'pending').length;

  // Process Recent Chats
  const recentChats = Array.from(new Set(chats.map(c => c.userId))).map(userId => {
        const userChats = chats.filter(c => c.userId === userId);
        const lastMsg = userChats[userChats.length - 1];
        const user = users.find(u => u.id === userId);
        const name = user ? user.name : (lastMsg?.userName || 'Guest');
        
        return {
            userId,
            name,
            lastMessage: lastMsg?.text || '',
            lastTime: lastMsg?.timestamp || new Date().toISOString(),
            hasUnread: userChats.some(c => !c.isRead && c.sender === 'user')
        };
    })
    .sort((a, b) => new Date(b.lastTime).getTime() - new Date(a.lastTime).getTime())
    .slice(0, 5);

  if (isLoading) {
      return <LoadingSpinner />;
  }

  // Determine if running in local mode (Check both env and hardcoded config)
  const env = (import.meta as any).env || {};
  const isEnvFirebase = env.VITE_ENABLE_FIREBASE;
  const isHardcodedFirebase = isFirebaseConfigured();
  
  const isLocalMode = !isEnvFirebase && !isHardcodedFirebase;

  return (
    <div>
        <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-semibold text-gray-800">Dashboard</h1>
        </div>

        {/* Warning Banner for Local Mode */}
        {isLocalMode && (
            <div className="bg-orange-100 border-l-4 border-orange-500 text-orange-700 p-4 mb-6 rounded shadow-sm flex justify-between items-center">
                <div>
                    <p className="font-bold">⚠ Local Mode Active</p>
                    <p className="text-sm">You are using local storage. Changes will NOT be visible to other users. Connect Firebase in Settings or Hardcode it in code to go live.</p>
                </div>
                <button onClick={() => onNavigate('database')} className="bg-orange-500 text-white px-3 py-1 rounded text-sm hover:bg-orange-600 transition">
                    Fix Now
                </button>
            </div>
        )}

        {/* Stats Cards Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            <StatCard
              title="Total Users"
              value={totalUsers.toLocaleString()}
              icon="mdi-account-group"
              gradient="bg-gradient-to-r from-purple-500 to-pink-500"
              onClick={() => onNavigate('users')}
            />
            <StatCard
              title="Pending Payments"
              value={pendingCount.toLocaleString()}
              icon="mdi-cash-multiple"
              gradient="bg-gradient-to-r from-yellow-400 to-orange-500"
              onClick={() => onNavigate('payments')}
            />
             <StatCard
              title="Total Jobs"
              value={totalJobs.toLocaleString()}
              icon="mdi-briefcase"
              gradient="bg-gradient-to-r from-sky-400 to-blue-600"
              onClick={() => onNavigate('jobs')}
            />
        </div>

        {/* Recent Payments Section */}
        <div className="bg-white p-6 rounded-lg shadow-lg mt-8 border border-gray-100">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-gray-800 flex items-center">
                    <i className="mdi mdi-credit-card-outline mr-2 text-green-600"></i>
                    Recent Payments (সর্বশেষ পেমেন্ট)
                </h2>
                <button 
                    onClick={() => onNavigate('payments')} 
                    className="text-blue-500 hover:text-blue-700 text-sm font-semibold transition-colors bg-blue-50 px-3 py-1 rounded-full"
                >
                    View All
                </button>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-left">
                    <thead>
                        <tr className="text-gray-500 border-b border-gray-100 text-xs uppercase tracking-wider">
                            <th className="pb-3 font-medium">User/Sender</th>
                            <th className="pb-3 font-medium">Method</th>
                            <th className="pb-3 font-medium">Amount</th>
                            <th className="pb-3 font-medium text-right">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {recentPayments.length === 0 ? (
                            <tr>
                                <td colSpan={4} className="py-6 text-center text-gray-400 text-sm italic">
                                    No recent payments found.
                                </td>
                            </tr>
                        ) : (
                            recentPayments.map(payment => (
                                <tr key={payment.id} className="border-b border-gray-50 last:border-0 hover:bg-gray-50 transition-colors">
                                    <td className="py-3">
                                        <div className="font-medium text-gray-800 text-sm">{payment.userName}</div>
                                        <div className="text-xs text-gray-500">{payment.senderNumber}</div>
                                    </td>
                                    <td className="py-3 text-sm text-gray-600">{payment.methodName}</td>
                                    <td className="py-3 font-bold text-gray-800 text-sm">
                                        {payment.currency === 'BDT' ? '৳' : '$'}{payment.amount}
                                    </td>
                                    <td className="py-3 text-right">
                                        <span className={`px-2 py-1 rounded-full text-xs font-bold uppercase ${
                                            payment.status === 'approved' ? 'bg-green-100 text-green-700' :
                                            payment.status === 'rejected' ? 'bg-red-100 text-red-700' :
                                            'bg-yellow-100 text-yellow-700 animate-pulse'
                                        }`}>
                                            {payment.status}
                                        </span>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>

        {/* Charts & Tables Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
            
            {/* Recent Live Chats (New Widget) */}
            <div className="bg-white p-6 rounded-lg shadow-lg flex flex-col h-full border border-gray-100">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-semibold text-gray-800 flex items-center">
                        <i className="mdi mdi-face-agent mr-2 text-purple-600"></i>
                        Recent Live Chats
                    </h2>
                    <button 
                        onClick={() => onNavigate('bot-chat')} 
                        className="text-purple-500 hover:text-purple-700 text-sm font-semibold transition-colors"
                    >
                        View All
                    </button>
                </div>
                <div className="flex-grow">
                    {recentChats.length === 0 ? (
                        <div className="flex flex-col items-center justify-center h-full text-gray-400 py-8">
                            <i className="mdi mdi-chat-outline text-4xl mb-2"></i>
                            <p className="text-sm">No recent messages</p>
                        </div>
                    ) : (
                        <ul className="space-y-3">
                            {recentChats.map(chat => (
                                <li key={chat.userId} className={`flex items-center justify-between p-3 rounded-lg border ${chat.hasUnread ? 'bg-purple-50 border-purple-200' : 'bg-gray-50 border-gray-100'}`}>
                                    <div className="flex items-center overflow-hidden">
                                        <div className={`w-10 h-10 rounded-full flex items-center justify-center mr-3 text-white font-bold flex-shrink-0 ${chat.hasUnread ? 'bg-purple-600' : 'bg-gray-400'}`}>
                                            {chat.name.charAt(0).toUpperCase()}
                                        </div>
                                        <div className="min-w-0">
                                            <p className="font-bold text-gray-800 text-sm truncate">
                                                {chat.name}
                                                {chat.hasUnread && <span className="ml-2 text-[10px] bg-red-500 text-white px-1.5 rounded-full">NEW</span>}
                                            </p>
                                            <p className="text-xs text-gray-500 truncate max-w-[150px]">{chat.lastMessage}</p>
                                        </div>
                                    </div>
                                    <div className="text-right flex-shrink-0">
                                        <p className="text-[10px] text-gray-400 mb-1">
                                            {new Date(chat.lastTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                        </p>
                                        <button 
                                            onClick={() => onNavigate('bot-chat')}
                                            className="text-xs text-blue-500 hover:underline"
                                        >
                                            Reply
                                        </button>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    )}
                </div>
            </div>

            {/* Recent Users Table */}
            <div className="bg-white p-6 rounded-lg shadow-lg flex flex-col h-full">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-semibold text-gray-800">Recent Users</h2>
                    <button 
                        onClick={() => onNavigate('users')} 
                        className="text-blue-500 hover:text-blue-700 text-sm font-semibold transition-colors"
                    >
                        View All
                    </button>
                </div>
                <div className="overflow-x-auto flex-grow">
                    <table className="w-full text-left">
                        <thead>
                            <tr className="text-gray-500 border-b border-gray-100">
                                <th className="pb-3 font-medium text-sm">Name</th>
                                <th className="pb-3 font-medium text-sm">Email</th>
                                <th className="pb-3 font-medium text-sm text-right">Role</th>
                            </tr>
                        </thead>
                        <tbody>
                            {recentUsers.map(user => (
                                <tr key={user.id} className="border-b border-gray-50 last:border-0 hover:bg-gray-50 transition-colors">
                                    <td className="py-3 font-medium text-gray-800 text-sm">{user.name}</td>
                                    <td className="py-3 text-sm text-gray-500">{user.email}</td>
                                    <td className="py-3 text-right">
                                        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${user.role === 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-green-100 text-green-700'}`}>
                                            {user.role}
                                        </span>
                                    </td>
                                </tr>
                            ))}
                            {recentUsers.length === 0 && (
                                <tr>
                                    <td colSpan={3} className="py-8 text-center text-gray-400 text-sm">
                                        No users found.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        {/* Traffic Stats Row */}
        <div className="mt-8">
             <TrafficByCountry data={trafficData} />
        </div>
    </div>
  );
};

export default AdminDashboardPage;
