import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import type { Page, User } from '../types';
import AdBanner from '../components/AdBanner';
import SiteLogo from '../components/SiteLogo';

interface JobDetailsPageProps {
  jobId: number | null;
  onNavigate: (page: Page) => void;
  user: User | null;
}

const JobDetailsPage: React.FC<JobDetailsPageProps> = ({ jobId, onNavigate, user }) => {
  const { jobs, settings, jobComments, addJobComment } = useData();
  const [commentText, setCommentText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedMsg, setSubmittedMsg] = useState(false);
  
  const job = jobs.find(j => j.id === jobId);

  if (!job) {
    return (
      <div className="p-4 text-center">
        <p className="text-red-500 mb-4">Job not found.</p>
        <button 
          onClick={() => onNavigate('home')}
          className="bg-blue-500 text-white px-4 py-2 rounded"
        >
          Go Home
        </button>
      </div>
    );
  }

  // Filter comments for this job and sort by new
  // ONLY SHOW APPROVED COMMENTS
  const comments = jobComments
    .filter(c => c.jobId === job.id && c.status === 'approved')
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const handleCommentSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!user) {
          onNavigate('settings'); // Redirect to login
          return;
      }
      if (!commentText.trim()) return;

      setIsSubmitting(true);
      await addJobComment({
          jobId: job.id,
          userId: user.id,
          userName: user.name,
          text: commentText
      });
      setCommentText('');
      setIsSubmitting(false);
      setSubmittedMsg(true);
      setTimeout(() => setSubmittedMsg(false), 5000);
  };

  return (
    <div className="min-h-screen bg-transparent pb-20">
      {/* Header / Back Button */}
      <div className="bg-white/40 backdrop-blur-md shadow-sm sticky top-0 z-10 flex items-center justify-between px-4 py-2 border-b border-white/20">
         <div className="flex items-center">
            <button 
                onClick={() => onNavigate('jobs')} 
                className="mr-3 text-gray-800 hover:text-blue-600"
            >
                <i className="mdi mdi-arrow-left text-2xl"></i>
            </button>
            <h1 className="text-lg font-bold text-gray-800 truncate mr-2">Job Details</h1>
        </div>
        
        {/* Logo in Header */}
        <div className="flex-shrink-0">
             <SiteLogo className="h-8 w-auto" />
        </div>
      </div>

      {/* Top Ad */}
      {settings.jobsTopAdCode && (
          <div className="p-4 pb-0">
              <AdBanner code={settings.jobsTopAdCode} />
          </div>
      )}

      <div className="p-4">
        <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-lg overflow-hidden border border-white/50">
            {/* Image Header */}
            <div className="bg-white p-6 flex justify-center items-center border-b border-gray-100">
                <img 
                    src={job.imageUrl} 
                    alt={job.title} 
                    className="max-h-48 max-w-full object-contain drop-shadow-sm" 
                />
            </div>
            
            <div className="p-6">
                <h1 className="text-2xl font-bold text-gray-900 mb-2">{job.title}</h1>
                
                <div className="flex items-center text-gray-600 mb-4 text-sm">
                    <span className="font-semibold text-blue-600 mr-2">{job.company}</span>
                    <span className="mx-2">•</span>
                    <span className="bg-red-100 text-red-800 px-2 py-0.5 rounded text-xs font-bold border border-red-200">{job.salary}</span>
                </div>

                {/* Apply Button (Top) */}
                <a 
                    href={job.applyUrl}
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="block w-full text-center bg-blue-600 text-white font-bold py-3 rounded-lg hover:bg-blue-700 transition-colors mb-6 shadow-md"
                >
                    Apply Now
                </a>

                <div className="border-t border-gray-100 pt-6">
                    <h3 className="text-lg font-semibold text-gray-800 mb-3">Job Description:</h3>
                    <div className="prose text-gray-600 text-sm leading-relaxed whitespace-pre-line">
                        {job.description}
                    </div>
                    
                    {/* Placeholder for features if needed */}
                    <div className="mt-6">
                        <h3 className="text-lg font-semibold text-gray-800 mb-3">Features:</h3>
                        <ul className="space-y-2 text-sm text-gray-600">
                            <li className="flex items-start">
                                <i className="mdi mdi-check-circle text-green-500 mr-2 mt-0.5"></i>
                                <span>Basic computer knowledge is enough to participate.</span>
                            </li>
                             <li className="flex items-start">
                                <i className="mdi mdi-check-circle text-green-500 mr-2 mt-0.5"></i>
                                <span>Work at your own free time.</span>
                            </li>
                             <li className="flex items-start">
                                <i className="mdi mdi-check-circle text-green-500 mr-2 mt-0.5"></i>
                                <span>No investment needed.</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        {/* Comment Section */}
        <div className="mt-6 bg-white/90 backdrop-blur-sm rounded-lg shadow-lg p-6 border border-white/50">
            <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
                <i className="mdi mdi-comment-text-multiple-outline mr-2 text-blue-600"></i>
                Discussion / Comments ({comments.length})
            </h3>
            
            {/* Comment List */}
            <div className="space-y-4 mb-6 max-h-80 overflow-y-auto pr-2">
                {comments.length === 0 ? (
                    <p className="text-sm text-gray-500 italic text-center py-4 bg-gray-50 rounded">
                        No comments yet. Be the first to ask a question!
                    </p>
                ) : (
                    comments.map(comment => (
                        <div key={comment.id} className="bg-gray-50 p-3 rounded-lg border border-gray-100">
                            <div className="flex justify-between items-start mb-1">
                                <span className="font-bold text-sm text-gray-800">{comment.userName}</span>
                                <span className="text-[10px] text-gray-400">{comment.date}</span>
                            </div>
                            <p className="text-sm text-gray-600">{comment.text}</p>
                        </div>
                    ))
                )}
            </div>

            {/* Add Comment Form */}
            {user ? (
                <form onSubmit={handleCommentSubmit} className="mt-4">
                    <textarea 
                        value={commentText}
                        onChange={(e) => setCommentText(e.target.value)}
                        placeholder="Write a comment or ask a question..."
                        className="w-full p-3 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                        rows={3}
                        required
                    />
                    <div className="flex justify-end mt-2 items-center gap-2">
                        {submittedMsg && <span className="text-green-600 text-xs font-bold">Submited for review!</span>}
                        <button 
                            type="submit" 
                            disabled={isSubmitting}
                            className="bg-blue-600 text-white font-bold py-2 px-6 rounded-lg text-sm hover:bg-blue-700 transition-colors shadow-sm disabled:opacity-50"
                        >
                            {isSubmitting ? 'Posting...' : 'Post Comment'}
                        </button>
                    </div>
                </form>
            ) : (
                <div className="text-center bg-gray-100 p-4 rounded-lg">
                    <p className="text-sm text-gray-600 mb-2">You must be logged in to post a comment.</p>
                    <button 
                        onClick={() => onNavigate('settings')}
                        className="bg-purple-600 text-white font-bold py-2 px-4 rounded text-sm hover:bg-purple-700"
                    >
                        Login to Comment
                    </button>
                </div>
            )}
        </div>

        {/* Bottom Apply Button */}
        <div className="mt-6">
             <a 
                href={job.applyUrl}
                target="_blank" 
                rel="noopener noreferrer"
                className="block w-full text-center bg-green-500 text-white font-bold py-3 rounded-lg hover:bg-green-600 transition-colors shadow-md"
            >
                Start Job Now
            </a>
        </div>
      </div>

      {/* Bottom Ad */}
      {settings.jobsBottomAdCode && (
          <div className="p-4 pt-0">
              <AdBanner code={settings.jobsBottomAdCode} />
          </div>
      )}
    </div>
  );
};

export default JobDetailsPage;