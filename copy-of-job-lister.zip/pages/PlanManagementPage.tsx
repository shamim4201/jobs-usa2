import React, { useState, useEffect } from 'react';
import { useData } from '../context/DataContext';
import type { AppSettings, PricingPlan, FaqItem, PaymentMethod } from '../types';

// Plan Editor Component
const PlanEditor: React.FC<{
    planName: string;
    plan: PricingPlan;
    onSave: (plan: PricingPlan) => void;
    isLoading: boolean;
}> = ({ planName, plan, onSave, isLoading }) => {
    const [data, setData] = useState<PricingPlan>(plan);
    const [featuresText, setFeaturesText] = useState(plan.features.join('\n'));
    const [saved, setSaved] = useState(false);

    useEffect(() => {
        setData(plan);
        setFeaturesText(plan.features.join('\n'));
    }, [plan]);

    const handleFeaturesChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        setFeaturesText(e.target.value);
        setData(prev => ({
            ...prev,
            features: e.target.value.split('\n').filter(line => line.trim() !== '')
        }));
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSave = () => {
        onSave(data);
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-md border border-purple-100 h-full flex flex-col">
             <div className="flex justify-between items-center mb-4 border-b pb-2">
                <h3 className="font-bold text-gray-800 text-lg">{planName}</h3>
                {data.isPopular && <span className="bg-purple-100 text-purple-700 text-xs px-2 py-1 rounded font-bold">POPULAR</span>}
            </div>

            <div className="mb-4">
                <label className="block text-gray-700 text-xs font-bold mb-1">Plan Title</label>
                <input name="title" value={data.title} onChange={handleChange} className="w-full border rounded px-2 py-1 text-sm focus:ring-1 focus:ring-purple-500" />
            </div>

            {/* Monthly Settings */}
            <div className="bg-blue-50 p-3 rounded mb-3 border border-blue-100">
                <p className="text-xs font-bold text-blue-700 mb-2 uppercase">Monthly Settings (মাসিক)</p>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-gray-700 text-xs font-bold mb-1">Price</label>
                        <input name="price" value={data.price} onChange={handleChange} className="w-full border rounded px-2 py-1 text-sm focus:ring-1 focus:ring-purple-500" placeholder="$8" />
                    </div>
                    <div>
                        <label className="block text-gray-700 text-xs font-bold mb-1">Unit</label>
                        <input name="unit" value={data.unit} onChange={handleChange} className="w-full border rounded px-2 py-1 text-sm focus:ring-1 focus:ring-purple-500" placeholder="/mo" />
                    </div>
                </div>
            </div>

            {/* Yearly Settings */}
            <div className="bg-orange-50 p-3 rounded mb-3 border border-orange-100">
                <p className="text-xs font-bold text-orange-700 mb-2 uppercase">Yearly Settings (বাৎসরিক)</p>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-gray-700 text-xs font-bold mb-1">Price</label>
                        <input name="yearlyPrice" value={data.yearlyPrice || ''} onChange={handleChange} className="w-full border rounded px-2 py-1 text-sm focus:ring-1 focus:ring-purple-500" placeholder="$80" />
                    </div>
                    <div>
                        <label className="block text-gray-700 text-xs font-bold mb-1">Unit</label>
                        <input name="yearlyUnit" value={data.yearlyUnit || ''} onChange={handleChange} className="w-full border rounded px-2 py-1 text-sm focus:ring-1 focus:ring-purple-500" placeholder="/yr" />
                    </div>
                </div>
            </div>

            <div className="mb-4 flex-grow">
                <label className="block text-gray-700 text-xs font-bold mb-1">Features (One per line)</label>
                <textarea 
                    value={featuresText} 
                    onChange={handleFeaturesChange} 
                    rows={5} 
                    className="w-full border rounded px-2 py-1 text-sm focus:ring-1 focus:ring-purple-500"
                    placeholder="Feature 1&#10;Feature 2&#10;Feature 3"
                />
            </div>

            <div className="mb-4">
                 <label className="block text-gray-700 text-xs font-bold mb-1">Button Text</label>
                 <input name="buttonText" value={data.buttonText} onChange={handleChange} className="w-full border rounded px-2 py-1 text-sm focus:ring-1 focus:ring-purple-500" />
            </div>

            <div className="flex justify-end items-center mt-auto pt-4 border-t">
                 {saved && <span className="text-green-600 font-bold mr-3 text-xs animate-pulse">Saved!</span>}
                <button 
                    onClick={handleSave}
                    disabled={isLoading}
                    className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded text-sm transition-colors disabled:opacity-50"
                >
                    Update Plan
                </button>
            </div>
        </div>
    );
};

// General Plan Settings (Labels)
const GeneralPlanSettings: React.FC<{
    monthLabel: string;
    yearLabel: string;
    onSave: (monthLabel: string, yearLabel: string) => void;
    isLoading: boolean;
}> = ({ monthLabel, yearLabel, onSave, isLoading }) => {
    const [localMonth, setLocalMonth] = useState(monthLabel);
    const [localYear, setLocalYear] = useState(yearLabel);
    const [saved, setSaved] = useState(false);

    useEffect(() => {
        setLocalMonth(monthLabel);
        setLocalYear(yearLabel);
    }, [monthLabel, yearLabel]);

    const handleSave = () => {
        onSave(localMonth, localYear);
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-md border border-purple-100 mb-6">
             <div className="flex justify-between items-center mb-4 border-b pb-2">
                <h3 className="font-bold text-gray-800 text-lg">General Plan Settings (বাটনের নাম)</h3>
            </div>
            <div className="grid grid-cols-2 gap-6">
                <div>
                    <label className="block text-gray-700 text-xs font-bold mb-1">Month Button Label</label>
                    <input 
                        value={localMonth} 
                        onChange={(e) => setLocalMonth(e.target.value)} 
                        className="w-full border rounded px-2 py-2 text-sm focus:ring-1 focus:ring-purple-500" 
                        placeholder="e.g. Month"
                    />
                </div>
                <div>
                    <label className="block text-gray-700 text-xs font-bold mb-1">Year Button Label</label>
                    <input 
                        value={localYear} 
                        onChange={(e) => setLocalYear(e.target.value)} 
                        className="w-full border rounded px-2 py-2 text-sm focus:ring-1 focus:ring-purple-500" 
                        placeholder="e.g. Year"
                    />
                </div>
            </div>
            <div className="flex justify-end items-center mt-4">
                 {saved && <span className="text-green-600 font-bold mr-3 text-xs animate-pulse">Saved!</span>}
                <button 
                    onClick={handleSave}
                    disabled={isLoading}
                    className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-6 rounded text-sm transition-colors disabled:opacity-50"
                >
                    Save Labels
                </button>
            </div>
        </div>
    );
};

// FAQ Editor Component
const FaqSettings: React.FC<{
    faqs: FaqItem[];
    onSave: (faqs: FaqItem[]) => void;
    isLoading: boolean;
}> = ({ faqs, onSave, isLoading }) => {
    const [faqList, setFaqList] = useState<FaqItem[]>(faqs);
    const [saved, setSaved] = useState(false);

    useEffect(() => {
        setFaqList(faqs || []);
    }, [faqs]);

    const handleChange = (index: number, field: keyof FaqItem, value: string) => {
        const updated = [...faqList];
        updated[index] = { ...updated[index], [field]: value };
        setFaqList(updated);
    };

    const handleAdd = () => {
        setFaqList([...faqList, { question: '', answer: '' }]);
    };

    const handleDelete = (index: number) => {
        const updated = faqList.filter((_, i) => i !== index);
        setFaqList(updated);
    };

    const handleSave = () => {
        onSave(faqList);
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-md border border-purple-100">
             <div className="flex justify-between items-center mb-6 border-b pb-2">
                <h3 className="font-bold text-gray-800 text-lg">FAQ Management</h3>
                <button 
                    onClick={handleAdd}
                    className="bg-green-500 hover:bg-green-600 text-white font-bold py-1 px-3 rounded text-sm transition-colors"
                >
                    + Add Question
                </button>
            </div>

            <div className="space-y-6">
                {faqList.map((faq, index) => (
                    <div key={index} className="bg-gray-50 p-4 rounded-md border border-gray-200 relative group">
                        <button 
                            onClick={() => handleDelete(index)}
                            className="absolute top-2 right-2 text-red-400 hover:text-red-600 p-1"
                            title="Delete FAQ"
                        >
                            <i className="mdi mdi-delete text-xl"></i>
                        </button>
                        
                        <div className="mb-3 pr-8">
                            <label className="block text-gray-700 text-xs font-bold mb-1">Question (প্রশ্ন)</label>
                            <input 
                                value={faq.question} 
                                onChange={(e) => handleChange(index, 'question', e.target.value)}
                                className="w-full border rounded px-2 py-1 text-sm focus:ring-1 focus:ring-purple-500"
                                placeholder="Enter question..."
                            />
                        </div>
                        
                        <div>
                            <label className="block text-gray-700 text-xs font-bold mb-1">Answer (উত্তর)</label>
                            <textarea 
                                value={faq.answer} 
                                onChange={(e) => handleChange(index, 'answer', e.target.value)}
                                rows={2}
                                className="w-full border rounded px-2 py-1 text-sm focus:ring-1 focus:ring-purple-500"
                                placeholder="Enter answer..."
                            />
                        </div>
                    </div>
                ))}
            </div>

            {faqList.length === 0 && (
                <p className="text-center text-gray-400 py-8 border-2 border-dashed border-gray-200 rounded-lg">
                    No FAQs added yet. Click "Add Question" to start.
                </p>
            )}

            <div className="flex justify-end items-center mt-6 border-t pt-4">
                 {saved && <span className="text-green-600 font-bold mr-3 text-sm animate-pulse">FAQs Saved!</span>}
                <button 
                    onClick={handleSave}
                    disabled={isLoading}
                    className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-6 rounded text-sm transition-colors disabled:opacity-50"
                >
                    {isLoading ? 'Saving...' : 'Save All FAQs'}
                </button>
            </div>
        </div>
    );
};

// Payment Settings Component
const PaymentSettings: React.FC<{
    methods: PaymentMethod[];
    onSave: (methods: PaymentMethod[]) => void;
    isLoading: boolean;
}> = ({ methods, onSave, isLoading }) => {
    const [methodList, setMethodList] = useState<PaymentMethod[]>(methods);
    const [saved, setSaved] = useState(false);

    useEffect(() => {
        setMethodList(methods || []);
    }, [methods]);

    const handleChange = (index: number, field: keyof PaymentMethod, value: string | boolean) => {
        const updated = [...methodList];
        // @ts-ignore
        updated[index] = { ...updated[index], [field]: value };
        setMethodList(updated);
    };

    const handleAddMethod = () => {
        const newMethod: PaymentMethod = {
            id: `new-${Date.now()}`,
            name: 'New Method',
            number: '017...',
            instruction: 'Send Money',
            logoBg: 'bg-gray-500',
            isEnabled: true,
            currency: 'BDT'
        };
        // Fix: Add to the TOP of the list so user can see it immediately
        setMethodList([newMethod, ...methodList]);
    };

    const handleDeleteMethod = (index: number) => {
        const updated = methodList.filter((_, i) => i !== index);
        setMethodList(updated);
    };

    const handleSave = () => {
        onSave(methodList);
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-md border border-purple-100">
            <div className="flex justify-between items-center mb-6 border-b pb-2">
                <h3 className="font-bold text-gray-800 text-lg">Payment Settings (পেমেন্ট গেটওয়ে)</h3>
                <button 
                    onClick={handleAddMethod}
                    className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-1 px-3 rounded text-sm transition-colors"
                >
                    + Add Method
                </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {methodList.map((method, index) => (
                    <div key={method.id} className={`p-4 rounded-lg border relative ${method.isEnabled ? 'border-blue-300 bg-blue-50' : 'border-gray-200 bg-gray-50'}`}>
                        <button 
                            onClick={() => handleDeleteMethod(index)}
                            className="absolute top-2 right-2 text-red-400 hover:text-red-600"
                            title="Delete Method"
                        >
                            <i className="mdi mdi-close-circle text-xl"></i>
                        </button>

                        <div className="flex justify-between items-center mb-3 pr-6">
                            <input 
                                value={method.name}
                                onChange={(e) => handleChange(index, 'name', e.target.value)}
                                className="font-bold text-gray-800 bg-transparent border-b border-transparent focus:border-blue-500 focus:outline-none w-2/3"
                            />
                            <div className="relative inline-block w-10 align-middle select-none transition duration-200 ease-in">
                                <input 
                                    type="checkbox" 
                                    name={`toggle-${method.id}`} 
                                    id={`toggle-${method.id}`} 
                                    checked={method.isEnabled}
                                    onChange={(e) => handleChange(index, 'isEnabled', e.target.checked)}
                                    className="toggle-checkbox absolute block w-5 h-5 rounded-full bg-white border-4 appearance-none cursor-pointer"
                                    style={{ right: method.isEnabled ? '0' : 'auto', left: method.isEnabled ? 'auto' : '0' }}
                                />
                                <label 
                                    htmlFor={`toggle-${method.id}`} 
                                    className={`toggle-label block overflow-hidden h-5 rounded-full cursor-pointer ${method.isEnabled ? 'bg-blue-500' : 'bg-gray-300'}`}
                                ></label>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-2 mb-2">
                             <div>
                                <label className="block text-gray-500 text-[10px] font-bold mb-1">Currency</label>
                                <select
                                    value={method.currency || 'BDT'}
                                    onChange={(e) => handleChange(index, 'currency', e.target.value)}
                                    className="w-full border rounded px-1 py-1 text-xs bg-white"
                                >
                                    <option value="BDT">BDT (৳)</option>
                                    <option value="USD">USD ($)</option>
                                </select>
                            </div>
                             <div>
                                <label className="block text-gray-500 text-[10px] font-bold mb-1">Color</label>
                                <select
                                    value={method.logoBg}
                                    onChange={(e) => handleChange(index, 'logoBg', e.target.value)}
                                    className="w-full border rounded px-1 py-1 text-xs bg-white"
                                >
                                    <option value="bg-pink-600">Pink (Bkash)</option>
                                    <option value="bg-orange-600">Orange (Nagad)</option>
                                    <option value="bg-purple-600">Purple (Rocket)</option>
                                    <option value="bg-yellow-500">Yellow (Binance)</option>
                                    <option value="bg-indigo-600">Indigo (Bank)</option>
                                    <option value="bg-blue-600">Blue</option>
                                    <option value="bg-gray-600">Gray</option>
                                </select>
                            </div>
                        </div>

                        <div className="mb-2">
                            <label className="block text-gray-600 text-xs font-bold mb-1">Number / Wallet</label>
                            <input 
                                value={method.number}
                                onChange={(e) => handleChange(index, 'number', e.target.value)}
                                className="w-full border rounded px-2 py-1 text-sm bg-white"
                            />
                        </div>
                        <div>
                            <label className="block text-gray-600 text-xs font-bold mb-1">Instruction</label>
                            <input 
                                value={method.instruction}
                                onChange={(e) => handleChange(index, 'instruction', e.target.value)}
                                className="w-full border rounded px-2 py-1 text-xs bg-white"
                            />
                        </div>
                    </div>
                ))}
            </div>

            <div className="flex justify-end items-center mt-6 border-t pt-4">
                 {saved && <span className="text-green-600 font-bold mr-3 text-sm animate-pulse">Saved!</span>}
                <button 
                    onClick={handleSave}
                    disabled={isLoading}
                    className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-6 rounded text-sm transition-colors disabled:opacity-50"
                >
                    Update Payment Info
                </button>
            </div>
        </div>
    );
};

const PlanManagementPage: React.FC = () => {
    const { settings, updateSettings, isLoading } = useData();

    const handlePlanSave = async (key: 'freePlan' | 'premiumPlan', plan: PricingPlan) => {
        const newSettings = { ...settings, [key]: plan };
        await updateSettings(newSettings);
    }
    
    const handleLabelSave = async (monthLabel: string, yearLabel: string) => {
        const newSettings = { ...settings, billingCycleMonthLabel: monthLabel, billingCycleYearLabel: yearLabel };
        await updateSettings(newSettings);
    }

    const handleFaqSave = async (faqs: FaqItem[]) => {
        const newSettings = { ...settings, faqs };
        await updateSettings(newSettings);
    }

    const handlePaymentSave = async (paymentMethods: PaymentMethod[]) => {
        const newSettings = { ...settings, paymentMethods };
        await updateSettings(newSettings);
    }

    // Default empty objects to prevent crashes if settings are loading
    const freePlan = settings.freePlan || { title: '', price: '', unit: '', features: [], buttonText: '', buttonLink: '', isPopular: false };
    const premiumPlan = settings.premiumPlan || { title: '', price: '', unit: '', features: [], buttonText: '', buttonLink: '', isPopular: false };

    return (
        <div className="h-full flex flex-col">
            <div className="mb-6">
                <h1 className="text-2xl font-bold text-gray-800">Plan Management (প্ল্যান ম্যানেজমেন্ট)</h1>
                <p className="text-gray-500">এখানে আপনি মেম্বারশিপ প্ল্যান, FAQ এবং পেমেন্ট সেটিং পরিবর্তন করতে পারবেন।</p>
            </div>
            
            {/* Pricing Plans Section */}
            <h2 className="text-xl font-bold text-gray-800 mt-2 mb-4 pb-2 border-b border-gray-200 flex items-center">
                <i className="mdi mdi-star-circle-outline mr-2 text-purple-600"></i>
                Pricing Plan Settings (মেম্বারশিপ প্ল্যান)
            </h2>
            
            {/* New General Settings Box */}
            <GeneralPlanSettings 
                monthLabel={settings.billingCycleMonthLabel || 'Month'}
                yearLabel={settings.billingCycleYearLabel || 'Year'}
                onSave={handleLabelSave}
                isLoading={isLoading}
            />

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 pb-8">
                <PlanEditor 
                    planName="Free Plan Settings" 
                    plan={freePlan} 
                    onSave={(p) => handlePlanSave('freePlan', p)} 
                    isLoading={isLoading}
                />
                <PlanEditor 
                    planName="Premium Plan Settings" 
                    plan={premiumPlan} 
                    onSave={(p) => handlePlanSave('premiumPlan', p)} 
                    isLoading={isLoading}
                />
            </div>

             {/* Payment Gateway Section */}
             <h2 className="text-xl font-bold text-gray-800 mt-4 mb-4 pb-2 border-b border-gray-200 flex items-center">
                <i className="mdi mdi-wallet-outline mr-2 text-blue-600"></i>
                Payment Gateway Settings (বিকাশ/নগদ সেটিংস)
            </h2>
            <div className="pb-8">
                <PaymentSettings 
                    methods={settings.paymentMethods || []}
                    onSave={handlePaymentSave}
                    isLoading={isLoading}
                />
            </div>

            {/* FAQ Section */}
            <h2 className="text-xl font-bold text-gray-800 mt-4 mb-4 pb-2 border-b border-gray-200 flex items-center">
                <i className="mdi mdi-frequently-asked-questions mr-2 text-green-600"></i>
                FAQ Settings (প্রশ্ন ও উত্তর)
            </h2>
            <div className="pb-20">
                <FaqSettings 
                    faqs={settings.faqs || []} 
                    onSave={handleFaqSave}
                    isLoading={isLoading}
                />
            </div>
        </div>
    );
};

export default PlanManagementPage;