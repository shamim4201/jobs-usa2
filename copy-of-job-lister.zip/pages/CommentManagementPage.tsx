import React, { useState } from 'react';
import { useData } from '../context/DataContext';

const CommentManagementPage: React.FC = () => {
    const { jobComments, jobs, updateJobCommentStatus, deleteJobComment } = useData();
    const [activeTab, setActiveTab] = useState<'pending' | 'approved' | 'all'>('pending');

    const filteredComments = activeTab === 'all' 
        ? jobComments 
        : jobComments.filter(c => c.status === activeTab);

    // Sort by newest first
    const sortedComments = [...filteredComments].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    const getJobTitle = (jobId: number) => {
        const job = jobs.find(j => j.id === jobId);
        return job ? job.title : `Job #${jobId} (Deleted)`;
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <h1 className="text-2xl font-semibold text-gray-800 mb-6 flex items-center">
                <i className="mdi mdi-comment-text-multiple-outline mr-2 text-blue-600"></i>
                Comment Moderation (কমেন্ট ম্যানেজমেন্ট)
            </h1>

            {/* Tabs */}
            <div className="flex border-b border-gray-200 mb-6 space-x-2">
                <button
                    onClick={() => setActiveTab('pending')}
                    className={`py-2 px-4 text-sm font-bold border-b-2 transition-colors ${
                        activeTab === 'pending' ? 'border-yellow-500 text-yellow-600' : 'border-transparent text-gray-500 hover:text-gray-700'
                    }`}
                >
                    Pending ({jobComments.filter(c => c.status === 'pending').length})
                </button>
                <button
                    onClick={() => setActiveTab('approved')}
                    className={`py-2 px-4 text-sm font-bold border-b-2 transition-colors ${
                        activeTab === 'approved' ? 'border-green-500 text-green-600' : 'border-transparent text-gray-500 hover:text-gray-700'
                    }`}
                >
                    Approved
                </button>
                <button
                    onClick={() => setActiveTab('all')}
                    className={`py-2 px-4 text-sm font-bold border-b-2 transition-colors ${
                        activeTab === 'all' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'
                    }`}
                >
                    All
                </button>
            </div>

            {/* Comments List */}
            <div className="space-y-4">
                {sortedComments.length === 0 ? (
                    <p className="text-center text-gray-400 py-10 italic">No {activeTab} comments found.</p>
                ) : (
                    sortedComments.map(comment => (
                        <div key={comment.id} className="border border-gray-200 rounded-lg p-4 bg-gray-50 hover:bg-white transition-shadow hover:shadow-md">
                            <div className="flex justify-between items-start mb-2">
                                <div>
                                    <span className="font-bold text-gray-800 mr-2">{comment.userName}</span>
                                    <span className="text-xs text-gray-500">on {getJobTitle(comment.jobId)}</span>
                                    <span className="text-[10px] text-gray-400 block">{comment.date}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    {comment.status === 'pending' && (
                                        <>
                                            <button 
                                                onClick={() => updateJobCommentStatus(comment.id, 'approved')}
                                                className="bg-green-100 text-green-600 px-3 py-1 rounded text-xs font-bold hover:bg-green-200 transition-colors"
                                            >
                                                <i className="mdi mdi-check mr-1"></i> Approve
                                            </button>
                                            <button 
                                                onClick={() => deleteJobComment(comment.id)}
                                                className="bg-red-100 text-red-600 px-3 py-1 rounded text-xs font-bold hover:bg-red-200 transition-colors"
                                            >
                                                <i className="mdi mdi-delete mr-1"></i> Delete
                                            </button>
                                        </>
                                    )}
                                    {comment.status === 'approved' && (
                                        <>
                                            <span className="bg-green-50 text-green-600 text-xs px-2 py-1 rounded border border-green-200 mr-2">Approved</span>
                                            <button 
                                                onClick={() => deleteJobComment(comment.id)}
                                                className="text-red-400 hover:text-red-600"
                                                title="Delete"
                                            >
                                                <i className="mdi mdi-delete text-lg"></i>
                                            </button>
                                        </>
                                    )}
                                </div>
                            </div>
                            <p className="text-gray-700 text-sm bg-white p-2 rounded border border-gray-100">{comment.text}</p>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

export default CommentManagementPage;