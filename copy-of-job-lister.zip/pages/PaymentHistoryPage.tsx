
import React, { useState } from 'react';
import type { PaymentTransaction } from '../types';
import PaymentDetailsModal from '../components/admin/PaymentDetailsModal';

interface PaymentHistoryPageProps {
    payments: PaymentTransaction[];
    onUpdateStatus: (id: number, status: 'approved' | 'rejected') => void;
}

const PaymentHistoryPage: React.FC<PaymentHistoryPageProps> = ({ payments, onUpdateStatus }) => {
    const [viewingPayment, setViewingPayment] = useState<PaymentTransaction | null>(null);

    // Sort payments by date descending (newest first)
    const sortedPayments = [...payments].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    const getStatusBadge = (status: string) => {
        switch (status) {
            case 'approved':
                return <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs font-bold uppercase">Approved</span>;
            case 'rejected':
                return <span className="bg-red-100 text-red-700 px-2 py-1 rounded-full text-xs font-bold uppercase">Rejected</span>;
            default:
                return <span className="bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full text-xs font-bold uppercase">Pending</span>;
        }
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <h1 className="text-2xl font-semibold text-gray-800 mb-6 flex items-center">
                <i className="mdi mdi-history mr-2 text-blue-600"></i>
                Payment History (পেমেন্ট হিস্ট্রি)
            </h1>

            <div className="overflow-x-auto">
                <table className="w-full text-left">
                    <thead>
                        <tr className="bg-gray-100 border-b">
                            <th className="p-4 font-semibold text-sm">Date</th>
                            <th className="p-4 font-semibold text-sm">User / Sender</th>
                            <th className="p-4 font-semibold text-sm">Plan</th>
                            <th className="p-4 font-semibold text-sm">Amount</th>
                            <th className="p-4 font-semibold text-sm">Method & TrxID</th>
                            <th className="p-4 font-semibold text-sm">Status</th>
                            <th className="p-4 font-semibold text-sm text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {sortedPayments.length === 0 ? (
                             <tr>
                                <td colSpan={7} className="p-8 text-center text-gray-400">
                                    No payment records found.
                                </td>
                            </tr>
                        ) : (
                            sortedPayments.map(payment => (
                                <tr key={payment.id} className="border-b hover:bg-gray-50 transition-colors">
                                    <td className="p-4 text-xs text-gray-600 whitespace-nowrap">{payment.date}</td>
                                    <td className="p-4">
                                        <div className="font-bold text-sm text-gray-800">{payment.userName}</div>
                                        <div className="text-xs text-gray-500">{payment.senderNumber}</div>
                                    </td>
                                    <td className="p-4 text-sm">{payment.planTitle}</td>
                                    <td className="p-4 font-bold text-gray-800">
                                        {payment.currency === 'BDT' ? '৳' : '$'}{payment.amount}
                                    </td>
                                    <td className="p-4">
                                        <div className="text-xs font-bold bg-gray-100 px-1 py-0.5 rounded inline-block mb-1">{payment.methodName}</div>
                                        <div className="text-xs text-blue-600 font-mono select-all cursor-pointer truncate max-w-[100px]" title={payment.trxId}>
                                            {payment.trxId}
                                        </div>
                                    </td>
                                    <td className="p-4">
                                        {getStatusBadge(payment.status)}
                                    </td>
                                    <td className="p-4 text-center">
                                        <div className="flex justify-center space-x-2">
                                            {/* View Details Button */}
                                            <button 
                                                onClick={() => setViewingPayment(payment)}
                                                className="bg-blue-100 text-blue-600 p-1.5 rounded hover:bg-blue-200 transition-colors"
                                                title="View Full Details"
                                            >
                                                <i className="mdi mdi-eye text-lg"></i>
                                            </button>

                                            {/* Quick Actions for Pending */}
                                            {payment.status === 'pending' && (
                                                <>
                                                    <button 
                                                        onClick={() => onUpdateStatus(payment.id, 'approved')}
                                                        className="bg-green-100 text-green-600 p-1.5 rounded hover:bg-green-200 transition-colors"
                                                        title="Quick Approve"
                                                    >
                                                        <i className="mdi mdi-check text-lg"></i>
                                                    </button>
                                                    <button 
                                                        onClick={() => onUpdateStatus(payment.id, 'rejected')}
                                                        className="bg-red-100 text-red-600 p-1.5 rounded hover:bg-red-200 transition-colors"
                                                        title="Quick Reject"
                                                    >
                                                        <i className="mdi mdi-close text-lg"></i>
                                                    </button>
                                                </>
                                            )}
                                        </div>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>

            {/* Details Modal */}
            <PaymentDetailsModal 
                payment={viewingPayment}
                isOpen={!!viewingPayment}
                onClose={() => setViewingPayment(null)}
                onUpdateStatus={onUpdateStatus}
            />
        </div>
    );
};

export default PaymentHistoryPage;
