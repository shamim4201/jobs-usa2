import React, { useState } from 'react';
import type { Country } from '../types';
import CountryFormModal from '../components/admin/CountryFormModal';
import DeleteConfirmationModal from '../components/admin/DeleteConfirmationModal';

interface CountryManagementPageProps {
  countries: Country[];
  onSave: (country: Country) => void;
  onDelete: (country: Country) => void;
}

const CountryManagementPage: React.FC<CountryManagementPageProps> = ({ countries, onSave, onDelete }) => {
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [editingCountry, setEditingCountry] = useState<Country | null>(null);
  const [countryToDelete, setCountryToDelete] = useState<Country | null>(null);

  const handleOpenAddModal = () => {
    setEditingCountry(null);
    setIsFormModalOpen(true);
  };

  const handleEdit = (country: Country) => {
    setEditingCountry(country);
    setIsFormModalOpen(true);
  };

  const handleOpenDeleteModal = (country: Country) => {
    setCountryToDelete(country);
  };

  const handleConfirmDelete = () => {
    if (countryToDelete) {
      onDelete(countryToDelete);
      setCountryToDelete(null);
    }
  };

  const handleCloseModal = () => {
    setIsFormModalOpen(false);
    setEditingCountry(null);
  };

  const handleSaveCountry = (countryData: Country) => {
    onSave(countryData);
    handleCloseModal();
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-semibold text-gray-800">Country Management</h1>
        <button
          onClick={handleOpenAddModal}
          className="bg-purple-500 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-600 transition-colors"
        >
          Add New Country
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-gray-100 border-b">
              <th className="p-4 font-semibold">Country Name</th>
              <th className="p-4 font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            {countries.map((country) => (
              <tr key={country.id} className="border-b hover:bg-gray-50">
                <td className="p-4">{country.name}</td>
                <td className="p-4">
                  <button onClick={() => handleEdit(country)} className="text-blue-500 hover:underline mr-4">Edit</button>
                  <button onClick={() => handleOpenDeleteModal(country)} className="text-red-500 hover:underline">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {isFormModalOpen && (
        <CountryFormModal
          country={editingCountry}
          isOpen={isFormModalOpen}
          onClose={handleCloseModal}
          onSave={handleSaveCountry}
        />
      )}
      {countryToDelete && (
        <DeleteConfirmationModal
            isOpen={!!countryToDelete}
            onClose={() => setCountryToDelete(null)}
            onConfirm={handleConfirmDelete}
            title="Confirm Country Deletion"
            message={`Are you sure you want to delete the country: "${countryToDelete.name}"? This action cannot be undone.`}
        />
      )}
    </div>
  );
};

export default CountryManagementPage;