
import React, { useState } from 'react';
import { useData } from '../context/DataContext'; 
import type { User, Page } from '../types';
import AdBanner from '../components/AdBanner';
import SiteLogo from '../components/SiteLogo';
import UserDashboardPage from './UserDashboardPage';
import SupportChatModal from '../components/SupportChatModal';

interface LoginPageProps {
  onLogin: (user: User) => void;
  onNavigate: (page: Page) => void;
  loggedInUser: User | null;
  onLogout: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin, onNavigate, loggedInUser, onLogout }) => {
  const { users, settings, countries } = useData(); 
  const [view, setView] = useState<'login' | 'forgot'>('login');
  
  // Login States
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState('');

  // Forgot Password States
  const [resetEmail, setResetEmail] = useState('');
  const [resetMessage, setResetMessage] = useState<{type: 'success' | 'error', text: string} | null>(null);
  
  // Chat Modal State
  const [showChat, setShowChat] = useState(false);
  const [targetUser, setTargetUser] = useState<User | null>(null);

  // IF USER IS LOGGED IN, SHOW DASHBOARD
  if (loggedInUser) {
      return <UserDashboardPage user={loggedInUser} onLogout={onLogout} onNavigate={onNavigate} />;
  }

  // Handle Login Submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Case insensitive email check
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    
    if (user) {
        // Check password (default 'password' if not set in DB yet)
        const userPass = user.password || 'password';

        if (password === userPass) {
             onLogin(user);
             if (rememberMe) {
                 localStorage.setItem('auth_email', email);
                 localStorage.setItem('auth_token', 'dummy_token'); // Simple persistence
             } else {
                 localStorage.removeItem('auth_email');
                 localStorage.removeItem('auth_token');
             }
             setError('');
        } else {
             setError('Invalid password');
        }
    } else {
        setError('User not found');
    }
  };

  // Handle Forgot Password Submit
  const handleForgotSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      const user = users.find(u => u.email.toLowerCase() === resetEmail.toLowerCase());

      if (user) {
          setTargetUser(user);
          setResetMessage(null);
          setShowChat(true); // Open Chat Window
      } else {
          setResetMessage({
              type: 'error',
              text: 'No account found with this email address.'
          });
      }
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center p-4 bg-transparent">
      
      {/* Logo */}
      <div className="mb-6">
         <SiteLogo className="h-20 w-auto drop-shadow-md" />
      </div>

      {settings.loginTopAdCode && (
          <div className="w-full max-w-md mb-4">
              <AdBanner code={settings.loginTopAdCode} />
          </div>
      )}

      <div className="max-w-md w-full bg-white/90 backdrop-blur-md rounded-lg shadow-xl p-8 border border-white/50">
        
        {view === 'login' ? (
            <>
                <h2 className="text-2xl font-bold text-center text-gray-800 mb-8">Login to your Account</h2>
                <form onSubmit={handleSubmit}>
                {error && <p className="bg-red-100 text-red-700 p-3 rounded mb-4 text-center border border-red-200">{error}</p>}
                <div className="mb-4">
                    <label htmlFor="email" className="block text-gray-700 text-sm font-bold mb-2">
                    Email Address
                    </label>
                    <input
                    type="email"
                    id="email"
                    name="email"
                    autoComplete="email"
                    className="shadow-sm appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="you@example.com"
                    aria-label="Email Address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    />
                </div>
                <div className="mb-2">
                    <label htmlFor="password" aria-label="Password" className="block text-gray-700 text-sm font-bold mb-2">
                    Password
                    </label>
                    <input
                    type="password"
                    id="password"
                    name="password"
                    autoComplete="current-password"
                    className="shadow-sm appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    />
                </div>

                <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center">
                        <input 
                            id="rememberMe" 
                            type="checkbox" 
                            checked={rememberMe}
                            onChange={(e) => setRememberMe(e.target.checked)}
                            className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500"
                        />
                        <label htmlFor="rememberMe" className="ml-2 text-sm font-medium text-gray-900">Remember me</label>
                    </div>
                    <button 
                        type="button"
                        onClick={() => {
                            setView('forgot');
                            setError('');
                            setResetMessage(null);
                        }}
                        className="text-sm text-blue-600 hover:text-blue-800 font-semibold"
                    >
                        Forgot Password?
                    </button>
                </div>

                <div className="flex items-center justify-between">
                    <button
                    type="submit"
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 px-4 rounded shadow-md focus:outline-none focus:shadow-outline transition-transform transform active:scale-95"
                    >
                    Sign In
                    </button>
                </div>
                </form>
                <p className="text-center text-gray-500 text-xs mt-6">
                (Default Admin: <b>admin@example.com</b> / <b>password</b>)
                </p>
                <p className="text-center text-gray-600 text-xs mt-4">
                Don't have an account?{' '}
                <button onClick={() => onNavigate('register')} className="text-blue-600 hover:text-blue-800 font-bold underline">
                    Register
                </button>
                </p>
            </>
        ) : (
            <>
                <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i className="mdi mdi-lock-reset text-3xl"></i>
                    </div>
                    <h2 className="text-2xl font-bold text-gray-800">Reset Password</h2>
                    <p className="text-sm text-gray-500 mt-2">Enter your email to receive recovery instructions.</p>
                </div>

                <form onSubmit={handleForgotSubmit}>
                    {resetMessage && (
                        <div className={`p-3 rounded mb-4 text-center border text-sm ${resetMessage.type === 'success' ? 'bg-green-100 text-green-700 border-green-200' : 'bg-red-100 text-red-700 border-red-200'}`}>
                            {resetMessage.text}
                        </div>
                    )}

                    <div className="mb-6">
                        <label htmlFor="resetEmail" className="block text-gray-700 text-sm font-bold mb-2">
                        Email Address
                        </label>
                        <input
                        type="email"
                        id="resetEmail"
                        className="shadow-sm appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Enter your registered email"
                        value={resetEmail}
                        onChange={(e) => setResetEmail(e.target.value)}
                        required
                        />
                    </div>

                    <button
                        type="submit"
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 px-4 rounded shadow-md transition-colors mb-3"
                    >
                        Send Reset Link
                    </button>
                    
                    <button
                        type="button"
                        onClick={() => setView('login')}
                        className="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold py-2.5 px-4 rounded transition-colors"
                    >
                        Back to Login
                    </button>
                </form>
            </>
        )}
      </div>

      {settings.loginBottomAdCode && (
          <div className="w-full max-w-md mt-4">
              <AdBanner code={settings.loginBottomAdCode} />
          </div>
      )}

      {/* Support Chat Modal */}
      <SupportChatModal 
        isOpen={showChat}
        onClose={() => setShowChat(false)}
        user={targetUser}
        countries={countries}
      />
    </div>
  );
};

export default LoginPage;
