
import React, { useState, useEffect, useRef } from 'react';
import { useData } from '../context/DataContext';
import type { SupportBotConfig, ChatMessage } from '../types';

const BotManagementPage: React.FC = () => {
    const { settings, updateSettings, chats, sendChatMessage, users } = useData();
    const [activeTab, setActiveTab] = useState<'livechat' | 'autobot'>('livechat');

    // --- Auto Bot States ---
    const [botConfig, setBotConfig] = useState<SupportBotConfig>({
        greeting: '', askName: '', askCountry: '', successMsg: '', errorName: '', errorCountry: ''
    });
    const [saved, setSaved] = useState(false);

    // --- Live Chat States ---
    const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
    const [replyText, setReplyText] = useState('');
    const chatEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (settings.supportBot) {
            setBotConfig(settings.supportBot);
        }
    }, [settings]);

    // Group chats by User
    const conversations = Array.from(new Set(chats.map(c => c.userId))).map(userId => {
        const userChats = chats.filter(c => c.userId === userId);
        const lastMsg = userChats[userChats.length - 1];
        // Identify User
        const user = users.find(u => u.id === userId);
        const name = user ? user.name : (lastMsg?.userName || 'Guest');
        
        return {
            userId,
            name,
            lastMessage: lastMsg.text,
            lastTime: lastMsg.timestamp,
            unread: userChats.filter(c => c.sender === 'user' && !c.isRead).length
        };
    }).sort((a, b) => new Date(b.lastTime).getTime() - new Date(a.lastTime).getTime());

    // Auto-scroll chat window
    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [selectedUserId, chats]);

    const handleBotChange = (field: keyof SupportBotConfig, value: string) => {
        setBotConfig(prev => ({ ...prev, [field]: value }));
    };

    const handleSaveBot = async () => {
        await updateSettings({ ...settings, supportBot: botConfig });
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
    };

    const handleSendReply = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!selectedUserId || !replyText.trim()) return;

        // Find user name for consistency, though not strictly needed for admin reply
        const user = users.find(u => u.id === selectedUserId);
        const userName = user ? user.name : 'Guest';

        await sendChatMessage({
            userId: selectedUserId,
            userName: userName,
            text: replyText,
            sender: 'admin'
        });
        setReplyText('');
    };

    const selectedChatMessages = selectedUserId 
        ? chats.filter(c => c.userId === selectedUserId).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
        : [];

    return (
        <div className="h-full flex flex-col">
            <h1 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <i className="mdi mdi-robot mr-2 text-purple-600"></i>
                Bot & Live Chat Management
            </h1>

            {/* Tabs */}
            <div className="flex border-b border-gray-200 mb-6">
                <button
                    onClick={() => setActiveTab('livechat')}
                    className={`py-2 px-6 font-bold text-sm border-b-2 transition-colors ${
                        activeTab === 'livechat' ? 'border-purple-600 text-purple-600' : 'border-transparent text-gray-500 hover:text-gray-700'
                    }`}
                >
                    Live Chat (সরাসরি চ্যাট)
                </button>
                <button
                    onClick={() => setActiveTab('autobot')}
                    className={`py-2 px-6 font-bold text-sm border-b-2 transition-colors ${
                        activeTab === 'autobot' ? 'border-purple-600 text-purple-600' : 'border-transparent text-gray-500 hover:text-gray-700'
                    }`}
                >
                    Auto Bot Settings (পাসওয়ার্ড বট)
                </button>
            </div>

            {/* --- LIVE CHAT TAB --- */}
            {activeTab === 'livechat' && (
                <div className="flex bg-white border border-gray-200 rounded-lg shadow-lg h-[600px] overflow-hidden">
                    {/* Sidebar: Conversation List */}
                    <div className="w-1/3 border-r border-gray-200 flex flex-col bg-gray-50">
                        <div className="p-4 border-b border-gray-200 font-bold text-gray-700">Inbox</div>
                        <div className="overflow-y-auto flex-1">
                            {conversations.length === 0 && <p className="text-center text-gray-400 p-4 text-sm">No conversations yet.</p>}
                            {conversations.map(conv => (
                                <div 
                                    key={conv.userId}
                                    onClick={() => setSelectedUserId(conv.userId)}
                                    className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-white transition-colors ${
                                        selectedUserId === conv.userId ? 'bg-white border-l-4 border-l-purple-600 shadow-sm' : ''
                                    }`}
                                >
                                    <div className="flex justify-between items-start mb-1">
                                        <h4 className="font-bold text-gray-800 text-sm">{conv.name}</h4>
                                        <span className="text-[10px] text-gray-400">{new Date(conv.lastTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                                    </div>
                                    <p className="text-xs text-gray-500 truncate">{conv.lastMessage}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Chat Area */}
                    <div className="flex-1 flex flex-col bg-white">
                        {selectedUserId ? (
                            <>
                                {/* Header */}
                                <div className="p-4 border-b border-gray-200 flex items-center justify-between bg-gray-50">
                                    <h3 className="font-bold text-gray-800">
                                        Chat with {conversations.find(c => c.userId === selectedUserId)?.name}
                                    </h3>
                                </div>

                                {/* Messages */}
                                <div className="flex-1 overflow-y-auto p-4 bg-gray-100 space-y-3">
                                    {selectedChatMessages.map(msg => (
                                        <div key={msg.id} className={`flex ${msg.sender === 'admin' ? 'justify-end' : 'justify-start'}`}>
                                            <div className={`max-w-[70%] p-3 rounded-lg text-sm shadow-sm ${
                                                msg.sender === 'admin' 
                                                ? 'bg-purple-600 text-white rounded-br-none' 
                                                : 'bg-white text-gray-800 rounded-bl-none border border-gray-200'
                                            }`}>
                                                {msg.text}
                                                <div className={`text-[10px] text-right mt-1 ${msg.sender === 'admin' ? 'text-purple-200' : 'text-gray-400'}`}>
                                                    {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                    <div ref={chatEndRef} />
                                </div>

                                {/* Reply Input */}
                                <form onSubmit={handleSendReply} className="p-4 border-t border-gray-200 bg-white">
                                    <div className="flex gap-2">
                                        <input 
                                            type="text" 
                                            value={replyText}
                                            onChange={e => setReplyText(e.target.value)}
                                            placeholder="Type a reply..." 
                                            className="flex-1 border rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                                        />
                                        <button 
                                            type="submit" 
                                            disabled={!replyText.trim()}
                                            className="bg-purple-600 text-white px-4 py-2 rounded-lg font-bold hover:bg-purple-700 transition disabled:opacity-50"
                                        >
                                            Send
                                        </button>
                                    </div>
                                </form>
                            </>
                        ) : (
                            <div className="flex-1 flex items-center justify-center text-gray-400">
                                Select a conversation to start chatting
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* --- AUTO BOT SETTINGS TAB --- */}
            {activeTab === 'autobot' && (
                <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200 max-w-3xl">
                    <h2 className="text-lg font-bold text-gray-800 mb-4 border-b pb-2 flex items-center">
                        <i className="mdi mdi-face-agent mr-2 text-blue-600"></i>
                        Password Recovery Bot Configuration
                    </h2>
                    <div className="space-y-4">
                        <div>
                            <label className="block text-gray-700 text-xs font-bold mb-1">1. Greeting Message (শুরুর কথা)</label>
                            <textarea 
                                rows={2}
                                value={botConfig.greeting}
                                onChange={(e) => handleBotChange('greeting', e.target.value)}
                                className="w-full border rounded px-3 py-2 text-sm focus:ring-2 focus:ring-purple-500 outline-none"
                            />
                        </div>
                        <div>
                            <label className="block text-gray-700 text-xs font-bold mb-1">2. Ask for Name (নাম চাওয়ার প্রশ্ন)</label>
                            <input 
                                value={botConfig.askName}
                                onChange={(e) => handleBotChange('askName', e.target.value)}
                                className="w-full border rounded px-3 py-2 text-sm focus:ring-2 focus:ring-purple-500 outline-none"
                            />
                        </div>
                        <div>
                            <label className="block text-gray-700 text-xs font-bold mb-1">3. Ask for Country (দেশ চাওয়ার প্রশ্ন)</label>
                            <input 
                                value={botConfig.askCountry}
                                onChange={(e) => handleBotChange('askCountry', e.target.value)}
                                className="w-full border rounded px-3 py-2 text-sm focus:ring-2 focus:ring-purple-500 outline-none"
                            />
                        </div>
                        <div>
                            <label className="block text-gray-700 text-xs font-bold mb-1">4. Success Message (পাসওয়ার্ড দেওয়ার আগে)</label>
                            <input 
                                value={botConfig.successMsg}
                                onChange={(e) => handleBotChange('successMsg', e.target.value)}
                                className="w-full border rounded px-3 py-2 text-sm focus:ring-2 focus:ring-purple-500 outline-none"
                            />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-red-600 text-xs font-bold mb-1">Error: Wrong Name</label>
                                <input 
                                    value={botConfig.errorName}
                                    onChange={(e) => handleBotChange('errorName', e.target.value)}
                                    className="w-full border rounded px-3 py-2 text-sm focus:ring-2 focus:ring-red-500 border-red-200 outline-none"
                                />
                            </div>
                            <div>
                                <label className="block text-red-600 text-xs font-bold mb-1">Error: Wrong Country</label>
                                <input 
                                    value={botConfig.errorCountry}
                                    onChange={(e) => handleBotChange('errorCountry', e.target.value)}
                                    className="w-full border rounded px-3 py-2 text-sm focus:ring-2 focus:ring-red-500 border-red-200 outline-none"
                                />
                            </div>
                        </div>
                    </div>
                    <div className="flex justify-end mt-6">
                        {saved && <span className="text-green-600 font-bold mr-4 text-sm animate-pulse flex items-center">Saved Successfully!</span>}
                        <button 
                            onClick={handleSaveBot}
                            className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-6 rounded shadow-md transition-colors"
                        >
                            Save Bot Settings
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default BotManagementPage;
