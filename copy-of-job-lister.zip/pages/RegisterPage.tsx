
import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import type { Page } from '../types';
import SiteLogo from '../components/SiteLogo';

interface RegisterPageProps {
  onNavigate: (page: Page) => void;
}

const RegisterPage: React.FC<RegisterPageProps> = ({ onNavigate }) => {
  const { addUser, users } = useData();
  const [accountType, setAccountType] = useState<'job_seeker' | 'employer'>('job_seeker');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (users.some(u => u.email.toLowerCase() === email.toLowerCase())) {
      setError('Email already exists');
      return;
    }

    // Add new user with selected account type
    addUser({
      id: 0, // ID is handled by context
      name,
      email,
      password, // Save password
      role: 'user',
      accountType: accountType,
      countryId: 1 // Default to first country
    });

    setSuccess(true);
    setTimeout(() => {
      onNavigate('settings'); // Redirect to login
    }, 1500);
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center p-4 bg-transparent pb-20">
      
      <div className="mb-6">
         <SiteLogo className="h-20 w-auto drop-shadow-md" />
      </div>

      <div className="max-w-md w-full bg-white/90 backdrop-blur-md rounded-lg shadow-xl p-8 border border-white/50">
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-2">Create an Account</h2>
        <p className="text-center text-gray-500 text-sm mb-6">Join us to find jobs or hire talent</p>
        
        {success ? (
          <div className="bg-green-100 text-green-700 p-4 rounded text-center mb-4 border border-green-200">
            Registration successful! Redirecting to login...
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            {error && <p className="bg-red-100 text-red-700 p-3 rounded mb-4 text-center border border-red-200">{error}</p>}
            
            {/* Account Type Selection */}
            <label className="block text-gray-700 text-sm font-bold mb-2 text-center">I want to...</label>
            <div className="grid grid-cols-2 gap-4 mb-6">
                <button
                    type="button"
                    onClick={() => setAccountType('job_seeker')}
                    className={`p-4 rounded-lg border-2 flex flex-col items-center transition-all ${
                        accountType === 'job_seeker' 
                        ? 'border-blue-500 bg-blue-50 text-blue-700 shadow-sm' 
                        : 'border-gray-200 hover:border-blue-300 text-gray-500'
                    }`}
                >
                    <i className="mdi mdi-briefcase-search text-3xl mb-1"></i>
                    <span className="font-bold text-xs">Find a Job</span>
                    <span className="text-[10px] opacity-70">(Job Seeker)</span>
                </button>

                <button
                    type="button"
                    onClick={() => setAccountType('employer')}
                    className={`p-4 rounded-lg border-2 flex flex-col items-center transition-all ${
                        accountType === 'employer' 
                        ? 'border-purple-500 bg-purple-50 text-purple-700 shadow-sm' 
                        : 'border-gray-200 hover:border-purple-300 text-gray-500'
                    }`}
                >
                    <i className="mdi mdi-bullhorn text-3xl mb-1"></i>
                    <span className="font-bold text-xs">Post Jobs/Ads</span>
                    <span className="text-[10px] opacity-70">(Employer)</span>
                </button>
            </div>

            <div className="mb-4">
              <label htmlFor="name" className="block text-gray-700 text-sm font-bold mb-2">Full Name</label>
              <input
                type="text"
                id="name"
                className="shadow-sm appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-green-500"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>

            <div className="mb-4">
              <label htmlFor="email" className="block text-gray-700 text-sm font-bold mb-2">Email Address</label>
              <input
                type="email"
                id="email"
                className="shadow-sm appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-green-500"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div className="mb-4">
              <label htmlFor="password" className="block text-gray-700 text-sm font-bold mb-2">Password</label>
              <input
                type="password"
                id="password"
                className="shadow-sm appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:ring-2 focus:ring-green-500"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            <div className="mb-6">
              <label htmlFor="confirmPassword" className="block text-gray-700 text-sm font-bold mb-2">Confirm Password</label>
              <input
                type="password"
                id="confirmPassword"
                className="shadow-sm appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:ring-2 focus:ring-green-500"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
            </div>

            <div className="flex items-center justify-between">
              <button
                type="submit"
                className={`w-full text-white font-bold py-2.5 px-4 rounded shadow-md focus:outline-none focus:shadow-outline transition-transform transform active:scale-95 ${
                    accountType === 'job_seeker' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-purple-600 hover:bg-purple-700'
                }`}
              >
                Register as {accountType === 'job_seeker' ? 'Job Seeker' : 'Employer'}
              </button>
            </div>
          </form>
        )}

        <p className="text-center text-gray-600 text-xs mt-6">
          Already have an account?{' '}
          <button onClick={() => onNavigate('settings')} className="text-blue-600 hover:text-blue-800 font-bold underline">
            Sign In
          </button>
        </p>
      </div>
    </div>
  );
};

export default RegisterPage;
