
import React, { useEffect, useState } from 'react';
import type { User, Page, UserAdRequest } from '../types';
import SiteLogo from '../components/SiteLogo';
import { useData } from '../context/DataContext';
import AdSubmissionModal from '../components/AdSubmissionModal';

interface UserDashboardPageProps {
  user: User;
  onLogout: () => void;
  onNavigate: (page: Page) => void;
}

// Helper Component for Live Countdown
const CountdownDisplay: React.FC<{ targetDate: string; compact?: boolean }> = ({ targetDate, compact }) => {
    const [timeLeft, setTimeLeft] = useState<{days: number, hours: number, minutes: number, seconds: number} | null>(null);

    useEffect(() => {
        const calculate = () => {
            const difference = new Date(targetDate).getTime() - new Date().getTime();
            if (difference > 0) {
                setTimeLeft({
                    days: Math.floor(difference / (1000 * 60 * 60 * 24)),
                    hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
                    minutes: Math.floor((difference / 1000 / 60) % 60),
                    seconds: Math.floor((difference / 1000) % 60)
                });
            } else {
                setTimeLeft(null);
            }
        };
        calculate();
        const timer = setInterval(calculate, 1000);
        return () => clearInterval(timer);
    }, [targetDate]);

    if (!timeLeft) return <span className="text-red-600 font-bold text-xs">Expired</span>;

    const pad = (n: number) => n.toString().padStart(2, '0');

    if (compact) {
        return (
             <span className="font-mono text-green-700 font-bold text-xs">
                {timeLeft.days}d {pad(timeLeft.hours)}h {pad(timeLeft.minutes)}m {pad(timeLeft.seconds)}s
             </span>
        );
    }

    return (
        <div className="flex justify-center gap-2 mt-2">
            {[
                { label: 'Days', value: timeLeft.days },
                { label: 'Hrs', value: pad(timeLeft.hours) },
                { label: 'Mins', value: pad(timeLeft.minutes) },
                { label: 'Secs', value: pad(timeLeft.seconds) },
            ].map((item, i) => (
                <div key={i} className="bg-gray-800 text-white rounded-md p-2 min-w-[50px] flex flex-col items-center shadow-lg">
                    <span className="text-xl font-bold font-mono leading-none">{item.value}</span>
                    <span className="text-[10px] uppercase text-gray-400 mt-1">{item.label}</span>
                </div>
            ))}
        </div>
    );
};

const UserDashboardPage: React.FC<UserDashboardPageProps> = ({ user: initialUser, onLogout, onNavigate }) => {
  const { users, payments, adRequests } = useData();
  const [isAdModalOpen, setIsAdModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'all' | 'approved' | 'rejected' | 'pending'>('all');
  
  // Find the fresh user object from the global state to ensure we have the latest subscription info
  const user = users.find(u => u.id === initialUser.id) || initialUser;

  const accountType = user.accountType || 'job_seeker'; 

  // Check for any pending payments for this user
  const pendingPayment = payments.find(p => p.userId === user.id && p.status === 'pending');

  const calculateDaysLeft = () => {
      if (!user.subscriptionEndDate) return 0;
      const end = new Date(user.subscriptionEndDate);
      const now = new Date();
      const diffTime = end.getTime() - now.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays > 0 ? diffDays : 0;
  };

  const daysLeft = calculateDaysLeft();
  const isActive = user.subscriptionStatus === 'active' && daysLeft > 0;
  const totalDuration = 30; // Assuming 30 days pack
  const progressPercentage = isActive ? Math.min(100, Math.max(0, (daysLeft / totalDuration) * 100)) : 0;

  // Filter Ad Requests for this user
  const myAds = adRequests.filter(req => req.userId === user.id);
  
  const getFilteredAds = () => {
      if (activeTab === 'all') return myAds;
      return myAds.filter(ad => ad.status === activeTab);
  };

  const filteredAds = getFilteredAds();
  
  // Helper to count stats
  const stats = {
      total: myAds.length,
      approved: myAds.filter(a => a.status === 'approved').length,
      rejected: myAds.filter(a => a.status === 'rejected').length,
      pending: myAds.filter(a => a.status === 'pending').length
  };

  return (
    <div className="min-h-screen bg-transparent p-4 pb-20">
      <div className="flex justify-between items-center mb-6">
         <SiteLogo className="h-10" />
         <button 
            onClick={onLogout}
            className="text-red-500 font-bold text-sm bg-white/50 px-3 py-1 rounded-full border border-red-200"
         >
             Logout
         </button>
      </div>

      <div className="bg-white/90 backdrop-blur-md rounded-2xl shadow-xl p-6 border border-white/50 text-center mb-6">
          <div className={`w-20 h-20 rounded-full mx-auto flex items-center justify-center text-white text-2xl font-bold mb-3 border-4 border-white shadow-sm ${
              accountType === 'employer' ? 'bg-gradient-to-tr from-purple-500 to-pink-500' : 'bg-gradient-to-tr from-blue-500 to-cyan-500'
          }`}>
              {user.name.charAt(0)}
          </div>
          <h1 className="text-xl font-bold text-gray-800">{user.name}</h1>
          <p className="text-gray-500 text-sm">{user.email}</p>
          <div className={`mt-2 inline-block px-3 py-0.5 rounded-full text-xs font-bold uppercase tracking-wide ${
              accountType === 'employer' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'
          }`}>
              {accountType === 'employer' ? 'Employer Account' : 'Job Seeker Account'}
          </div>
      </div>

      {/* --- EMPLOYER DASHBOARD VIEW --- */}
      {accountType === 'employer' && (
          <>
          <div className="bg-white/90 backdrop-blur-md rounded-2xl shadow-lg p-6 border border-white/50 mb-6">
              <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
                  <i className="mdi mdi-star-circle text-yellow-500 mr-2 text-2xl"></i>
                  My Subscription Plan (প্ল্যান)
              </h2>
              
              <div className={`p-4 rounded-xl border-2 mb-4 transition-colors duration-500 ${
                  isActive ? 'bg-green-50 border-green-200' : 
                  pendingPayment ? 'bg-yellow-50 border-yellow-200' : 'bg-red-50 border-red-200'
              }`}>
                  <div className="flex justify-between items-end mb-1">
                      <span className="text-xs font-bold text-gray-500 uppercase">Current Status</span>
                      {isActive ? (
                          <span className="bg-green-500 text-white text-[10px] px-2 py-0.5 rounded-full font-bold animate-pulse">ACTIVE</span>
                      ) : pendingPayment ? (
                          <span className="bg-yellow-500 text-white text-[10px] px-2 py-0.5 rounded-full font-bold">VERIFICATION PENDING</span>
                      ) : (
                          <span className="bg-red-500 text-white text-[10px] px-2 py-0.5 rounded-full font-bold">INACTIVE</span>
                      )}
                  </div>
                  
                  <p className={`text-2xl font-black ${
                      isActive ? 'text-green-700' : 
                      pendingPayment ? 'text-yellow-700' : 'text-red-700'
                  }`}>
                      {isActive ? user.subscriptionPlan : pendingPayment ? 'Payment Processing...' : 'No Active Plan'}
                  </p>

                  {/* Pending Message */}
                  {pendingPayment && !isActive && (
                      <div className="mt-2 text-xs text-yellow-800 bg-yellow-100 p-2 rounded">
                          <i className="mdi mdi-clock-outline mr-1"></i>
                          Your payment of <strong>{pendingPayment.currency === 'BDT' ? '৳' : '$'}{pendingPayment.amount}</strong> is being reviewed by admin. Please wait.
                      </div>
                  )}
                  
                  {isActive && user.subscriptionEndDate && (
                      <div className="mt-4">
                          <div className="flex justify-between text-xs text-gray-600 mb-1 font-semibold">
                              <span>Plan Duration</span>
                              <span>{Math.round(progressPercentage)}% Used</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-3 mb-4">
                              <div 
                                className="bg-green-500 h-3 rounded-full transition-all duration-1000 ease-out" 
                                style={{ width: `${progressPercentage}%` }}
                              ></div>
                          </div>

                          {/* LIVE COUNTDOWN FOR PLAN */}
                          <div className="text-center bg-white border border-green-100 rounded-lg p-3">
                              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Live Time Remaining</p>
                              <CountdownDisplay targetDate={user.subscriptionEndDate} />
                          </div>

                          <div className="flex justify-between text-[10px] text-gray-400 mt-3">
                              <span>Started: {new Date(user.subscriptionStartDate || '').toLocaleDateString()}</span>
                              <span>Ends: {new Date(user.subscriptionEndDate || '').toLocaleDateString()}</span>
                          </div>

                          {/* Post New Ad Button - Only for Active Plan */}
                          <button 
                            onClick={() => setIsAdModalOpen(true)}
                            className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold py-3 rounded-lg mt-6 shadow-md hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
                          >
                              <i className="mdi mdi-bullhorn text-xl"></i>
                              📢 Post New Ad (বিজ্ঞাপন দিন)
                          </button>
                      </div>
                  )}

                  {!isActive && !pendingPayment && (
                      <div className="mt-4">
                          <p className="text-xs text-red-600 mb-2">You need an active plan to post ads.</p>
                          <button 
                            onClick={() => onNavigate('ads-plan')}
                            className="w-full bg-purple-600 text-white py-2 rounded-lg font-bold text-sm hover:bg-purple-700 transition"
                          >
                              View Plans & Pricing
                          </button>
                      </div>
                  )}
              </div>
          </div>

          {/* --- AD MANAGER SECTION --- */}
          <div className="bg-white/90 backdrop-blur-md rounded-2xl shadow-lg p-6 border border-white/50">
              <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
                  <i className="mdi mdi-bullhorn-outline text-purple-500 mr-2 text-2xl"></i>
                  My Ads Manager
              </h2>

              {/* Stats Row */}
              <div className="grid grid-cols-3 gap-2 mb-6">
                  <div className="bg-blue-50 border border-blue-100 p-2 rounded-lg text-center">
                      <p className="text-[10px] font-bold text-gray-500 uppercase">All Ads</p>
                      <p className="text-xl font-bold text-blue-600">{stats.total}</p>
                  </div>
                  <div className="bg-green-50 border border-green-100 p-2 rounded-lg text-center">
                      <p className="text-[10px] font-bold text-gray-500 uppercase">Active</p>
                      <p className="text-xl font-bold text-green-600">{stats.approved}</p>
                  </div>
                   <div className="bg-red-50 border border-red-100 p-2 rounded-lg text-center">
                      <p className="text-[10px] font-bold text-gray-500 uppercase">Rejected</p>
                      <p className="text-xl font-bold text-red-600">{stats.rejected}</p>
                  </div>
              </div>

              {/* Tabs */}
              <div className="flex border-b border-gray-200 mb-4 overflow-x-auto">
                  <button 
                    onClick={() => setActiveTab('all')}
                    className={`py-2 px-4 text-sm font-medium whitespace-nowrap ${activeTab === 'all' ? 'text-purple-600 border-b-2 border-purple-600' : 'text-gray-500 hover:text-gray-700'}`}
                  >
                      All Ads
                  </button>
                  <button 
                    onClick={() => setActiveTab('approved')}
                    className={`py-2 px-4 text-sm font-medium whitespace-nowrap ${activeTab === 'approved' ? 'text-green-600 border-b-2 border-green-600' : 'text-gray-500 hover:text-gray-700'}`}
                  >
                      Approved
                  </button>
                  <button 
                    onClick={() => setActiveTab('pending')}
                    className={`py-2 px-4 text-sm font-medium whitespace-nowrap ${activeTab === 'pending' ? 'text-yellow-600 border-b-2 border-yellow-600' : 'text-gray-500 hover:text-gray-700'}`}
                  >
                      Pending
                  </button>
                  <button 
                    onClick={() => setActiveTab('rejected')}
                    className={`py-2 px-4 text-sm font-medium whitespace-nowrap ${activeTab === 'rejected' ? 'text-red-600 border-b-2 border-red-600' : 'text-gray-500 hover:text-gray-700'}`}
                  >
                      Rejected
                  </button>
              </div>

              {/* Ad List */}
              <div className="space-y-4">
                  {filteredAds.length === 0 ? (
                      <p className="text-center text-gray-400 py-6 italic text-sm">No ads found in this category.</p>
                  ) : (
                      filteredAds.map(ad => {
                          return (
                            <div key={ad.id} className="bg-gray-50 border border-gray-200 rounded-lg p-3 flex gap-3">
                                {/* Thumbnail */}
                                <div className="w-20 h-20 bg-gray-200 rounded-md flex-shrink-0 overflow-hidden border">
                                    <img src={ad.bannerImageDataUrl} alt={ad.title} className="w-full h-full object-cover" />
                                </div>
                                
                                {/* Content */}
                                <div className="flex-1 min-w-0">
                                    <div className="flex justify-between items-start">
                                        <h3 className="font-bold text-gray-800 text-sm truncate pr-2">{ad.title}</h3>
                                        {ad.status === 'approved' && (
                                            <span className="bg-green-100 text-green-700 text-[10px] px-2 py-0.5 rounded-full font-bold uppercase">Active</span>
                                        )}
                                        {ad.status === 'pending' && (
                                            <span className="bg-yellow-100 text-yellow-700 text-[10px] px-2 py-0.5 rounded-full font-bold uppercase">Pending</span>
                                        )}
                                        {ad.status === 'rejected' && (
                                            <span className="bg-red-100 text-red-700 text-[10px] px-2 py-0.5 rounded-full font-bold uppercase">Rejected</span>
                                        )}
                                    </div>
                                    
                                    <p className="text-[10px] text-gray-500 truncate mb-1">
                                        <a href={ad.targetUrl} target="_blank" rel="noreferrer" className="text-blue-500 hover:underline">
                                            {ad.targetUrl}
                                        </a>
                                    </p>

                                    {/* Approved Details (LIVE TIMER for AD) */}
                                    {ad.status === 'approved' && ad.endDate && (
                                        <div className="mt-2 bg-white border border-green-100 p-2 rounded text-[10px]">
                                            <div className="flex justify-between items-center mb-1">
                                                <span className="text-gray-500">Expires in:</span>
                                                <CountdownDisplay targetDate={ad.endDate} compact={true} />
                                            </div>
                                            <div className="flex justify-between text-gray-400">
                                                <span>Start: {new Date(ad.startDate!).toLocaleDateString()}</span>
                                                <span>End: {new Date(ad.endDate!).toLocaleDateString()}</span>
                                            </div>
                                        </div>
                                    )}

                                    {ad.status === 'pending' && (
                                        <p className="text-[10px] text-gray-400 mt-2 italic">Waiting for admin approval...</p>
                                    )}
                                </div>
                            </div>
                          );
                      })
                  )}
              </div>
          </div>
          </>
      )}

      {/* --- JOB SEEKER DASHBOARD VIEW --- */}
      {accountType === 'job_seeker' && (
          <div className="bg-white/90 backdrop-blur-md rounded-2xl shadow-lg p-6 border border-white/50">
              <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
                  <i className="mdi mdi-briefcase-check text-blue-500 mr-2 text-2xl"></i>
                  My Job Activity
              </h2>

              <div className="grid grid-cols-2 gap-4 mb-4">
                   <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 text-center">
                       <p className="text-xs text-gray-500 font-bold uppercase">Jobs Applied</p>
                       <p className="text-2xl font-bold text-blue-700">0</p>
                   </div>
                   <div className="bg-cyan-50 p-4 rounded-lg border border-cyan-100 text-center">
                       <p className="text-xs text-gray-500 font-bold uppercase">Saved Jobs</p>
                       <p className="text-2xl font-bold text-cyan-700">0</p>
                   </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4 text-center border border-gray-100">
                  <i className="mdi mdi-file-document-outline text-3xl text-gray-300 mb-2"></i>
                  <p className="text-sm text-gray-600 font-medium">No applications yet.</p>
                  <p className="text-xs text-gray-400 mb-4">Start applying to jobs to track them here.</p>
                  <button 
                    onClick={() => onNavigate('jobs')}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-blue-700"
                  >
                      Browse Jobs
                  </button>
              </div>
          </div>
      )}
      
      <div className="mt-6 text-center">
          <p className="text-xs text-gray-500">Member Since: {new Date(user.joinedDate || Date.now()).getFullYear()}</p>
      </div>

      <AdSubmissionModal 
        isOpen={isAdModalOpen} 
        onClose={() => setIsAdModalOpen(false)} 
        user={user} 
      />

    </div>
  );
};

export default UserDashboardPage;
