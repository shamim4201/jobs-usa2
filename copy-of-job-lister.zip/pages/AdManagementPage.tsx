
import React, { useState, useEffect } from 'react';
import { useData } from '../context/DataContext';
import type { AppSettings } from '../types';

interface AdSlotEditorProps {
    title: string;
    description: string;
    code: string;
    onSave: (code: string, interval?: number) => void;
    isLoading: boolean;
    hasInterval?: boolean;
    initialInterval?: number;
}

const AdSlotEditor: React.FC<AdSlotEditorProps> = ({ title, description, code, onSave, isLoading, hasInterval, initialInterval }) => {
    const [localCode, setLocalCode] = useState(code);
    const [localInterval, setLocalInterval] = useState(initialInterval || 3);
    const [selectedCompany, setSelectedCompany] = useState('custom');
    const [saved, setSaved] = useState(false);

    useEffect(() => {
        setLocalCode(code);
    }, [code]);

    useEffect(() => {
        if(initialInterval) setLocalInterval(initialInterval);
    }, [initialInterval]);

    const handleSave = () => {
        onSave(localCode, localInterval);
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-md mb-6 border border-gray-100 h-full flex flex-col">
            <h2 className="text-xl font-bold text-gray-800 mb-1">{title}</h2>
            <p className="text-gray-500 text-sm mb-4 min-h-[40px]">{description}</p>
            
            {hasInterval && (
                <div className="mb-4 bg-purple-50 p-4 rounded-md border border-purple-100">
                    <label className="block text-purple-700 text-sm font-bold mb-2">
                        কতগুলো জবের পর পর অ্যাড দেখাবে?
                    </label>
                    <div className="flex items-center">
                        <span className="text-sm text-gray-700 mr-2">প্রতি</span>
                        <input 
                            type="number" 
                            min="1"
                            max="50"
                            value={localInterval}
                            onChange={(e) => setLocalInterval(parseInt(e.target.value) || 3)}
                            className="w-20 border-2 border-purple-200 rounded px-2 py-1 text-center font-bold text-purple-800 focus:outline-none focus:border-purple-500"
                        />
                        <span className="text-sm text-gray-700 ml-2">টি জবের পর অ্যাডটি আসবে।</span>
                    </div>
                </div>
            )}

            <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2">বিজ্ঞাপন কোম্পানি সিলেক্ট করুন</label>
                <select 
                    value={selectedCompany} 
                    onChange={(e) => setSelectedCompany(e.target.value)}
                    className="w-full border rounded px-3 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white"
                >
                    <option value="custom">Custom Code / অন্যান্য</option>
                    <option value="adsense">Google AdSense</option>
                    <option value="admob">Google AdMob</option>
                    <option value="adsterra">Adsterra</option>
                </select>
            </div>

            <div className="mb-4 flex-grow">
                <label className="block text-gray-700 text-sm font-bold mb-2">অ্যাড কোড এখানে পেস্ট করুন (Paste Code)</label>
                <textarea
                    rows={5}
                    className="w-full border rounded px-3 py-2 text-gray-700 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 bg-gray-50 resize-y"
                    value={localCode}
                    onChange={(e) => setLocalCode(e.target.value)}
                    placeholder="<!-- আপনার বিজ্ঞাপনের কোড এখানে বসান -->"
                />
            </div>

            <div className="flex justify-end items-center mt-auto border-t pt-4">
                 {saved && <span className="text-green-600 font-bold mr-4 text-sm animate-pulse">সংরক্ষণ হয়েছে! (Saved)</span>}
                <button 
                    onClick={handleSave}
                    disabled={isLoading}
                    className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-6 rounded focus:outline-none focus:shadow-outline transition-colors disabled:opacity-50"
                >
                    {isLoading ? 'সেভ হচ্ছে...' : 'সেভ করুন (Save)'}
                </button>
            </div>
        </div>
    );
};

const AdManagementPage: React.FC = () => {
    const { settings, updateSettings, isLoading } = useData();

    const handleSave = async (key: keyof AppSettings, code: string, intervalKey?: keyof AppSettings, intervalValue?: number) => {
        const newSettings = { ...settings, [key]: code };
        if (intervalKey && intervalValue !== undefined) {
            // @ts-ignore - dynamic assignment
            newSettings[intervalKey] = intervalValue;
        }
        await updateSettings(newSettings);
    };

    return (
        <div className="h-full flex flex-col">
            <div className="mb-6">
                <h1 className="text-2xl font-bold text-gray-800">বিজ্ঞাপন ম্যানেজমেন্ট (Ad Management)</h1>
                <p className="text-gray-500">এখানে আপনি আপনার সাইটের সব বিজ্ঞাপন নিয়ন্ত্রণ করতে পারবেন।</p>
            </div>
            
            <h2 className="text-xl font-bold text-gray-800 mt-2 mb-4 pb-2 border-b border-gray-200">
                1. Advertisement Slots (বিজ্ঞাপনের জায়গা)
            </h2>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 pb-6 mb-10">
                
                {/* Home Page Section */}
                <AdSlotEditor 
                    title="হোম পেজ - সবার উপরে (Home Top)" 
                    description="হোম পেজের টাইটেলের ঠিক নিচে এই অ্যাডটি দেখাবে।" 
                    code={settings.homeTopAdCode || ''} 
                    isLoading={isLoading}
                    onSave={(code) => handleSave('homeTopAdCode', code)}
                />
                <AdSlotEditor 
                    title="হোম পেজ - মাঝখানে (Home Middle)" 
                    description="হোম পেজে প্রথম ৪টি জবের পর এই অ্যাডটি দেখাবে।" 
                    code={settings.homeMiddleAdCode || ''} 
                    isLoading={isLoading}
                    onSave={(code) => handleSave('homeMiddleAdCode', code)}
                />
                <AdSlotEditor 
                    title="হোম পেজ - সবার নিচে (Home Bottom)" 
                    description="হোম পেজের একদম শেষে এই অ্যাডটি দেখাবে।" 
                    code={settings.homeBottomAdCode || ''} 
                    isLoading={isLoading}
                    onSave={(code) => handleSave('homeBottomAdCode', code)}
                />

                {/* Jobs Page Section */}
                <AdSlotEditor 
                    title="জব পেজ - সবার উপরে (Jobs Top)" 
                    description="জব লিস্ট পেজের একদম শুরুতে দেখাবে।" 
                    code={settings.jobsTopAdCode || ''} 
                    isLoading={isLoading}
                    onSave={(code) => handleSave('jobsTopAdCode', code)}
                />
                <AdSlotEditor 
                    title="জব পেজ - রিপিটিং অ্যাড (Jobs Repeating)" 
                    description="এই অ্যাডটি জব লিস্টের মধ্যে বারবার আসবে। আপনি ঠিক করতে পারবেন কতগুলো জবের পর পর এটি দেখাবে।" 
                    code={settings.jobsMiddleAdCode || ''} 
                    isLoading={isLoading}
                    onSave={(code, interval) => handleSave('jobsMiddleAdCode', code, 'jobsAdInterval', interval)}
                    hasInterval={true}
                    initialInterval={settings.jobsAdInterval}
                />
                <AdSlotEditor 
                    title="জব পেজ - সবার নিচে (Jobs Bottom)" 
                    description="জব লিস্টের একদম শেষে দেখাবে।" 
                    code={settings.jobsBottomAdCode || ''} 
                    isLoading={isLoading}
                    onSave={(code) => handleSave('jobsBottomAdCode', code)}
                />

                {/* Invite Page Section */}
                <AdSlotEditor 
                    title="ইনভাইট পেজ - উপরে (Invite Top)" 
                    description="ইনভাইট পেজের কন্টেন্টের উপরে দেখাবে।" 
                    code={settings.inviteTopAdCode || ''} 
                    isLoading={isLoading}
                    onSave={(code) => handleSave('inviteTopAdCode', code)}
                />
                <AdSlotEditor 
                    title="ইনভাইট পেজ - নিচে (Invite Bottom)" 
                    description="ইনভাইট পেজের কন্টেন্টের নিচে দেখাবে।" 
                    code={settings.inviteBottomAdCode || ''} 
                    isLoading={isLoading}
                    onSave={(code) => handleSave('inviteBottomAdCode', code)}
                />

                {/* Login Page Section */}
                 <AdSlotEditor 
                    title="লগইন পেজ - উপরে (Login Top)" 
                    description="লগইন ফর্মের উপরে দেখাবে।" 
                    code={settings.loginTopAdCode || ''} 
                    isLoading={isLoading}
                    onSave={(code) => handleSave('loginTopAdCode', code)}
                />
                <AdSlotEditor 
                    title="লগইন পেজ - নিচে (Login Bottom)" 
                    description="লগইন ফর্মের নিচে দেখাবে।" 
                    code={settings.loginBottomAdCode || ''} 
                    isLoading={isLoading}
                    onSave={(code) => handleSave('loginBottomAdCode', code)}
                />

            </div>
        </div>
    );
};

export default AdManagementPage;
