
import React from 'react';
import { useData } from '../context/DataContext';
import JobListItem from '../components/JobListItem';
import LoadingSpinner from '../components/LoadingSpinner';
import AdBanner from '../components/AdBanner';
import SiteLogo from '../components/SiteLogo';

interface JobsPageProps {
    onJobClick: (id: number) => void;
}

const JobsPage: React.FC<JobsPageProps> = ({ onJobClick }) => {
  const { jobs, isLoading, settings } = useData();
  
  // Display newest jobs first
  const sortedJobs = [...jobs].reverse();
  
  // Default to 3 if setting is missing or 0
  const adInterval = settings.jobsAdInterval && settings.jobsAdInterval > 0 ? settings.jobsAdInterval : 3;

  return (
    <div className="min-h-screen bg-transparent">
       <header className="text-center py-4 bg-white/40 backdrop-blur-md border-b border-white/20 flex flex-col items-center sticky top-0 z-10 shadow-sm">
         <div className="mb-2">
            <SiteLogo className="h-10 w-auto" />
         </div>
         {settings.jobsTopAdCode && (
             <div className="w-full px-4 mt-2">
                 <AdBanner code={settings.jobsTopAdCode} />
             </div>
         )}
       </header>
       <main className="p-3">
        {isLoading ? (
            <LoadingSpinner />
        ) : (
            <div className="flex flex-col gap-2">
              {sortedJobs.length === 0 ? (
                  <p className="text-center text-gray-600 mt-10 bg-white/50 p-4 rounded-lg">No jobs found.</p>
              ) : (
                  sortedJobs.map((job, index) => (
                      <React.Fragment key={job.id}>
                          <JobListItem job={job} onJobClick={onJobClick} />
                          
                          {/* Insert Ad dynamically based on the interval setting */}
                          {(index + 1) % adInterval === 0 && settings.jobsMiddleAdCode && (
                              <div className="my-2">
                                  <AdBanner code={settings.jobsMiddleAdCode} />
                              </div>
                          )}
                      </React.Fragment>
                  ))
              )}
              
              {/* Bottom Ad */}
              {settings.jobsBottomAdCode && (
                  <div className="mt-4">
                      <AdBanner code={settings.jobsBottomAdCode} />
                  </div>
              )}
            </div>
        )}
       </main>
    </div>
  );
};

export default JobsPage;
