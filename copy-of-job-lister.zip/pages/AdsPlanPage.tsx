
import React from 'react';
import type { Page, User } from '../types';
import SiteLogo from '../components/SiteLogo';
import PricingPlans from '../components/PricingPlans';

interface AdsPlanPageProps {
    onNavigate: (page: Page) => void;
    user: User | null;
}

const AdsPlanPage: React.FC<AdsPlanPageProps> = ({ onNavigate, user }) => {
    return (
        <div className="min-h-screen bg-transparent p-4 pb-20">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
                <button onClick={() => onNavigate('home')} className="bg-white/50 p-2 rounded-full hover:bg-white transition">
                    <i className="mdi mdi-arrow-left text-xl text-gray-800"></i>
                </button>
                <div className="flex-1 flex justify-center">
                    <SiteLogo className="h-8" />
                </div>
                <div className="w-10"></div> {/* Spacer */}
            </div>

            <div className="text-center mb-4">
                <h1 className="text-2xl font-bold text-gray-800">Advertise With Us</h1>
                <p className="text-gray-600 text-sm mt-1">Choose a plan to post jobs or show ads on our platform.</p>
            </div>

            <PricingPlans user={user} onNavigate={onNavigate} />
        </div>
    );
};

export default AdsPlanPage;
