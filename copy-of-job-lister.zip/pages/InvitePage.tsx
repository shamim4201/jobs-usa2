
import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import AdBanner from '../components/AdBanner';
import SiteLogo from '../components/SiteLogo';

const InvitePage: React.FC = () => {
  const { settings } = useData();
  // Use URL from settings or default fallback
  const referralLink = settings.inviteReferralUrl || 'https://t.me/Porttimejobsbot';
  const [copySuccess, setCopySuccess] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(referralLink).then(() => {
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    });
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Job Opportunities',
        text: `For those who haven't got a job in the USA yet, this platform provides easy opportunities. Join here: ${referralLink}`,
        url: referralLink,
      })
      .then(() => console.log('Successful share'))
      .catch((error) => console.log('Error sharing', error));
    } else {
      handleCopy();
      alert('Referral link copied to clipboard!');
    }
  };

  return (
    <div className="min-h-screen p-4 bg-transparent">
        {settings.inviteTopAdCode && (
            <div className="mb-4">
                <AdBanner code={settings.inviteTopAdCode} />
            </div>
        )}

        <div className="max-w-md mx-auto mt-4 text-center">
            {/* Logo */}
            <div className="mx-auto flex justify-center mb-6">
                <SiteLogo className="h-24 w-auto object-contain drop-shadow-sm" />
            </div>
            
            <p className="text-gray-800 font-medium text-sm mt-2 mb-6 px-4 bg-white/30 p-2 rounded-lg backdrop-blur-sm">
            For those who haven't got a job in the USA yet, this platform provides easy opportunities. Share with your friends and benefit everyone.
            </p>
            
            <div className="bg-white/90 backdrop-blur-sm border border-white/50 rounded-lg p-4 shadow-lg">
                <div className="flex items-center justify-between bg-gray-50 p-2 rounded-md border border-gray-200">
                    <span className="text-gray-800 text-sm truncate mr-2">{referralLink}</span>
                    <button 
                    onClick={handleCopy}
                    className="bg-blue-500 text-white text-xs font-bold py-2 px-3 rounded-md hover:bg-blue-600 transition-colors flex-shrink-0"
                    >
                    {copySuccess ? 'Copied' : 'Copy'}
                    </button>
                </div>
                <button 
                onClick={handleShare}
                className="w-full bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors mt-4 shadow-md"
                >
                Invite Friends
                </button>
            </div>
        </div>

        {settings.inviteBottomAdCode && (
            <div className="mt-8">
                <AdBanner code={settings.inviteBottomAdCode} />
            </div>
        )}
    </div>
  );
};

export default InvitePage;
