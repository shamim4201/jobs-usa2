import React, { useState, useEffect } from 'react';
import type { Job } from '../../types';

interface EditJobModalProps {
    job: Job | null;
    isOpen: boolean;
    onClose: () => void;
    onSave: (job: Job) => void;
}

const EditJobModal: React.FC<EditJobModalProps> = ({ job, isOpen, onClose, onSave }) => {
    const isEditing = job !== null;
    const initialFormData: Job = {
        id: 0,
        title: '',
        description: '',
        salary: '',
        imageUrl: 'https://i.imgur.com/7bQ5b2S.png',
        company: '',
        applyUrl: '',
        clicks: 0,
        showOnHome: false
    };
    const [formData, setFormData] = useState<Job>(job || initialFormData);

    useEffect(() => {
        setFormData(job || initialFormData);
    }, [job, isOpen]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        // @ts-ignore
        const type = e.target.type;
        
        if (name === 'clicks') {
            setFormData(prev => ({ ...prev, [name]: parseInt(value, 10) || 0 }));
        } else if (type === 'checkbox') {
             // @ts-ignore
             const checked = e.target.checked;
             setFormData(prev => ({ ...prev, [name]: checked }));
        } else {
            setFormData(prev => ({ ...prev, [name]: value } as Job));
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(formData);
    };

    if (!isOpen) {
        return null;
    }

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-bold text-gray-800">{isEditing ? 'Edit Job' : 'Add New Job'}</h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-800">
                        <i className="mdi mdi-close text-2xl"></i>
                    </button>
                </div>
                <form onSubmit={handleSubmit}>
                    
                    {/* Show on Homepage Checkbox */}
                    <div className="mb-4 bg-purple-50 p-3 rounded border border-purple-100">
                        <label className="flex items-center cursor-pointer">
                            <input 
                                type="checkbox"
                                name="showOnHome"
                                checked={formData.showOnHome || false}
                                // @ts-ignore
                                onChange={handleChange}
                                className="form-checkbox h-5 w-5 text-purple-600 rounded focus:ring-purple-500"
                            />
                            <span className="ml-2 text-gray-800 font-bold text-sm">Show on Homepage (হোম পেজে দেখান)</span>
                        </label>
                        <p className="text-xs text-gray-500 mt-1 ml-7">
                            টিক দিলে এই জবটি হোম পেজে দেখা যাবে।
                        </p>
                    </div>

                    <div className="mb-4">
                        <label htmlFor="title" className="block text-gray-700 text-sm font-bold mb-2">Title</label>
                        <input
                            type="text"
                            id="title"
                            name="title"
                            value={formData.title}
                            onChange={handleChange}
                            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="company" className="block text-gray-700 text-sm font-bold mb-2">Company</label>
                        <input
                            type="text"
                            id="company"
                            name="company"
                            value={formData.company || ''}
                            onChange={handleChange}
                            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        />
                    </div>
                     <div className="mb-4">
                        <label htmlFor="salary" className="block text-gray-700 text-sm font-bold mb-2">Salary</label>
                        <input
                            type="text"
                            id="salary"
                            name="salary"
                            value={formData.salary}
                            onChange={handleChange}
                            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="imageUrl" className="block text-gray-700 text-sm font-bold mb-2">Image URL</label>
                        <input
                            type="text"
                            id="imageUrl"
                            name="imageUrl"
                            value={formData.imageUrl || ''}
                            onChange={handleChange}
                            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                            placeholder="https://example.com/image.png"
                        />
                    </div>
                     <div className="mb-4">
                        <label htmlFor="applyUrl" className="block text-gray-700 text-sm font-bold mb-2">Apply URL</label>
                        <input
                            type="text"
                            id="applyUrl"
                            name="applyUrl"
                            value={formData.applyUrl || ''}
                            onChange={handleChange}
                            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="clicks" className="block text-gray-700 text-sm font-bold mb-2">Clicks</label>
                        <input
                            type="number"
                            id="clicks"
                            name="clicks"
                            value={formData.clicks}
                            onChange={handleChange}
                            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        />
                    </div>
                    <div className="mb-6">
                        <label htmlFor="description" className="block text-gray-700 text-sm font-bold mb-2">Description</label>
                        <textarea
                            id="description"
                            name="description"
                            value={formData.description}
                            onChange={handleChange}
                            rows={4}
                            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        />
                    </div>
                    <div className="flex items-center justify-end gap-4">
                        <button
                            type="button"
                            onClick={onClose}
                            className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                        >
                            Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default EditJobModal;