import React from 'react';
import type { User } from '../../types';

interface HeaderProps {
    user: User;
    onLogout: () => void;
    onMenuButtonClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ user, onLogout, onMenuButtonClick }) => {
    return (
        <header className="flex justify-between items-center p-4 bg-white border-b-2 border-gray-200">
            <div className="flex items-center">
                <button onClick={onMenuButtonClick} className="text-gray-500 focus:outline-none lg:hidden">
                    <i className="mdi mdi-menu text-2xl"></i>
                </button>
                <div className="relative ml-4">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center">
                        <i className="mdi mdi-magnify text-gray-500"></i>
                    </span>
                    <input type="text" className="w-full pl-10 pr-4 py-2 border rounded-md" placeholder="Search..."/>
                </div>
            </div>
            <div className="flex items-center">
                {/* Live Preview Button */}
                <button 
                    onClick={() => window.open('/?page=home', '_blank')}
                    className="hidden sm:flex items-center gap-2 bg-purple-100 text-purple-700 px-3 py-1.5 rounded-full hover:bg-purple-200 transition-colors mr-2"
                    title="Open Live Preview"
                >
                    <i className="mdi mdi-eye text-lg"></i>
                    <span className="text-sm font-semibold">Live Preview</span>
                </button>

                <button className="p-2 rounded-full hover:bg-gray-200">
                  <i className="mdi mdi-bell-outline text-xl text-gray-600"></i>
                </button>
                 <button className="p-2 rounded-full hover:bg-gray-200 ml-2">
                  <i className="mdi mdi-email-outline text-xl text-gray-600"></i>
                </button>

                <div className="relative ml-4">
                    <button className="flex items-center">
                        <span className="hidden md:inline-block mr-2">{user.name}</span>
                        <img src="https://i.imgur.com/5LN5cO7.png" alt="user" className="w-8 h-8 rounded-full" />
                    </button>
                </div>
                
                 <button onClick={onLogout} className="ml-4 text-gray-500 hover:text-red-500" title="Logout">
                  <i className="mdi mdi-logout text-xl"></i>
                </button>
            </div>
        </header>
    );
};

export default Header;