
import React from 'react';

interface SidebarProps {
  currentPage: string;
  setCurrentPage: (page: string) => void;
  isSidebarOpen: boolean;
}

const NavItem: React.FC<{
    id: string;
    label: string;
    icon: string;
    currentPage: string;
    setCurrentPage: (page: string) => void;
}> = ({ id, label, icon, currentPage, setCurrentPage }) => {
    const isActive = currentPage === id;
    return (
        <li className="px-4">
            <button
                onClick={() => setCurrentPage(id)}
                className={`flex items-center w-full p-3 my-1 rounded-md text-left transition-colors ${
                    isActive
                        ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-md'
                        : 'text-gray-600 hover:bg-gray-100'
                }`}
            >
                <i className={`mdi ${icon} mr-4 text-xl`}></i>
                <span className="font-medium">{label}</span>
            </button>
        </li>
    );
};

const Sidebar: React.FC<SidebarProps> = ({ currentPage, setCurrentPage, isSidebarOpen }) => {
    const navItems = [
        { id: 'dashboard', label: 'Dashboard', icon: 'mdi-home' },
        { id: 'jobs', label: 'Job Management', icon: 'mdi-briefcase' },
        { id: 'users', label: 'User Management', icon: 'mdi-account-group' },
        { id: 'countries', label: 'Country Management', icon: 'mdi-earth' },
        { id: 'payments', label: 'Payment History', icon: 'mdi-history' }, 
        { id: 'ad-requests', label: 'Ad Requests', icon: 'mdi-file-upload-outline' }, 
        { id: 'notifications', label: 'Notifications', icon: 'mdi-bell-ring-outline' }, 
        { id: 'bot-chat', label: 'Bot / Live Chat', icon: 'mdi-robot' },
        { id: 'comments', label: 'Comments', icon: 'mdi-comment-text-multiple-outline' }, 
        { id: 'ads', label: 'Ads Management', icon: 'mdi-bullhorn-outline' },
        { id: 'plans', label: 'Plan Management', icon: 'mdi-star-circle-outline' },
        { id: 'database', label: 'Database', icon: 'mdi-database' }, // New Item
        { id: 'settings', label: 'Settings', icon: 'mdi-cog' },
    ];

    return (
        <aside className={`fixed inset-y-0 left-0 z-30 w-64 bg-white flex-shrink-0 border-r-2 border-gray-200 transform transition-transform duration-300 ease-in-out lg:static lg:translate-x-0 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
            <div className="p-4 flex items-center justify-center border-b-2 border-gray-200 h-20">
                <h1 className="text-3xl font-bold text-purple-600">Purple</h1>
            </div>
            <nav className="mt-6">
                <ul>
                    {navItems.map(item => (
                        <NavItem
                            key={item.id}
                            id={item.id}
                            label={item.label}
                            icon={item.icon}
                            currentPage={currentPage}
                            setCurrentPage={setCurrentPage}
                        />
                    ))}
                </ul>
            </nav>
        </aside>
    );
};

export default Sidebar;
