



import React from 'react';
import type { UserAdRequest } from '../../types';

interface AdRequestDetailsModalProps {
    request: UserAdRequest | null;
    isOpen: boolean;
    onClose: () => void;
    onUpdateStatus: (id: number, status: 'approved' | 'rejected') => void;
    onDelete?: (id: number) => void; // Added onDelete
}

const AdRequestDetailsModal: React.FC<AdRequestDetailsModalProps> = ({ request, isOpen, onClose, onUpdateStatus, onDelete }) => {
    if (!isOpen || !request) return null;

    const handleStatusUpdate = (status: 'approved' | 'rejected') => {
        onUpdateStatus(request.id, status);
        onClose();
    };

    const handleDelete = () => {
        if (onDelete) {
            onDelete(request.id);
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4 backdrop-blur-sm">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
                
                {/* Header */}
                <div className="bg-gray-50 border-b border-gray-200 p-6 flex justify-between items-start">
                    <div>
                        <h2 className="text-xl font-bold text-gray-800">Ad Request Details</h2>
                        <p className="text-sm text-gray-500 mt-1">Submitted on {request.submittedDate}</p>
                    </div>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors">
                        <i className="mdi mdi-close text-2xl"></i>
                    </button>
                </div>

                {/* Body - Scrollable */}
                <div className="p-6 overflow-y-auto">
                    
                    {/* Status Badge */}
                    <div className="mb-6 flex items-center justify-between bg-gray-50 p-4 rounded-lg border border-gray-100">
                        <span className="text-gray-600 font-bold text-sm uppercase">Current Status</span>
                        <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                            request.status === 'approved' ? 'bg-green-100 text-green-700' :
                            request.status === 'rejected' ? 'bg-red-100 text-red-700' :
                            'bg-yellow-100 text-yellow-700 animate-pulse'
                        }`}>
                            {request.status}
                        </span>
                    </div>

                    {/* Start/End Dates (Only if Approved) */}
                    {request.status === 'approved' && request.startDate && request.endDate && (
                         <div className="grid grid-cols-2 gap-4 mb-6">
                            <div className="bg-green-50 p-3 rounded-lg border border-green-100">
                                <label className="block text-xs font-bold text-green-700 uppercase mb-1">Start Date</label>
                                <p className="text-gray-800 font-medium text-sm">
                                    {new Date(request.startDate).toLocaleDateString()}
                                </p>
                            </div>
                            <div className="bg-green-50 p-3 rounded-lg border border-green-100">
                                <label className="block text-xs font-bold text-green-700 uppercase mb-1">End Date</label>
                                <p className="text-gray-800 font-medium text-sm">
                                    {new Date(request.endDate).toLocaleDateString()}
                                </p>
                            </div>
                        </div>
                    )}

                    {/* Details Grid */}
                    <div className="space-y-4 mb-6">
                         <div>
                            <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">User Name</label>
                            <p className="font-medium text-gray-800 flex items-center bg-gray-50 p-2 rounded">
                                <i className="mdi mdi-account-circle-outline mr-2 text-purple-500"></i>
                                {request.userName}
                            </p>
                        </div>
                        <div>
                            <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Ad Title</label>
                            <p className="font-medium text-gray-800 bg-gray-50 p-2 rounded">
                                {request.title}
                            </p>
                        </div>
                        <div>
                            <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Target URL</label>
                            <div className="bg-gray-50 p-2 rounded flex items-center justify-between">
                                <a href={request.targetUrl} target="_blank" rel="noreferrer" className="text-blue-600 hover:underline text-sm truncate max-w-[80%]">
                                    {request.targetUrl}
                                </a>
                                <a href={request.targetUrl} target="_blank" rel="noreferrer" className="text-gray-500 hover:text-blue-600">
                                    <i className="mdi mdi-open-in-new"></i>
                                </a>
                            </div>
                        </div>
                        {request.description && (
                            <div>
                                <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Description</label>
                                <p className="text-sm text-gray-600 bg-gray-50 p-2 rounded">
                                    {request.description}
                                </p>
                            </div>
                        )}
                    </div>

                    {/* Banner Image */}
                    <div className="mb-6">
                        <label className="block text-xs font-semibold text-gray-500 uppercase mb-2">Banner Image</label>
                        <div className="bg-gray-100 border rounded-lg p-2 flex justify-center">
                             <img 
                                src={request.bannerImageDataUrl} 
                                alt="Ad Banner" 
                                className="max-h-60 max-w-full object-contain rounded"
                            />
                        </div>
                         <div className="text-center mt-2">
                             <a 
                                href={request.bannerImageDataUrl} 
                                download={`ad-banner-${request.id}.png`}
                                className="text-blue-500 hover:text-blue-700 text-xs font-bold flex items-center justify-center"
                            >
                                <i className="mdi mdi-download mr-1"></i> Download Image
                            </a>
                        </div>
                    </div>

                    {/* Actions */}
                    {request.status === 'pending' && (
                        <div className="grid grid-cols-2 gap-4">
                            <button 
                                onClick={() => handleStatusUpdate('rejected')}
                                className="w-full border border-red-500 text-red-500 hover:bg-red-50 font-bold py-3 rounded-lg transition-colors"
                            >
                                Reject
                            </button>
                            <button 
                                onClick={() => handleStatusUpdate('approved')}
                                className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 rounded-lg shadow-md transition-colors"
                            >
                                Approve (Start 30 Days)
                            </button>
                        </div>
                    )}
                    
                    {request.status !== 'pending' && (
                        <div className="flex gap-4">
                            <button 
                                onClick={handleDelete}
                                className="flex-1 bg-red-100 text-red-600 hover:bg-red-200 font-bold py-3 rounded-lg transition-colors"
                            >
                                <i className="mdi mdi-delete mr-1"></i> Delete
                            </button>
                            <button 
                                onClick={onClose}
                                className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 rounded-lg transition-colors"
                            >
                                Close
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default AdRequestDetailsModal;