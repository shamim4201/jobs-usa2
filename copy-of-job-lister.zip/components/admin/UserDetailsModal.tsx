import React from 'react';
import type { User, Country } from '../../types';

interface UserDetailsModalProps {
    user: User | null;
    countries: Country[];
    isOpen: boolean;
    onClose: () => void;
}

const UserDetailsModal: React.FC<UserDetailsModalProps> = ({ user, countries, isOpen, onClose }) => {
    if (!isOpen || !user) {
        return null;
    }

    const getCountryName = (countryId: number) => {
        const country = countries.find(c => c.id === countryId);
        return country ? `${country.flag} ${country.name}` : 'Unknown Country';
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4 backdrop-blur-sm">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden transform transition-all scale-100">
                
                {/* Header with gradient background */}
                <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-6 flex justify-between items-start">
                    <div className="flex items-center space-x-4">
                        <div className="bg-white p-1 rounded-full">
                             <img 
                                src="https://i.imgur.com/5LN5cO7.png" 
                                alt="User Avatar" 
                                className="w-16 h-16 rounded-full border-2 border-white"
                             />
                        </div>
                        <div className="text-white">
                            <h2 className="text-2xl font-bold">{user.name}</h2>
                            <p className="opacity-90 text-sm flex items-center">
                                <span className={`inline-block w-2 h-2 rounded-full mr-2 ${user.role === 'admin' ? 'bg-yellow-400' : 'bg-green-400'}`}></span>
                                {user.role.toUpperCase()}
                            </p>
                        </div>
                    </div>
                    <button 
                        onClick={onClose} 
                        className="text-white hover:bg-white/20 rounded-full p-1 transition-colors"
                        aria-label="Close"
                    >
                        <i className="mdi mdi-close text-2xl"></i>
                    </button>
                </div>

                {/* Body Content */}
                <div className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        
                        {/* Email */}
                        <div className="bg-gray-50 p-3 rounded-lg border border-gray-100">
                            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">
                                Email Address
                            </label>
                            <div className="flex items-center text-gray-800 font-medium">
                                <i className="mdi mdi-email-outline mr-2 text-blue-500"></i>
                                <span className="truncate" title={user.email}>{user.email}</span>
                            </div>
                        </div>

                        {/* Country */}
                        <div className="bg-gray-50 p-3 rounded-lg border border-gray-100">
                            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">
                                Country
                            </label>
                            <div className="flex items-center text-gray-800 font-medium">
                                <i className="mdi mdi-map-marker-outline mr-2 text-red-500"></i>
                                <span>{getCountryName(user.countryId)}</span>
                            </div>
                        </div>

                         {/* Joined Date */}
                         <div className="bg-gray-50 p-3 rounded-lg border border-gray-100">
                            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">
                                Joined Date
                            </label>
                            <div className="flex items-center text-gray-800 font-medium">
                                <i className="mdi mdi-calendar-clock mr-2 text-green-500"></i>
                                <span>{user.joinedDate || 'N/A'}</span>
                            </div>
                        </div>

                        {/* User ID */}
                        <div className="bg-gray-50 p-3 rounded-lg border border-gray-100">
                            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">
                                User ID
                            </label>
                            <div className="flex items-center text-gray-800 font-medium">
                                <i className="mdi mdi-identifier mr-2 text-purple-500"></i>
                                <span>#{user.id}</span>
                            </div>
                        </div>

                    </div>
                    
                    <div className="mt-8 flex justify-end">
                        <button
                            onClick={onClose}
                            className="bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold py-2 px-6 rounded-lg transition-colors border border-gray-300"
                        >
                            Close
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default UserDetailsModal;