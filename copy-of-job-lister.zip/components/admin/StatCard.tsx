import React from 'react';

interface StatCardProps {
    title: string;
    value: string;
    gradient: string;
    icon: string;
    onClick?: () => void;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, gradient, icon, onClick }) => {
    const Wrapper = onClick ? 'button' : 'div';
    
    return (
        <Wrapper
            onClick={onClick}
            className={`p-6 rounded-lg text-white shadow-lg ${gradient} flex items-center w-full text-left ${onClick ? 'cursor-pointer hover:opacity-90 transition-opacity' : ''}`}
        >
            <div className="flex-shrink-0">
                <i className={`mdi ${icon} text-4xl opacity-75`}></i>
            </div>
            <div className="ml-4">
                <h4 className="text-sm font-medium uppercase tracking-wider">{title}</h4>
                <p className="text-3xl font-bold">{value}</p>
            </div>
        </Wrapper>
    );
};

export default StatCard;