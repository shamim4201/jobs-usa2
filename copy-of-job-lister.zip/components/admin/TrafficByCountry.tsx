import React from 'react';

// This assumes you might create a shared types file or just use the one from data
interface TrafficData {
  country: string;
  flag: string;
  visitors: number;
  percentage: number;
}

interface TrafficByCountryProps {
    data: TrafficData[];
}

const TrafficByCountry: React.FC<TrafficByCountryProps> = ({ data }) => {
    return (
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Traffic by Country</h2>
            <div className="space-y-4">
                {data.map((item, index) => (
                    <div key={index}>
                        <div className="flex justify-between items-center mb-1">
                            <span className="text-gray-600">{item.flag} {item.country}</span>
                            <span className="text-gray-800 font-medium">{item.visitors.toLocaleString()}</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                            <div className="bg-blue-500 h-2.5 rounded-full" style={{ width: `${item.percentage}%` }}></div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default TrafficByCountry;
