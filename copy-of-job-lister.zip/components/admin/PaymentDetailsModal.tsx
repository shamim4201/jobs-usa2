
import React from 'react';
import type { PaymentTransaction } from '../../types';

interface PaymentDetailsModalProps {
    payment: PaymentTransaction | null;
    isOpen: boolean;
    onClose: () => void;
    onUpdateStatus: (id: number, status: 'approved' | 'rejected') => void;
}

const PaymentDetailsModal: React.FC<PaymentDetailsModalProps> = ({ payment, isOpen, onClose, onUpdateStatus }) => {
    if (!isOpen || !payment) return null;

    const handleStatusUpdate = (status: 'approved' | 'rejected') => {
        onUpdateStatus(payment.id, status);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4 backdrop-blur-sm">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden animate-fade-in-up max-h-[90vh] flex flex-col">
                
                {/* Header */}
                <div className="bg-gray-50 border-b border-gray-200 p-6 flex justify-between items-start flex-shrink-0">
                    <div>
                        <h2 className="text-xl font-bold text-gray-800">Payment Details</h2>
                        <p className="text-sm text-gray-500 mt-1">Transaction #{payment.trxId}</p>
                    </div>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors">
                        <i className="mdi mdi-close text-2xl"></i>
                    </button>
                </div>

                {/* Body - Scrollable */}
                <div className="p-6 overflow-y-auto">
                    {/* Amount Card */}
                    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-100 rounded-lg p-4 mb-6 flex justify-between items-center">
                        <div>
                            <p className="text-xs font-bold text-blue-500 uppercase tracking-wide">Total Amount</p>
                            <p className="text-3xl font-bold text-blue-700">
                                {payment.currency === 'BDT' ? '৳' : '$'}{payment.amount}
                            </p>
                        </div>
                        <div className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                            payment.status === 'approved' ? 'bg-green-200 text-green-800' :
                            payment.status === 'rejected' ? 'bg-red-200 text-red-800' :
                            'bg-yellow-200 text-yellow-800'
                        }`}>
                            {payment.status}
                        </div>
                    </div>

                    {/* Details Grid */}
                    <div className="grid grid-cols-2 gap-6 mb-6">
                        <div>
                            <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">User Name</label>
                            <p className="font-medium text-gray-800 flex items-center">
                                <i className="mdi mdi-account-circle-outline mr-2 text-gray-400"></i>
                                {payment.userName}
                            </p>
                        </div>
                        <div>
                            <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Plan</label>
                            <p className="font-medium text-gray-800 flex items-center">
                                <i className="mdi mdi-star-circle-outline mr-2 text-purple-500"></i>
                                {payment.planTitle}
                            </p>
                        </div>
                        <div>
                            <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Payment Method</label>
                            <p className="font-medium text-gray-800 flex items-center">
                                <i className="mdi mdi-wallet-outline mr-2 text-gray-400"></i>
                                {payment.methodName}
                            </p>
                        </div>
                        <div>
                            <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Date</label>
                            <p className="font-medium text-gray-800 flex items-center">
                                <i className="mdi mdi-calendar-clock mr-2 text-gray-400"></i>
                                {payment.date}
                            </p>
                        </div>
                    </div>

                    {/* Sender & TrxID */}
                    <div className="bg-gray-50 rounded-lg p-4 border border-gray-100 mb-6 space-y-3">
                        <div>
                            <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Sender Number / ID</label>
                            <div className="flex items-center justify-between bg-white border border-gray-200 rounded px-3 py-2">
                                <span className="font-mono text-gray-800 font-bold">{payment.senderNumber}</span>
                                <button 
                                    onClick={() => navigator.clipboard.writeText(payment.senderNumber)}
                                    className="text-blue-500 hover:text-blue-700 text-xs font-bold uppercase"
                                >
                                    Copy
                                </button>
                            </div>
                        </div>
                        <div>
                            <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Transaction ID (TrxID)</label>
                            <div className="flex items-center justify-between bg-white border border-gray-200 rounded px-3 py-2">
                                <span className="font-mono text-gray-800 font-bold">{payment.trxId}</span>
                                <button 
                                    onClick={() => navigator.clipboard.writeText(payment.trxId)}
                                    className="text-blue-500 hover:text-blue-700 text-xs font-bold uppercase"
                                >
                                    Copy
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* Screenshot Section */}
                    <div className="mb-6">
                        <label className="block text-xs font-semibold text-gray-500 uppercase mb-2">Screenshot Proof</label>
                        <div className="bg-gray-100 border-2 border-dashed border-gray-300 rounded-lg p-4 flex flex-col items-center justify-center text-center">
                            {payment.screenshotDataUrl ? (
                                <div className="w-full">
                                    <img 
                                        src={payment.screenshotDataUrl} 
                                        alt="Payment Proof" 
                                        className="max-w-full max-h-64 object-contain rounded border border-gray-200 mx-auto cursor-pointer"
                                        onClick={() => window.open(payment.screenshotDataUrl, '_blank')}
                                        title="Click to view full size"
                                    />
                                    <p className="text-xs text-gray-500 mt-2">Click image to open in new tab</p>
                                </div>
                            ) : payment.screenshotName ? (
                                <>
                                    <i className="mdi mdi-image-broken text-4xl text-gray-400 mb-2"></i>
                                    <p className="text-sm font-medium text-gray-700">Image not available</p>
                                    <p className="text-xs text-gray-500 mt-1">Filename: {payment.screenshotName}</p>
                                </>
                            ) : (
                                <p className="text-gray-400 text-sm italic">No screenshot uploaded</p>
                            )}
                        </div>
                    </div>

                    {/* Actions */}
                    {payment.status === 'pending' && (
                        <div className="grid grid-cols-2 gap-4">
                            <button 
                                onClick={() => handleStatusUpdate('rejected')}
                                className="w-full border border-red-500 text-red-500 hover:bg-red-50 font-bold py-3 rounded-lg transition-colors"
                            >
                                Reject Payment
                            </button>
                            <button 
                                onClick={() => handleStatusUpdate('approved')}
                                className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 rounded-lg shadow-md transition-colors"
                            >
                                Approve Payment
                            </button>
                        </div>
                    )}
                    
                    {payment.status !== 'pending' && (
                        <button 
                            onClick={onClose}
                            className="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 rounded-lg transition-colors"
                        >
                            Close Details
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};

export default PaymentDetailsModal;
