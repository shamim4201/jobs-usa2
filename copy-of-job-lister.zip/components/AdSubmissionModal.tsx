
import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import type { User } from '../types';

interface AdSubmissionModalProps {
    isOpen: boolean;
    onClose: () => void;
    user: User;
}

const AdSubmissionModal: React.FC<AdSubmissionModalProps> = ({ isOpen, onClose, user }) => {
    const { submitAdRequest } = useData();
    const [title, setTitle] = useState('');
    const [targetUrl, setTargetUrl] = useState('');
    const [description, setDescription] = useState('');
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [step, setStep] = useState<'form' | 'success'>('form');

    if (!isOpen) return null;

    const convertFileToBase64 = (file: File): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = error => reject(error);
        });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        
        if (!imageFile) {
            alert('Please upload an ad banner image.');
            return;
        }

        setIsSubmitting(true);
        try {
            const base64Image = await convertFileToBase64(imageFile);
            
            await submitAdRequest({
                userId: user.id,
                userName: user.name,
                title,
                targetUrl,
                description,
                bannerImageName: imageFile.name,
                bannerImageDataUrl: base64Image,
            });

            setStep('success');
        } catch (error) {
            console.error(error);
            alert('Error uploading ad. Please try again.');
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4 backdrop-blur-sm">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden relative">
                
                <div className="bg-purple-50 border-b border-purple-100 p-4 flex justify-between items-center">
                    <h2 className="text-lg font-bold text-gray-800">
                        {step === 'success' ? 'Ad Submitted!' : 'Post New Ad'}
                    </h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
                        <i className="mdi mdi-close text-2xl"></i>
                    </button>
                </div>

                <div className="p-6">
                    {step === 'form' ? (
                        <form onSubmit={handleSubmit}>
                            <div className="mb-4">
                                <label className="block text-gray-700 text-xs font-bold mb-1">Ad Title (বিজ্ঞাপনের নাম)</label>
                                <input 
                                    type="text" 
                                    required
                                    value={title}
                                    onChange={e => setTitle(e.target.value)}
                                    className="w-full border rounded px-3 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-purple-500"
                                    placeholder="e.g. Special Discount 50%"
                                />
                            </div>

                            <div className="mb-4">
                                <label className="block text-gray-700 text-xs font-bold mb-1">Target Link (যে লিংকে যাবে)</label>
                                <input 
                                    type="url" 
                                    required
                                    value={targetUrl}
                                    onChange={e => setTargetUrl(e.target.value)}
                                    className="w-full border rounded px-3 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-purple-500"
                                    placeholder="https://yourwebsite.com"
                                />
                            </div>

                            <div className="mb-4">
                                <label className="block text-gray-700 text-xs font-bold mb-1">Description (Optional)</label>
                                <textarea 
                                    value={description}
                                    onChange={e => setDescription(e.target.value)}
                                    rows={2}
                                    className="w-full border rounded px-3 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-purple-500"
                                    placeholder="Short details about the ad..."
                                />
                            </div>

                            <div className="mb-6">
                                <label className="block text-gray-700 text-xs font-bold mb-1">
                                    Ad Banner Image (ব্যানার ছবি)
                                </label>
                                {!imageFile ? (
                                    <label className="cursor-pointer mt-1 flex flex-col items-center justify-center px-4 py-8 border-2 border-gray-300 border-dashed rounded-lg hover:bg-gray-50 hover:border-purple-400 transition-colors bg-gray-50 w-full">
                                        <i className="mdi mdi-image-plus text-3xl text-gray-400 mb-2"></i>
                                        <div className="text-sm text-purple-600 font-semibold mb-1">Click to Upload Banner</div>
                                        <input 
                                            type="file" 
                                            className="hidden" 
                                            accept="image/*" 
                                            onChange={(e) => {
                                                if (e.target.files && e.target.files[0]) {
                                                    setImageFile(e.target.files[0]);
                                                }
                                            }} 
                                        />
                                    </label>
                                ) : (
                                    <div className="mt-1 flex items-center justify-between bg-white px-4 py-3 rounded border border-purple-200 shadow-sm">
                                        <div className="flex items-center overflow-hidden">
                                            <i className="mdi mdi-file-image text-purple-500 text-2xl mr-3"></i>
                                            <span className="text-sm font-semibold text-gray-700 truncate max-w-[150px]">{imageFile.name}</span>
                                        </div>
                                        <button 
                                            type="button" 
                                            onClick={() => setImageFile(null)}
                                            className="text-red-500 hover:text-red-700 p-2"
                                        >
                                            <i className="mdi mdi-delete text-xl"></i>
                                        </button>
                                    </div>
                                )}
                            </div>

                            <button 
                                type="submit" 
                                disabled={isSubmitting}
                                className="w-full bg-purple-600 text-white font-bold py-3 rounded-lg hover:bg-purple-700 transition-colors shadow-md disabled:opacity-50"
                            >
                                {isSubmitting ? 'Submitting...' : 'Submit Ad Request'}
                            </button>
                        </form>
                    ) : (
                        <div className="text-center py-6">
                            <div className="w-20 h-20 bg-green-100 text-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                                <i className="mdi mdi-check-circle text-5xl"></i>
                            </div>
                            <h3 className="text-xl font-bold text-gray-800 mb-2">Ad Request Sent!</h3>
                            <p className="text-gray-600 text-sm mb-6">
                                Admin will review your ad and approve it shortly. You can check the status here later.
                            </p>
                            <button 
                                onClick={onClose}
                                className="w-full bg-gray-900 text-white font-bold py-3 px-6 rounded-lg hover:bg-gray-800 transition-colors"
                            >
                                Close
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default AdSubmissionModal;
