import React from 'react';

const JobCard: React.FC = () => {
  return null;
};

export default JobCard;