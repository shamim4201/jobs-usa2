import React, { useEffect } from 'react';
import { useData } from '../context/DataContext';

const GoogleAnalytics: React.FC = () => {
    const { settings } = useData();
    
    useEffect(() => {
        const gaId = settings.googleAnalyticsId;
        
        if (gaId && !window.document.getElementById('google-analytics-script')) {
            // Create script 1: Async loader
            const script1 = document.createElement('script');
            script1.id = 'google-analytics-script';
            script1.async = true;
            script1.src = `https://www.googletagmanager.com/gtag/js?id=${gaId}`;
            
            // Create script 2: Config
            const script2 = document.createElement('script');
            script2.id = 'google-analytics-config';
            script2.innerHTML = `
                window.dataLayer = window.dataLayer || [];
                function gtag(){dataLayer.push(arguments);}
                gtag('js', new Date());
                gtag('config', '${gaId}');
            `;

            document.head.appendChild(script1);
            document.head.appendChild(script2);
            
            console.log(`Google Analytics initialized with ID: ${gaId}`);
        }
    }, [settings.googleAnalyticsId]);

    return null;
};

export default GoogleAnalytics;