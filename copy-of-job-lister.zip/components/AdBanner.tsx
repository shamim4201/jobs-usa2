
import React, { useEffect, useRef } from 'react';

interface AdBannerProps {
    code: string;
    label?: string;
}

const AdBanner: React.FC<AdBannerProps> = ({ code, label }) => {
    const containerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (!code || !containerRef.current) return;

        // Clear previous content
        const container = containerRef.current;
        container.innerHTML = '';

        // Create a wrapper for safety
        const wrapper = document.createElement('div');
        wrapper.innerHTML = code;

        // Append non-script elements
        Array.from(wrapper.childNodes).forEach(node => {
            if (node.nodeName !== 'SCRIPT') {
                container.appendChild(node.cloneNode(true));
            }
        });

        // Re-create scripts to ensure they execute
        const scripts = wrapper.getElementsByTagName('script');
        Array.from(scripts).forEach(oldScript => {
            const newScript = document.createElement('script');
            // Copy attributes (src, async, type, etc.)
            Array.from(oldScript.attributes).forEach(attr => {
                newScript.setAttribute(attr.name, attr.value);
            });
            // Copy content
            newScript.appendChild(document.createTextNode(oldScript.innerHTML));
            container.appendChild(newScript);
        });

    }, [code]);

    if (!code) return null;

    return (
        <div className="my-4 w-full flex flex-col items-center">
            {label && <div className="text-xs text-gray-400 mb-1 uppercase tracking-wide">{label}</div>}
            <div 
                ref={containerRef} 
                className="w-full overflow-hidden flex justify-center bg-gray-50 min-h-[50px] border border-dashed border-gray-200"
            >
                {/* Ad content will be injected here */}
            </div>
        </div>
    );
};

export default AdBanner;
