
import React, { useEffect } from 'react';
import { useData } from '../context/DataContext';

const SeoUpdater: React.FC = () => {
    const { settings } = useData();

    useEffect(() => {
        // Update Document Title
        if (settings.seoTitle) {
            document.title = settings.seoTitle;
        } else if (settings.siteTitle) {
            document.title = settings.siteTitle;
        }

        // Helper to update or create meta tags
        const updateMeta = (name: string, content: string) => {
            if (!content) return;
            let element = document.querySelector(`meta[name="${name}"]`);
            if (!element) {
                element = document.createElement('meta');
                element.setAttribute('name', name);
                document.head.appendChild(element);
            }
            element.setAttribute('content', content);
        };

        // Update Description
        if (settings.seoDescription) {
            updateMeta('description', settings.seoDescription);
        }

        // Update Keywords
        if (settings.seoKeywords) {
            updateMeta('keywords', settings.seoKeywords);
        }

    }, [settings.seoTitle, settings.seoDescription, settings.seoKeywords, settings.siteTitle]);

    return null;
};

export default SeoUpdater;
