
import React, { useState, useEffect, useRef } from 'react';
import type { User, Country } from '../types';
import { useData } from '../context/DataContext';

interface SupportChatModalProps {
    isOpen: boolean;
    onClose: () => void;
    user: User | null;
    countries: Country[];
}

interface Message {
    id: number;
    text: string;
    sender: 'bot' | 'user';
}

const SupportChatModal: React.FC<SupportChatModalProps> = ({ isOpen, onClose, user, countries }) => {
    const { settings } = useData();
    const [messages, setMessages] = useState<Message[]>([]);
    const [inputText, setInputText] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const [step, setStep] = useState<'greet' | 'name' | 'country' | 'reveal' | 'fail'>('greet');

    // Default Fallback Messages (if settings are empty)
    const botMsg = settings.supportBot || {
        greeting: "Hello! Welcome to Support. I can help recover your password. For security, please verify your identity.",
        askName: "First, please type your **Full Name** exactly as registered.",
        askCountry: "✅ Name verified! Now, please tell me your **Country** name.",
        successMsg: "✅ Identity Verified! Here is your password:",
        errorName: "❌ Incorrect name. Please try again or check your spelling.",
        errorCountry: "❌ Incorrect country. Please try again."
    };

    useEffect(() => {
        if (isOpen && user) {
            setStep('name');
            setMessages([
                { id: 1, text: botMsg.greeting, sender: 'bot' },
                { id: 2, text: botMsg.askName, sender: 'bot' }
            ]);
        } else {
            setMessages([]); // Reset on close
            setStep('greet');
        }
    }, [isOpen, user, botMsg.greeting, botMsg.askName]);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages, isTyping]);

    const handleSend = (e: React.FormEvent) => {
        e.preventDefault();
        if (!inputText.trim()) return;

        const userInput = inputText.trim();
        const userMsg: Message = { id: Date.now(), text: userInput, sender: 'user' };
        setMessages(prev => [...prev, userMsg]);
        setInputText('');
        setIsTyping(true);

        // Process Bot Response
        setTimeout(() => {
            let replyText = "";
            let nextStep = step;

            if (step === 'name') {
                if (user && userInput.toLowerCase() === user.name.toLowerCase()) {
                    replyText = botMsg.askCountry;
                    nextStep = 'country';
                } else {
                    replyText = botMsg.errorName;
                }
            } else if (step === 'country') {
                const userCountry = countries.find(c => c.id === user?.countryId)?.name || '';
                
                if (user && userCountry && userInput.toLowerCase() === userCountry.toLowerCase()) {
                    replyText = `${botMsg.successMsg} **${user.password || 'password'}**`;
                    nextStep = 'reveal';
                } else {
                    replyText = botMsg.errorCountry;
                }
            } else if (step === 'reveal') {
                replyText = "Is there anything else I can help you with?";
            }

            const botMsgResponse: Message = { id: Date.now() + 1, text: replyText, sender: 'bot' };
            setMessages(prev => [...prev, botMsgResponse]);
            setStep(nextStep);
            setIsTyping(false);

        }, 1500);
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4 backdrop-blur-sm">
            <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl overflow-hidden flex flex-col h-[500px] animate-fade-in-up">
                {/* Header */}
                <div className="bg-blue-600 p-4 flex justify-between items-center text-white shadow-md z-10">
                    <div className="flex items-center gap-3">
                        <div className="relative">
                            <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-inner">
                                <i className="mdi mdi-face-agent text-blue-600 text-2xl"></i>
                            </div>
                            <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-400 border-2 border-white rounded-full animate-pulse"></span>
                        </div>
                        <div>
                            <h3 className="font-bold text-sm">Security Support</h3>
                            <p className="text-xs opacity-90">Verification Required</p>
                        </div>
                    </div>
                    <button onClick={onClose} className="hover:bg-white/20 p-1 rounded-full transition text-white">
                        <i className="mdi mdi-close text-xl"></i>
                    </button>
                </div>

                {/* Chat Area */}
                <div className="flex-1 bg-gray-100 p-4 overflow-y-auto">
                    <p className="text-center text-xs text-gray-400 mb-4">Today</p>
                    {messages.map((msg) => (
                        <div key={msg.id} className={`flex mb-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                            {msg.sender === 'bot' && (
                                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-2 flex-shrink-0 border border-blue-200">
                                    <i className="mdi mdi-robot text-blue-600 text-sm"></i>
                                </div>
                            )}
                            <div className={`max-w-[80%] p-3 rounded-2xl text-sm leading-relaxed shadow-sm whitespace-pre-wrap ${
                                msg.sender === 'user' 
                                ? 'bg-blue-600 text-white rounded-br-none' 
                                : 'bg-white text-gray-800 border border-gray-200 rounded-bl-none'
                            }`}>
                                {msg.text}
                            </div>
                        </div>
                    ))}
                    {isTyping && (
                        <div className="flex justify-start mb-3">
                             <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-2 flex-shrink-0 border border-blue-200">
                                <i className="mdi mdi-robot text-blue-600 text-sm"></i>
                            </div>
                            <div className="bg-white border border-gray-200 p-3 rounded-2xl rounded-bl-none shadow-sm flex gap-1 items-center h-10">
                                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></span>
                                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></span>
                                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.4s'}}></span>
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>

                {/* Input Area */}
                <form onSubmit={handleSend} className="p-3 bg-white border-t border-gray-200 flex gap-2">
                    <input 
                        type="text" 
                        value={inputText}
                        onChange={(e) => setInputText(e.target.value)}
                        placeholder={step === 'reveal' ? "Thank you!" : "Type your answer..."} 
                        className="flex-1 bg-gray-100 border-0 rounded-full px-4 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all outline-none"
                    />
                    <button 
                        type="submit" 
                        disabled={!inputText.trim()}
                        className="bg-blue-600 text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-blue-700 transition disabled:opacity-50 disabled:cursor-not-allowed shadow-md"
                    >
                        <i className="mdi mdi-send"></i>
                    </button>
                </form>
            </div>
        </div>
    );
};

export default SupportChatModal;
