




import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import PaymentModal from './PaymentModal';
import type { PricingPlan, User, Page } from '../types';

interface PricingPlansProps {
    user?: User | null;
    onNavigate?: (page: Page) => void;
}

const PricingPlans: React.FC<PricingPlansProps> = ({ user, onNavigate }) => {
    const { settings } = useData();
    const [isPaymentOpen, setIsPaymentOpen] = useState(false);
    const [selectedPlan, setSelectedPlan] = useState<PricingPlan | null>(null);
    const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');

    // Fallback defaults if settings are somehow empty during load
    const freePlan = settings.freePlan || {
        title: 'Free', price: '$0', unit: '/mo', features: ['Basic Access'], buttonText: 'Current', buttonLink: '#'
    };
    
    const premiumPlan = settings.premiumPlan || {
        title: 'Premium', price: '$8', unit: '/mo', features: ['Full Access'], buttonText: 'Subscribe', buttonLink: '#', isPopular: true
    };
    
    // Labels
    const monthLabel = settings.billingCycleMonthLabel || 'Month';
    const yearLabel = settings.billingCycleYearLabel || 'Year';

    const faqs = settings.faqs || [];

    const handleSubscribe = (plan: PricingPlan) => {
        // Determine the actual price to charge based on billing cycle
        const currentPrice = billingCycle === 'monthly' ? plan.price : (plan.yearlyPrice || plan.price);
        
        // Force login if trying to subscribe to paid plan and not logged in
        if (!user && currentPrice !== '$0' && currentPrice !== 'Free' && onNavigate) {
            onNavigate('settings'); // Redirect to login
            return;
        }

        // If price is $0, treat as free/link. If price has value, open payment gateway.
        if (currentPrice === '$0' || currentPrice === 'Free') {
            window.location.href = plan.buttonLink;
        } else {
            // Create a temporary plan object with the correct price to pass to the modal
            const planToPay = { ...plan, price: currentPrice };
            setSelectedPlan(planToPay);
            setIsPaymentOpen(true);
        }
    };

    return (
        <div className="w-full max-w-4xl mx-auto mt-8 mb-10 px-2 md:px-4">
            <div className="text-center mb-6">
                {/* Toggle (Functional) */}
                <div className="inline-flex bg-white/60 p-1 rounded-full mt-2 border border-purple-200 backdrop-blur-sm">
                    <button 
                        onClick={() => setBillingCycle('monthly')}
                        className={`px-6 py-1.5 text-xs md:text-sm font-bold rounded-full shadow-sm transition-all active:scale-95 ${
                            billingCycle === 'monthly' 
                            ? 'bg-purple-600 text-white' 
                            : 'text-gray-600 hover:bg-white/50'
                        }`}
                    >
                        {monthLabel}
                    </button>
                    <button 
                        onClick={() => setBillingCycle('yearly')}
                        className={`px-6 py-1.5 text-xs md:text-sm font-bold rounded-full shadow-sm transition-all active:scale-95 ${
                            billingCycle === 'yearly' 
                            ? 'bg-purple-600 text-white' 
                            : 'text-gray-600 hover:bg-white/50'
                        }`}
                    >
                        {yearLabel}
                    </button>
                </div>
            </div>

            {/* Plans Grid - Forced Side by Side */}
            <div className="grid grid-cols-2 gap-3 md:gap-6">
                
                {/* Free Plan */}
                <div className="bg-purple-50/90 backdrop-blur-sm rounded-2xl p-3 md:p-6 shadow-sm border border-purple-100 flex flex-col hover:shadow-md transition-shadow">
                    <h2 className="text-lg md:text-2xl font-bold text-pink-500 mb-1 md:mb-2">{freePlan.title}</h2>
                    <div className="flex items-end mb-4 md:mb-6">
                        <span className="text-2xl md:text-4xl font-bold text-purple-700">
                            {billingCycle === 'monthly' ? freePlan.price : (freePlan.yearlyPrice || freePlan.price)}
                        </span>
                        <span className="text-gray-500 text-xs md:text-base mb-1 ml-1">
                             {billingCycle === 'monthly' ? freePlan.unit : (freePlan.yearlyUnit || freePlan.unit)}
                        </span>
                    </div>
                    
                    <ul className="space-y-2 md:space-y-3 mb-6 flex-1">
                        {freePlan.features.map((feature, idx) => (
                            <li key={idx} className="flex items-start">
                                <i className="mdi mdi-check-circle text-green-500 mr-1.5 text-base md:text-lg flex-shrink-0"></i>
                                <span className="text-xs md:text-sm text-gray-700 leading-tight">{feature}</span>
                            </li>
                        ))}
                    </ul>

                    <button 
                        onClick={() => handleSubscribe(freePlan)}
                        className="block w-full text-center bg-white border border-purple-200 text-purple-600 font-bold py-2 md:py-3 rounded-lg md:rounded-xl text-xs md:text-base hover:bg-purple-50 transition-colors shadow-sm mt-auto"
                    >
                        {freePlan.buttonText}
                    </button>
                </div>

                {/* Premium Plan */}
                <div className="bg-purple-50/90 backdrop-blur-sm rounded-2xl p-3 md:p-6 shadow-md border-2 border-purple-200 flex flex-col relative overflow-hidden hover:shadow-lg transition-shadow">
                    {premiumPlan.isPopular && (
                        <div className="absolute top-0 right-0 bg-purple-200 text-purple-800 text-[10px] md:text-xs font-bold px-2 py-0.5 md:px-3 md:py-1 rounded-bl-lg">
                            POPULAR
                        </div>
                    )}
                    <h2 className="text-lg md:text-2xl font-bold text-purple-600 mb-1 md:mb-2">{premiumPlan.title}</h2>
                    <div className="flex items-end mb-4 md:mb-6">
                        <span className="text-2xl md:text-4xl font-bold text-purple-700">
                            {billingCycle === 'monthly' ? premiumPlan.price : (premiumPlan.yearlyPrice || premiumPlan.price)}
                        </span>
                        <span className="text-gray-500 text-xs md:text-base mb-1 ml-1">
                            {billingCycle === 'monthly' ? premiumPlan.unit : (premiumPlan.yearlyUnit || premiumPlan.unit)}
                        </span>
                    </div>
                    
                    <ul className="space-y-2 md:space-y-3 mb-6 flex-1">
                        {premiumPlan.features.map((feature, idx) => (
                            <li key={idx} className="flex items-start">
                                <i className="mdi mdi-check-circle text-green-500 mr-1.5 text-base md:text-lg flex-shrink-0"></i>
                                <span className="text-xs md:text-sm text-gray-700 leading-tight">{feature}</span>
                            </li>
                        ))}
                    </ul>

                    <button 
                        onClick={() => handleSubscribe(premiumPlan)}
                        className="block w-full text-center bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold py-2 md:py-3 rounded-lg md:rounded-xl text-xs md:text-base hover:opacity-90 transition-opacity shadow-md mt-auto"
                    >
                        {premiumPlan.buttonText}
                    </button>
                </div>
            </div>

            {/* FAQ Section */}
            {faqs.length > 0 && (
                <div className="max-w-3xl mx-auto mt-8 bg-[#FDFBF7] rounded-3xl p-6 md:p-8 shadow-sm">
                    <h3 className="text-center text-xl md:text-2xl font-bold text-gray-800 mb-6 relative inline-block w-full">
                        <span className="relative z-10 border-b-4 border-green-200 pb-1">Frequently asked questions</span>
                    </h3>

                    <div className="space-y-6">
                        {faqs.map((faq, index) => (
                             <div key={index}>
                                <h4 className="font-bold text-gray-800 mb-1 text-xs md:text-sm">{faq.question}</h4>
                                <p className="text-[10px] md:text-xs text-gray-600 leading-relaxed whitespace-pre-line">
                                    {faq.answer}
                                </p>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Payment Modal */}
            {selectedPlan && (
                <PaymentModal 
                    isOpen={isPaymentOpen}
                    onClose={() => setIsPaymentOpen(false)}
                    plan={selectedPlan}
                    methods={settings.paymentMethods || []}
                    user={user || null} 
                />
            )}
        </div>
    );
};

export default PricingPlans;