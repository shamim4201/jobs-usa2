
import React from 'react';
import { useData } from '../context/DataContext';

interface SiteLogoProps {
    className?: string;
}

const SiteLogo: React.FC<SiteLogoProps> = ({ className = "h-10" }) => {
    const { settings } = useData();

    if (settings.siteLogoUrl) {
        return (
            <img 
                src={settings.siteLogoUrl} 
                alt={settings.siteTitle} 
                className={`object-contain ${className}`} 
            />
        );
    }

    // Fallback if no logo is set
    return (
        <span className={`font-bold text-xl text-blue-600 ${className} flex items-center`}>
            {settings.siteTitle}
        </span>
    );
};

export default SiteLogo;
