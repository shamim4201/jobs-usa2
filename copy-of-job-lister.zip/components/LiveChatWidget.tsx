
import React, { useState, useEffect, useRef } from 'react';
import { useData } from '../context/DataContext';
import type { User, ChatMessage } from '../types';

interface LiveChatWidgetProps {
    user: User | null;
}

const LiveChatWidget: React.FC<LiveChatWidgetProps> = ({ user }) => {
    const { chats, sendChatMessage } = useData();
    const [isOpen, setIsOpen] = useState(false);
    const [messageText, setMessageText] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    // If no user, we create a pseudo guest ID for this session
    const [guestId] = useState(() => {
        const stored = sessionStorage.getItem('guest_chat_id');
        if (stored) return parseInt(stored);
        const newId = -Math.floor(Math.random() * 1000000); // Negative ID for guests
        sessionStorage.setItem('guest_chat_id', newId.toString());
        return newId;
    });

    const currentUserId = user ? user.id : guestId;
    const currentUserName = user ? user.name : 'Guest User';

    // Filter messages for this user
    const myMessages = chats.filter(c => c.userId === currentUserId).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

    // Auto-scroll to bottom
    useEffect(() => {
        if (isOpen) {
            messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        }
    }, [myMessages, isOpen]);

    const handleSend = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!messageText.trim()) return;

        await sendChatMessage({
            userId: currentUserId,
            userName: currentUserName,
            text: messageText,
            sender: 'user'
        });
        setMessageText('');
    };

    const unreadCount = myMessages.filter(m => m.sender === 'admin' && !m.isRead).length;

    return (
        <div className="fixed bottom-20 right-4 z-50 flex flex-col items-end">
            
            {/* Chat Window */}
            {isOpen && (
                <div className="bg-white w-80 h-96 rounded-2xl shadow-2xl flex flex-col border border-gray-200 overflow-hidden mb-4 animate-fade-in-up">
                    {/* Header */}
                    <div className="bg-purple-600 p-4 flex justify-between items-center text-white">
                        <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center">
                                <i className="mdi mdi-face-agent text-purple-600"></i>
                            </div>
                            <div>
                                <h3 className="font-bold text-sm">Live Support</h3>
                                <p className="text-xs opacity-80">We reply typically in minutes</p>
                            </div>
                        </div>
                        <button onClick={() => setIsOpen(false)} className="hover:bg-purple-500 rounded-full p-1 transition">
                            <i className="mdi mdi-close"></i>
                        </button>
                    </div>

                    {/* Messages */}
                    <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
                        {myMessages.length === 0 && (
                            <p className="text-center text-xs text-gray-400 mt-10">
                                👋 Hi! How can we help you today?
                            </p>
                        )}
                        {myMessages.map(msg => (
                            <div key={msg.id} className={`flex mb-2 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                                <div className={`max-w-[80%] p-2 rounded-xl text-sm ${
                                    msg.sender === 'user' 
                                    ? 'bg-purple-600 text-white rounded-br-none' 
                                    : 'bg-white text-gray-800 border border-gray-200 rounded-bl-none shadow-sm'
                                }`}>
                                    {msg.text}
                                </div>
                            </div>
                        ))}
                        <div ref={messagesEndRef} />
                    </div>

                    {/* Input */}
                    <form onSubmit={handleSend} className="p-3 bg-white border-t border-gray-200 flex gap-2">
                        <input 
                            type="text" 
                            value={messageText}
                            onChange={e => setMessageText(e.target.value)}
                            placeholder="Type a message..." 
                            className="flex-1 bg-gray-100 border-0 rounded-full px-4 py-2 text-sm focus:ring-2 focus:ring-purple-500 focus:bg-white outline-none transition-all"
                        />
                        <button 
                            type="submit" 
                            disabled={!messageText.trim()}
                            className="bg-purple-600 text-white w-9 h-9 rounded-full flex items-center justify-center hover:bg-purple-700 transition shadow-md disabled:opacity-50"
                        >
                            <i className="mdi mdi-send text-sm"></i>
                        </button>
                    </form>
                </div>
            )}

            {/* Floating Button */}
            <button 
                onClick={() => setIsOpen(!isOpen)}
                className="w-14 h-14 bg-purple-600 rounded-full shadow-lg flex items-center justify-center text-white hover:bg-purple-700 transition-transform transform hover:scale-105 relative"
            >
                <i className={`mdi ${isOpen ? 'mdi-close' : 'mdi-chat-processing'} text-2xl`}></i>
                {!isOpen && unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-white">
                        {unreadCount}
                    </span>
                )}
            </button>
        </div>
    );
};

export default LiveChatWidget;
