
import React from 'react';
import type { Job } from '../types';
import { useData } from '../context/DataContext';

interface JobListItemProps {
  job: Job;
  onJobClick?: (id: number) => void;
}

const JobListItem: React.FC<JobListItemProps> = ({ job, onJobClick }) => {
  const { jobComments } = useData();
  
  // Calculate comment count for this specific job
  const commentCount = jobComments.filter(c => c.jobId === job.id).length;

  return (
    <div 
        onClick={() => onJobClick && onJobClick(job.id)}
        className="bg-white rounded-lg shadow-sm p-3 border border-gray-200 cursor-pointer hover:shadow-md transition-shadow mb-2 relative"
    >
      <div className="flex items-center justify-between gap-3">
        {/* Left: Image */}
        <div className="w-16 h-16 flex-shrink-0 bg-white border border-gray-100 rounded-md p-1 flex items-center justify-center">
            <img src={job.imageUrl} alt={job.title} className="w-full h-full object-contain" />
        </div>
        
        {/* Middle: Content */}
        <div className="flex-grow min-w-0 flex flex-col justify-center">
          <h3 className="font-bold text-gray-900 text-sm truncate leading-tight">{job.title}</h3>
          <p className="text-xs text-gray-500 truncate mb-1">{job.company}</p>
          
          <p className="text-[10px] text-gray-400 line-clamp-1 mb-1">{job.description}</p>

          <div className="flex items-center gap-3">
             {/* Salary in Blue */}
             <span className="text-blue-600 font-bold text-xs">
                {job.salary}
             </span>
          </div>
          
          {/* Comment Text Styled Blue with Count */}
          <div className="mt-1">
             <span className="text-blue-600 text-sm font-semibold opacity-90 leading-none hover:underline">
                Comment ({commentCount})
             </span>
          </div>
        </div>

        {/* Right: Button */}
        <div className="flex-shrink-0 self-center">
            <button 
              onClick={(e) => {
                  e.stopPropagation(); // Prevent triggering parent click
                  window.open(job.applyUrl, '_blank');
              }}
              className="bg-green-500 text-white text-xs font-bold py-2 px-4 rounded shadow-sm hover:bg-green-600 transition-colors"
            >
                Apply Now
            </button>
        </div>
      </div>
    </div>
  );
};

export default JobListItem;
