
import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import type { PaymentMethod, PricingPlan, User } from '../types';

interface PaymentModalProps {
    plan: PricingPlan;
    methods: PaymentMethod[];
    isOpen: boolean;
    onClose: () => void;
    user: User | null; // Added user prop
}

const PaymentModal: React.FC<PaymentModalProps> = ({ plan, methods, isOpen, onClose, user }) => {
    const { addPayment } = useData();
    const [selectedCurrency, setSelectedCurrency] = useState<'BDT' | 'USD' | null>(null);
    const [selectedMethodId, setSelectedMethodId] = useState<string | null>(null);
    const [senderPhone, setSenderPhone] = useState('');
    const [trxId, setTrxId] = useState('');
    const [screenshot, setScreenshot] = useState<File | null>(null);
    const [step, setStep] = useState<'currency' | 'method' | 'input' | 'success'>('currency');
    const [isSubmitting, setIsSubmitting] = useState(false);

    if (!isOpen) return null;

    const selectedMethod = methods.find(m => m.id === selectedMethodId);
    
    // Price Calculation
    const priceUSD = parseFloat(plan.price.replace(/[^0-9.]/g, '')) || 0;
    const priceBDT = Math.ceil(priceUSD * 120); // 1 USD = 120 BDT approx

    const handleCurrencySelect = (currency: 'BDT' | 'USD') => {
        setSelectedCurrency(currency);
        setStep('method');
    };

    const handleMethodSelect = (id: string) => {
        setSelectedMethodId(id);
        setStep('input');
    };

    const handleBack = () => {
        if (step === 'input') {
            setStep('method');
            setSelectedMethodId(null);
            setScreenshot(null);
        } else if (step === 'method') {
            setStep('currency');
            setSelectedCurrency(null);
        }
    };

    const convertFileToBase64 = (file: File): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = error => reject(error);
        });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        
        let screenshotDataUrl = undefined;
        if (screenshot) {
            try {
                // Compress/Limit checks could be added here, but for now we just convert
                screenshotDataUrl = await convertFileToBase64(screenshot);
            } catch (error) {
                console.error("Error converting file", error);
            }
        }

        // Save to database via context
        await addPayment({
            userId: user ? user.id : undefined, // Link to user ID
            userName: user ? user.name : 'Guest',
            planTitle: plan.title,
            amount: selectedCurrency === 'BDT' ? priceBDT : priceUSD,
            currency: selectedCurrency!,
            methodName: selectedMethod!.name,
            senderNumber: senderPhone,
            trxId: trxId,
            screenshotName: screenshot ? screenshot.name : undefined,
            screenshotDataUrl: screenshotDataUrl
        });

        setIsSubmitting(false);
        setStep('success');
    };

    // Filter methods based on currency
    const filteredMethods = methods.filter(m => m.isEnabled && m.currency === selectedCurrency);

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4 backdrop-blur-sm">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden relative">
                
                {/* Header */}
                <div className="bg-gray-50 border-b border-gray-100 p-4 flex justify-between items-center">
                    <h2 className="text-lg font-bold text-gray-800">
                        {step === 'success' ? 'Payment Successful' : `Pay for ${plan.title}`}
                    </h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
                        <i className="mdi mdi-close text-2xl"></i>
                    </button>
                </div>

                <div className="p-6">
                    {/* Step 1: Select Currency */}
                    {step === 'currency' && (
                        <div>
                            <p className="text-sm text-gray-600 mb-6 text-center">Select your payment currency:</p>
                            <div className="grid grid-cols-2 gap-4">
                                <button
                                    onClick={() => handleCurrencySelect('BDT')}
                                    className="flex flex-col items-center justify-center p-6 border border-gray-200 rounded-xl hover:border-green-500 hover:bg-green-50 transition-all group"
                                >
                                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center text-green-600 mb-3 group-hover:scale-110 transition-transform">
                                        <span className="text-2xl font-bold">৳</span>
                                    </div>
                                    <span className="text-lg font-bold text-gray-800">BDT</span>
                                    <span className="text-xs text-gray-500 mt-1">Bkash, Nagad, Rocket</span>
                                </button>

                                <button
                                    onClick={() => handleCurrencySelect('USD')}
                                    className="flex flex-col items-center justify-center p-6 border border-gray-200 rounded-xl hover:border-blue-500 hover:bg-blue-50 transition-all group"
                                >
                                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 mb-3 group-hover:scale-110 transition-transform">
                                        <span className="text-2xl font-bold">$</span>
                                    </div>
                                    <span className="text-lg font-bold text-gray-800">USD</span>
                                    <span className="text-xs text-gray-500 mt-1">Binance, Crypto</span>
                                </button>
                            </div>
                        </div>
                    )}

                    {/* Step 2: Select Method */}
                    {step === 'method' && (
                        <div>
                             <button 
                                type="button" 
                                onClick={handleBack} 
                                className="text-sm text-gray-500 hover:text-gray-800 mb-4 flex items-center"
                            >
                                <i className="mdi mdi-arrow-left mr-1"></i> Back
                            </button>
                            <p className="text-sm text-gray-600 mb-4 text-center">Select {selectedCurrency} Payment Method:</p>
                            <div className="grid grid-cols-2 gap-4">
                                {filteredMethods.map(method => (
                                    <button
                                        key={method.id}
                                        onClick={() => handleMethodSelect(method.id)}
                                        className="flex flex-col items-center justify-center p-4 border border-gray-200 rounded-lg hover:border-purple-500 hover:bg-purple-50 transition-all group"
                                    >
                                        <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white mb-2 ${method.logoBg}`}>
                                            <span className="font-bold text-xs">{method.name.substring(0, 2)}</span>
                                        </div>
                                        <span className="text-gray-700 font-medium group-hover:text-purple-600 text-sm">{method.name}</span>
                                    </button>
                                ))}
                            </div>
                             {filteredMethods.length === 0 && (
                                <p className="text-center text-red-500 text-sm py-4 bg-red-50 rounded-lg border border-red-100">
                                    No payment methods available for {selectedCurrency}.
                                </p>
                            )}
                        </div>
                    )}

                    {/* Step 3: Input Details */}
                    {step === 'input' && selectedMethod && (
                        <form onSubmit={handleSubmit}>
                            <button 
                                type="button" 
                                onClick={handleBack} 
                                className="text-sm text-gray-500 hover:text-gray-800 mb-4 flex items-center"
                            >
                                <i className="mdi mdi-arrow-left mr-1"></i> Back
                            </button>

                            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
                                <div className="flex justify-between items-center mb-2">
                                     <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">Amount to Pay</span>
                                     <span className="text-xl font-extrabold text-red-600">
                                        {selectedCurrency === 'BDT' ? `৳${priceBDT}` : `$${priceUSD}`}
                                     </span>
                                </div>
                                <div className="flex justify-between items-center">
                                     <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">Method</span>
                                     <span className="font-bold text-gray-800">{selectedMethod.name}</span>
                                </div>
                                
                                <div className="my-3 border-t border-yellow-200 border-dashed"></div>
                                
                                <p className="text-xs text-gray-600 mb-1">{selectedMethod.instruction}:</p>
                                <div className="flex items-center justify-between bg-white p-3 rounded border border-yellow-200 shadow-sm">
                                    <code className="text-lg font-bold text-gray-800 tracking-wide">{selectedMethod.number}</code>
                                    <button 
                                        type="button"
                                        onClick={() => navigator.clipboard.writeText(selectedMethod.number)}
                                        className="text-blue-600 hover:bg-blue-50 px-2 py-1 rounded text-xs font-bold uppercase transition-colors"
                                    >
                                        Copy
                                    </button>
                                </div>
                            </div>

                            <div className="mb-4">
                                <label className="block text-gray-700 text-xs font-bold mb-1">
                                    {selectedMethod.currency === 'USD' ? 'Sender Wallet / Email' : 'Sender Number (আপনার নাম্বার)'}
                                </label>
                                <input 
                                    type="text" 
                                    required
                                    value={senderPhone}
                                    onChange={e => setSenderPhone(e.target.value)}
                                    className="w-full border rounded px-3 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    placeholder={selectedMethod.currency === 'USD' ? 'Wallet Address' : '017xxxxxxxx'}
                                />
                            </div>

                            <div className="mb-4">
                                <label className="block text-gray-700 text-xs font-bold mb-1">Transaction ID (TrxID / Hash)</label>
                                <input 
                                    type="text" 
                                    required
                                    value={trxId}
                                    onChange={e => setTrxId(e.target.value)}
                                    className="w-full border rounded px-3 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    placeholder="8JHS2..."
                                />
                            </div>

                            {/* Screenshot Upload Field */}
                            <div className="mb-6">
                                <label className="block text-gray-700 text-xs font-bold mb-1">
                                    Payment Screenshot (পেমেন্টের প্রমাণ/স্ক্রিনশট)
                                </label>
                                
                                {!screenshot ? (
                                    <label className="cursor-pointer mt-1 flex flex-col items-center justify-center px-4 py-6 border-2 border-gray-300 border-dashed rounded-lg hover:bg-gray-50 hover:border-blue-400 transition-colors bg-gray-50 w-full">
                                        <i className="mdi mdi-cloud-upload text-3xl text-gray-400 mb-2"></i>
                                        <div className="text-sm text-blue-600 font-semibold mb-1">
                                            Click to Upload Screenshot
                                        </div>
                                        <p className="text-[10px] text-gray-500">JPG, PNG (Max 5MB)</p>
                                        <input 
                                            type="file" 
                                            className="hidden" 
                                            accept="image/*" 
                                            onChange={(e) => {
                                                if (e.target.files && e.target.files[0]) {
                                                    setScreenshot(e.target.files[0]);
                                                }
                                            }} 
                                        />
                                    </label>
                                ) : (
                                    <div className="mt-1 flex items-center justify-between bg-white px-4 py-3 rounded border border-green-200 shadow-sm">
                                        <div className="flex items-center overflow-hidden">
                                            <i className="mdi mdi-file-image text-green-500 text-2xl mr-3"></i>
                                            <div className="flex flex-col overflow-hidden">
                                                <span className="text-sm font-semibold text-gray-700 truncate max-w-[150px]">{screenshot.name}</span>
                                                <span className="text-[10px] text-gray-500">{(screenshot.size / 1024).toFixed(1)} KB</span>
                                            </div>
                                        </div>
                                        <button 
                                            type="button" 
                                            onClick={() => setScreenshot(null)}
                                            className="text-red-500 hover:text-red-700 p-2 rounded-full hover:bg-red-50 transition-colors"
                                            title="Remove image"
                                        >
                                            <i className="mdi mdi-delete text-xl"></i>
                                        </button>
                                    </div>
                                )}
                            </div>

                            <button 
                                type="submit" 
                                disabled={isSubmitting}
                                className="w-full bg-blue-600 text-white font-bold py-3 rounded-lg hover:bg-blue-700 transition-colors shadow-md flex items-center justify-center gap-2 disabled:opacity-50"
                            >
                                {isSubmitting ? 'Processing...' : (
                                    <>
                                        <span>Submit Payment</span>
                                        <i className="mdi mdi-arrow-right"></i>
                                    </>
                                )}
                            </button>
                        </form>
                    )}

                    {/* Step 4: Success */}
                    {step === 'success' && (
                        <div className="text-center py-6">
                            <div className="w-20 h-20 bg-green-100 text-green-500 rounded-full flex items-center justify-center mx-auto mb-6 animate-bounce">
                                <i className="mdi mdi-check-circle text-5xl"></i>
                            </div>
                            <h3 className="text-2xl font-bold text-gray-800 mb-2">Payment Submitted!</h3>
                            <p className="text-gray-600 text-sm mb-8 leading-relaxed">
                                We have received your payment info and screenshot. <br/>
                                Your plan will be activated automatically within <span className="font-bold">30 minutes</span> after verification.
                            </p>
                            <button 
                                onClick={onClose}
                                className="w-full bg-gray-900 text-white font-bold py-3 px-6 rounded-lg hover:bg-gray-800 transition-colors shadow-lg"
                            >
                                Close Window
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default PaymentModal;
