
import type { Job, User, Country, AppSettings, PaymentTransaction, UserAdRequest, UserNotification, JobComment, ChatMessage } from '../types';
import { jobs as initialJobs } from '../data/jobs';
import { users as initialUsers } from '../data/users';
import { countries as initialCountries } from '../data/countries';
// @ts-ignore
import { initializeApp } from 'firebase/app';
// @ts-ignore
import { getFirestore, collection, getDocs, addDoc, updateDoc, deleteDoc, doc, setDoc, query, orderBy } from 'firebase/firestore';

// --- 🔥🔥🔥 IMPORTANT: LIVE DATABASE CONFIGURATION 🔥🔥🔥 ---
// যদি আপনি অ্যাডমিন প্যানেল থেকে সেট করতে না পারেন, তবে আপনার Firebase Config সরাসরি এখানে বসান।
// If you cannot set it from Admin Panel, paste your Firebase Config directly here.
export const HARDCODED_FIREBASE_CONFIG = {
  apiKey: "AIzaSyAvRqRzHtJx99vUsrG6GJocDvzcgImXzgo",
  authDomain: "fort-time-jobs.firebaseapp.com",
  projectId: "fort-time-jobs",
  storageBucket: "fort-time-jobs.firebasestorage.app",
  messagingSenderId: "991828882714",
  appId: "1:991828882714:web:9af74186356deb9e0b68a3",
  measurementId: "G-1S96S0TRLV"
};
// -------------------------------------------------------------

const STORAGE_KEYS = {
    JOBS: 'app_jobs',
    USERS: 'app_users',
    COUNTRIES: 'app_countries',
    SETTINGS: 'app_settings',
    PAYMENTS: 'app_payments',
    AD_REQUESTS: 'app_ad_requests',
    NOTIFICATIONS: 'app_notifications',
    COMMENTS: 'app_job_comments',
    CHATS: 'app_chats'
};

// Simulate network delay (e.g., 500ms) to feel like a real server
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Helper to get data from storage or use initial data
const getFromStorage = <T>(key: string, initialData: T): T => {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : initialData;
};

// Helper to save data to storage
const saveToStorage = <T>(key: string, data: T) => {
    localStorage.setItem(key, JSON.stringify(data));
};

const initialSettings: AppSettings = {
    googleAnalyticsId: 'G-1S96S0TRLV', // Set from config
    siteTitle: 'Job Lister',
    siteLogoUrl: 'https://i.imgur.com/7bQ5b2S.png', // Default Logo
    inviteReferralUrl: 'https://t.me/Porttimejobsbot', // Default Invite Link
    
    // Firebase defaults (disabled)
    enableFirebase: false,
    
    // SEO Defaults
    seoTitle: 'Best Job - Find Online Jobs Easily',
    seoDescription: 'Find the best online jobs, data entry, typing, and remote work opportunities. Join now and start earning.',
    seoKeywords: 'jobs, online jobs, data entry, work from home, typing jobs, freelancing',

    // Default Plan Data
    freePlan: {
        title: 'Free',
        price: '$0',
        unit: '/mo',
        yearlyPrice: '$0',
        yearlyUnit: '/yr',
        features: [
            '100% Private address',
            'Enhanced privacy',
            'Basic Job Listing'
        ],
        buttonText: 'Current Plan',
        buttonLink: '#',
        isPopular: false
    },
    premiumPlan: {
        title: 'Premium',
        price: '$8',
        unit: '/mo',
        yearlyPrice: '$80',
        yearlyUnit: '/yr',
        features: [
            'Unlimited switching',
            'Dedicated domains',
            '100% Private',
            'No ads'
        ],
        buttonText: 'Subscribe Now',
        buttonLink: '#',
        isPopular: true
    },
    billingCycleMonthLabel: 'Month',
    billingCycleYearLabel: 'Year',

    // Support Bot Defaults
    supportBot: {
        greeting: "Hello! Welcome to Support. I can help recover your password. For security, please verify your identity.",
        askName: "First, please type your **Full Name** exactly as registered.",
        askCountry: "✅ Name verified! Now, please tell me your **Country** name.",
        successMsg: "✅ Identity Verified! Here is your password:",
        errorName: "❌ Incorrect name. Please try again or check your spelling.",
        errorCountry: "❌ Incorrect country. Please try again."
    },

    // Default FAQs
    faqs: [
        { 
            question: 'What is temporary mail?', 
            answer: 'Temporary email is a short-term use mailbox that helps protect privacy, avoid spam, and register quickly.' 
        },
        { 
            question: 'What scenarios are suitable?', 
            answer: 'Temporary email is suitable for scenarios such as registering on websites, trying out services, protecting privacy, avoiding spam, and participating in short-term activities.' 
        }
    ],

    // Default Payment Methods
    paymentMethods: [
        {
            id: 'bkash',
            name: 'Bkash',
            number: '01700000000',
            instruction: 'Send Money (Personal)',
            logoBg: 'bg-pink-600',
            isEnabled: true,
            currency: 'BDT'
        },
        {
            id: 'nagad',
            name: 'Nagad',
            number: '01800000000',
            instruction: 'Send Money (Personal)',
            logoBg: 'bg-orange-600',
            isEnabled: true,
            currency: 'BDT'
        },
        {
            id: 'rocket',
            name: 'Rocket',
            number: '01900000000',
            instruction: 'Send Money',
            logoBg: 'bg-purple-600',
            isEnabled: true,
            currency: 'BDT'
        },
        {
            id: 'binance',
            name: 'Binance',
            number: 'TQ8... (TRC20)',
            instruction: 'Send USDT (TRC20)',
            logoBg: 'bg-yellow-500',
            isEnabled: true,
            currency: 'USD'
        },
        {
            id: 'bank_usd',
            name: 'Bank Transfer (USD)',
            number: 'ACCT: 1234567890 (SWIFT: BANKUS33)',
            instruction: 'Wire Transfer / Swift',
            logoBg: 'bg-indigo-600',
            isEnabled: true,
            currency: 'USD'
        }
    ],

    homeTopAdCode: '',
    homeBottomAdCode: '',
    homeMiddleAdCode: '',
    jobsTopAdCode: '',
    jobsMiddleAdCode: '',
    jobsBottomAdCode: '',
    jobsAdInterval: 3, // Default to every 3 jobs
    inviteTopAdCode: '',
    inviteBottomAdCode: '',
    loginTopAdCode: '',
    loginBottomAdCode: ''
};

const initialPayments: PaymentTransaction[] = [];
const initialAdRequests: UserAdRequest[] = [];
const initialNotifications: UserNotification[] = [];
const initialComments: JobComment[] = [];
const initialChats: ChatMessage[] = [];

// --- Firebase Helper ---
let firebaseApp: any = null;
let firestoreDb: any = null;

// Export checking function for UI
export const isFirebaseConfigured = () => {
    // If db is initialized successfully, it's configured.
    // Also check hardcoded config for optimistic UI
    if (firestoreDb) return true;
    
    return (HARDCODED_FIREBASE_CONFIG.apiKey && HARDCODED_FIREBASE_CONFIG.apiKey.length > 5);
};

export const validateFirebaseConfig = async (config: any) => {
    try {
        // Attempt to initialize a test app to see if config is valid
        // Use a unique name to prevent "App named 'testApp' already exists" error on retries
        const appName = `testApp_${Date.now()}`;
        const testApp = initializeApp(config, appName); 
        const db = getFirestore(testApp);
        // Try a simple read operation (it might fail due to permissions, but it proves connection)
        // We just want to know if the SDK accepted the config
        return true;
    } catch (error) {
        console.error("Firebase Validation Error:", error);
        throw error;
    }
};

const getFirebaseDb = () => {
    // Return existing instance if available
    if (firestoreDb) return firestoreDb;

    // 1. First Check Hardcoded Config
    let configToUse = null;
    
    // Strict check for hardcoded config
    if (HARDCODED_FIREBASE_CONFIG.apiKey && HARDCODED_FIREBASE_CONFIG.apiKey.trim().length > 10) {
        configToUse = HARDCODED_FIREBASE_CONFIG;
    } else {
        // 2. Fallback to LocalStorage Settings
        const settings = getFromStorage<AppSettings>(STORAGE_KEYS.SETTINGS, initialSettings);
        if (settings.enableFirebase && settings.firebaseApiKey) {
            configToUse = {
                apiKey: settings.firebaseApiKey,
                authDomain: settings.firebaseAuthDomain,
                projectId: settings.firebaseProjectId,
                storageBucket: settings.firebaseStorageBucket,
                messagingSenderId: settings.firebaseMessagingSenderId,
                appId: settings.firebaseAppId
            };
        }
    }

    if (!configToUse) {
        return null; // Firebase not enabled
    }

    // 3. Initialize if not already done
    if (!firebaseApp) {
        try {
            // Check if app already exists to avoid duplicate error
            // This is a bit of a hack since we don't have getApp imported, but initializeApp handles it usually.
            
            firebaseApp = initializeApp(configToUse);
            try {
                firestoreDb = getFirestore(firebaseApp);
                console.log("🔥 Firebase Initialized Successfully");
            } catch (fsError) {
                console.error("🔥 Firestore Initialization Failed:", fsError);
                // Important: If Firestore fails, we shouldn't keep firebaseApp as "valid" for DB operations
                firestoreDb = null;
                return null;
            }
        } catch (error: any) {
            // If app already exists, try to get it (though re-importing getApp is tricky here without top-level import)
            if (error.code === 'app/duplicate-app') {
                 console.warn("Firebase app already initialized, attempting to reuse.");
                 // In a real module system, we'd use getApp(). Here we rely on the fact that if it exists,
                 // maybe firestoreDb was just null. But if we can't get the app instance, we can't get firestore.
                 // We will just return null to fallback to local storage.
            } else {
                console.error("Firebase App Initialization Error:", error);
            }
            return null;
        }
    }
    
    return firestoreDb;
};

// Generic Firebase Fetch
const fbGetAll = async <T>(collectionName: string): Promise<T[]> => {
    const db = getFirebaseDb();
    if (!db) throw new Error("Firebase not initialized");
    try {
        const querySnapshot = await getDocs(collection(db, collectionName));
        const list: any[] = [];
        querySnapshot.forEach((doc: any) => {
            list.push({ ...doc.data() }); 
        });
        return list;
    } catch (error) {
        console.error(`Error fetching ${collectionName}:`, error);
        return [];
    }
};

// Generic Firebase Add (using Custom numeric IDs for compatibility)
const fbAdd = async <T extends { id: number }>(collectionName: string, data: T): Promise<void> => {
    const db = getFirebaseDb();
    if (!db) throw new Error("Firebase not initialized");
    await setDoc(doc(db, collectionName, data.id.toString()), data);
};

// Generic Firebase Update
const fbUpdate = async <T extends { id: number }>(collectionName: string, data: T): Promise<void> => {
    const db = getFirebaseDb();
    if (!db) throw new Error("Firebase not initialized");
    await updateDoc(doc(db, collectionName, data.id.toString()), data);
};

// Generic Firebase Delete
const fbDelete = async (collectionName: string, id: number): Promise<void> => {
    const db = getFirebaseDb();
    if (!db) throw new Error("Firebase not initialized");
    await deleteDoc(doc(db, collectionName, id.toString()));
};


export const api = {
    // --- Seed Database ---
    async seedDatabase(): Promise<void> {
        const db = getFirebaseDb();
        if (!db) throw new Error("Firebase not connected. Cannot seed.");

        console.log("🌱 Seeding Database...");
        
        // Upload Jobs
        for (const job of initialJobs) {
            await fbAdd('jobs', job);
        }
        // Upload Users
        for (const user of initialUsers) {
            await fbAdd('users', user);
        }
        // Upload Countries
        for (const country of initialCountries) {
            await fbAdd('countries', country);
        }
        
        console.log("✅ Database Seeded Successfully!");
    },

    // --- Jobs API ---
    async getJobs(): Promise<Job[]> {
        const db = getFirebaseDb();
        if (db) return await fbGetAll<Job>('jobs');

        await delay(500); 
        return getFromStorage<Job[]>(STORAGE_KEYS.JOBS, initialJobs);
    },

    async addJob(job: Job): Promise<Job> {
        const db = getFirebaseDb();
        const newJobData = { ...job, showOnHome: job.showOnHome || false }; // Default false

        if (db) {
            const jobs = await fbGetAll<Job>('jobs');
            const newId = jobs.length > 0 ? Math.max(...jobs.map(j => j.id)) + 1 : 1;
            const newJob = { ...newJobData, id: newId };
            await fbAdd('jobs', newJob);
            return newJob;
        }

        await delay(500);
        const jobs = getFromStorage<Job[]>(STORAGE_KEYS.JOBS, initialJobs);
        const newId = jobs.length > 0 ? Math.max(...jobs.map(j => j.id)) + 1 : 1;
        const newJob = { ...newJobData, id: newId };
        saveToStorage(STORAGE_KEYS.JOBS, [...jobs, newJob]);
        return newJob;
    },

    async updateJob(job: Job): Promise<Job> {
        const db = getFirebaseDb();
        if (db) {
            await fbUpdate('jobs', job);
            return job;
        }

        await delay(500);
        const jobs = getFromStorage<Job[]>(STORAGE_KEYS.JOBS, initialJobs);
        const updatedJobs = jobs.map(j => j.id === job.id ? job : j);
        saveToStorage(STORAGE_KEYS.JOBS, updatedJobs);
        return job;
    },

    async deleteJob(jobId: number): Promise<void> {
        const db = getFirebaseDb();
        if (db) {
            await fbDelete('jobs', jobId);
            return;
        }

        await delay(500);
        const jobs = getFromStorage<Job[]>(STORAGE_KEYS.JOBS, initialJobs);
        const filteredJobs = jobs.filter(j => j.id !== jobId);
        saveToStorage(STORAGE_KEYS.JOBS, filteredJobs);
    },

    // --- Users API ---
    async getUsers(): Promise<User[]> {
        const db = getFirebaseDb();
        if (db) {
            let users = await fbGetAll<User>('users');
            
            // --- AUTO SEED DEFAULT ADMIN IF EMPTY ---
            if (users.length === 0) {
                console.warn("⚠ No users found in Firebase. Auto-creating default admin...");
                const defaultAdmin = initialUsers[0]; // The default admin from data/users.ts
                await fbAdd('users', defaultAdmin);
                users = [defaultAdmin];
            }
            // ----------------------------------------

            return users;
        }

        await delay(500);
        return getFromStorage<User[]>(STORAGE_KEYS.USERS, initialUsers);
    },

    async addUser(user: User): Promise<User> {
        const db = getFirebaseDb();
        if (db) {
            const users = await fbGetAll<User>('users');
            const newId = users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1;
            const newUser = { 
                ...user, 
                id: newId,
                joinedDate: user.joinedDate || new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })
            };
            await fbAdd('users', newUser);
            return newUser;
        }

        await delay(500);
        const users = getFromStorage<User[]>(STORAGE_KEYS.USERS, initialUsers);
        const newId = users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1;
        const newUser = { 
            ...user, 
            id: newId,
            joinedDate: user.joinedDate || new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })
        };
        saveToStorage(STORAGE_KEYS.USERS, [...users, newUser]);
        return newUser;
    },

    async updateUser(user: User): Promise<User> {
        const db = getFirebaseDb();
        if (db) {
            await fbUpdate('users', user);
            return user;
        }

        await delay(500);
        const users = getFromStorage<User[]>(STORAGE_KEYS.USERS, initialUsers);
        const updatedUsers = users.map(u => u.id === user.id ? user : u);
        saveToStorage(STORAGE_KEYS.USERS, updatedUsers);
        return user;
    },

    async deleteUser(userId: number): Promise<void> {
        const db = getFirebaseDb();
        if (db) {
            await fbDelete('users', userId);
            return;
        }

        await delay(500);
        const users = getFromStorage<User[]>(STORAGE_KEYS.USERS, initialUsers);
        const filteredUsers = users.filter(u => u.id !== userId);
        saveToStorage(STORAGE_KEYS.USERS, filteredUsers);
    },

    // --- Countries API ---
    async getCountries(): Promise<Country[]> {
        const db = getFirebaseDb();
        if (db) return await fbGetAll<Country>('countries');

        await delay(500);
        return getFromStorage<Country[]>(STORAGE_KEYS.COUNTRIES, initialCountries);
    },

    async addCountry(country: Country): Promise<Country> {
        const db = getFirebaseDb();
        if (db) {
            const countries = await fbGetAll<Country>('countries');
            const newId = countries.length > 0 ? Math.max(...countries.map(c => c.id)) + 1 : 1;
            const newCountry = { ...country, id: newId };
            await fbAdd('countries', newCountry);
            return newCountry;
        }

        await delay(500);
        const countries = getFromStorage<Country[]>(STORAGE_KEYS.COUNTRIES, initialCountries);
        const newId = countries.length > 0 ? Math.max(...countries.map(c => c.id)) + 1 : 1;
        const newCountry = { ...country, id: newId };
        saveToStorage(STORAGE_KEYS.COUNTRIES, [...countries, newCountry]);
        return newCountry;
    },

    async updateCountry(country: Country): Promise<Country> {
        const db = getFirebaseDb();
        if (db) {
            await fbUpdate('countries', country);
            return country;
        }

        await delay(500);
        const countries = getFromStorage<Country[]>(STORAGE_KEYS.COUNTRIES, initialCountries);
        const updatedCountries = countries.map(c => c.id === country.id ? country : c);
        saveToStorage(STORAGE_KEYS.COUNTRIES, updatedCountries);
        return country;
    },

    async deleteCountry(countryId: number): Promise<void> {
        const db = getFirebaseDb();
        if (db) {
            await fbDelete('countries', countryId);
            return;
        }

        await delay(500);
        const countries = getFromStorage<Country[]>(STORAGE_KEYS.COUNTRIES, initialCountries);
        const filteredCountries = countries.filter(c => c.id !== countryId);
        saveToStorage(STORAGE_KEYS.COUNTRIES, filteredCountries);
    },

    // --- Settings API ---
    async getSettings(): Promise<AppSettings> {
        await delay(500);
        return getFromStorage<AppSettings>(STORAGE_KEYS.SETTINGS, initialSettings);
    },

    async updateSettings(settings: AppSettings): Promise<AppSettings> {
        await delay(500);
        saveToStorage(STORAGE_KEYS.SETTINGS, settings);
        return settings;
    },

    // --- Payments API ---
    async getPayments(): Promise<PaymentTransaction[]> {
        const db = getFirebaseDb();
        if (db) return await fbGetAll<PaymentTransaction>('payments');

        await delay(500);
        return getFromStorage<PaymentTransaction[]>(STORAGE_KEYS.PAYMENTS, initialPayments);
    },

    async addPayment(paymentData: Omit<PaymentTransaction, 'id' | 'date' | 'status'>): Promise<PaymentTransaction> {
        const db = getFirebaseDb();
        if (db) {
            const payments = await fbGetAll<PaymentTransaction>('payments');
            const newId = payments.length > 0 ? Math.max(...payments.map(p => p.id)) + 1 : 1;
            const newPayment: PaymentTransaction = {
                ...paymentData,
                id: newId,
                status: 'pending',
                date: new Date().toLocaleString()
            };
            await fbAdd('payments', newPayment);
            return newPayment;
        }

        await delay(500);
        const payments = getFromStorage<PaymentTransaction[]>(STORAGE_KEYS.PAYMENTS, initialPayments);
        const newId = payments.length > 0 ? Math.max(...payments.map(p => p.id)) + 1 : 1;
        const newPayment: PaymentTransaction = {
            ...paymentData,
            id: newId,
            status: 'pending',
            date: new Date().toLocaleString()
        };
        saveToStorage(STORAGE_KEYS.PAYMENTS, [...payments, newPayment]);
        return newPayment;
    },

    async updatePaymentStatus(id: number, status: 'approved' | 'rejected'): Promise<void> {
        const db = getFirebaseDb();
        let transaction: PaymentTransaction | undefined;

        if (db) {
            const payments = await fbGetAll<PaymentTransaction>('payments');
            transaction = payments.find(p => p.id === id);
            if (transaction) {
                transaction.status = status;
                await fbUpdate('payments', transaction);
            }
        } else {
            await delay(500);
            const payments = getFromStorage<PaymentTransaction[]>(STORAGE_KEYS.PAYMENTS, initialPayments);
            transaction = payments.find(p => p.id === id);
            const updatedPayments = payments.map(p => p.id === id ? { ...p, status } : p);
            saveToStorage(STORAGE_KEYS.PAYMENTS, updatedPayments);
        }

        if (status === 'approved' && transaction && transaction.userId) {
            let user: User | undefined;
            if (db) {
                const users = await fbGetAll<User>('users');
                user = users.find(u => u.id === transaction!.userId);
            } else {
                const users = getFromStorage<User[]>(STORAGE_KEYS.USERS, initialUsers);
                user = users.find(u => u.id === transaction!.userId);
            }
            
            if (user) {
                const now = new Date();
                const endDate = new Date();
                endDate.setDate(now.getDate() + 30);

                const updatedUser: User = {
                    ...user,
                    subscriptionPlan: transaction.planTitle,
                    subscriptionStatus: 'active',
                    subscriptionStartDate: now.toISOString(),
                    subscriptionEndDate: endDate.toISOString()
                };

                if (db) {
                    await fbUpdate('users', updatedUser);
                } else {
                    const users = getFromStorage<User[]>(STORAGE_KEYS.USERS, initialUsers);
                    const updatedUsers = users.map(u => u.id === user!.id ? updatedUser : u);
                    saveToStorage(STORAGE_KEYS.USERS, updatedUsers);
                }
            }
        }
    },

    // --- User Ad Requests API ---
    async getAdRequests(): Promise<UserAdRequest[]> {
        const db = getFirebaseDb();
        if (db) return await fbGetAll<UserAdRequest>('ad_requests');

        await delay(500);
        return getFromStorage<UserAdRequest[]>(STORAGE_KEYS.AD_REQUESTS, initialAdRequests);
    },

    async submitAdRequest(adData: Omit<UserAdRequest, 'id' | 'submittedDate' | 'status'>): Promise<UserAdRequest> {
        const db = getFirebaseDb();
        if (db) {
            const requests = await fbGetAll<UserAdRequest>('ad_requests');
            const newId = requests.length > 0 ? Math.max(...requests.map(r => r.id)) + 1 : 1;
            const newRequest: UserAdRequest = {
                ...adData,
                id: newId,
                status: 'pending',
                submittedDate: new Date().toLocaleString()
            };
            await fbAdd('ad_requests', newRequest);
            return newRequest;
        }

        await delay(500);
        const requests = getFromStorage<UserAdRequest[]>(STORAGE_KEYS.AD_REQUESTS, initialAdRequests);
        const newId = requests.length > 0 ? Math.max(...requests.map(r => r.id)) + 1 : 1;
        const newRequest: UserAdRequest = {
            ...adData,
            id: newId,
            status: 'pending',
            submittedDate: new Date().toLocaleString()
        };
        saveToStorage(STORAGE_KEYS.AD_REQUESTS, [...requests, newRequest]);
        return newRequest;
    },

    async updateAdRequestStatus(id: number, status: 'approved' | 'rejected'): Promise<void> {
        const db = getFirebaseDb();
        let updatedRequestData: Partial<UserAdRequest> = { status };

        if (status === 'approved') {
            const startDate = new Date();
            const endDate = new Date();
            endDate.setDate(startDate.getDate() + 30);
            updatedRequestData = {
                ...updatedRequestData,
                startDate: startDate.toISOString(),
                endDate: endDate.toISOString()
            };
        }

        if (db) {
             const requests = await fbGetAll<UserAdRequest>('ad_requests');
             const req = requests.find(r => r.id === id);
             if (req) {
                 await fbUpdate('ad_requests', { ...req, ...updatedRequestData });
             }
        } else {
            await delay(500);
            const requests = getFromStorage<UserAdRequest[]>(STORAGE_KEYS.AD_REQUESTS, initialAdRequests);
            const updatedRequests = requests.map(r => r.id === id ? { ...r, ...updatedRequestData } : r);
            saveToStorage(STORAGE_KEYS.AD_REQUESTS, updatedRequests);
        }
    },

    async deleteAdRequest(id: number): Promise<void> {
        const db = getFirebaseDb();
        if (db) {
            await fbDelete('ad_requests', id);
            return;
        }

        await delay(500);
        const requests = getFromStorage<UserAdRequest[]>(STORAGE_KEYS.AD_REQUESTS, initialAdRequests);
        const filtered = requests.filter(r => r.id !== id);
        saveToStorage(STORAGE_KEYS.AD_REQUESTS, filtered);
    },

    // --- Notifications API ---
    async getNotifications(): Promise<UserNotification[]> {
        const db = getFirebaseDb();
        if (db) return await fbGetAll<UserNotification>('notifications');

        await delay(500);
        return getFromStorage<UserNotification[]>(STORAGE_KEYS.NOTIFICATIONS, initialNotifications);
    },

    async sendNotification(notification: Omit<UserNotification, 'id' | 'date' | 'isRead'>): Promise<UserNotification> {
        const db = getFirebaseDb();
        const newNotificationData = {
            ...notification,
            isRead: false,
            date: new Date().toLocaleString()
        };

        if (db) {
            const notifications = await fbGetAll<UserNotification>('notifications');
            const newId = notifications.length > 0 ? Math.max(...notifications.map(n => n.id)) + 1 : 1;
            const newNotif = { ...newNotificationData, id: newId };
            await fbAdd('notifications', newNotif);
            return newNotif;
        }

        await delay(500);
        const notifications = getFromStorage<UserNotification[]>(STORAGE_KEYS.NOTIFICATIONS, initialNotifications);
        const newId = notifications.length > 0 ? Math.max(...notifications.map(n => n.id)) + 1 : 1;
        const newNotif = { ...newNotificationData, id: newId };
        saveToStorage(STORAGE_KEYS.NOTIFICATIONS, [...notifications, newNotif]);
        return newNotif;
    },

    async deleteNotification(id: number): Promise<void> {
        const db = getFirebaseDb();
        if (db) {
            await fbDelete('notifications', id);
            return;
        }

        await delay(500);
        const notifications = getFromStorage<UserNotification[]>(STORAGE_KEYS.NOTIFICATIONS, initialNotifications);
        const filtered = notifications.filter(n => n.id !== id);
        saveToStorage(STORAGE_KEYS.NOTIFICATIONS, filtered);
    },

    // --- Comments API ---
    async getJobComments(): Promise<JobComment[]> {
        const db = getFirebaseDb();
        if (db) return await fbGetAll<JobComment>('comments');

        await delay(500);
        return getFromStorage<JobComment[]>(STORAGE_KEYS.COMMENTS, initialComments);
    },

    async addJobComment(comment: Omit<JobComment, 'id' | 'date' | 'status'>): Promise<JobComment> {
        const db = getFirebaseDb();
        const newCommentData = {
            ...comment,
            status: 'pending' as const,
            date: new Date().toLocaleString()
        };

        if (db) {
            const comments = await fbGetAll<JobComment>('comments');
            const newId = comments.length > 0 ? Math.max(...comments.map(c => c.id)) + 1 : 1;
            const newComment = { ...newCommentData, id: newId };
            // @ts-ignore
            await fbAdd('comments', newComment);
            // @ts-ignore
            return newComment;
        }

        await delay(500);
        const comments = getFromStorage<JobComment[]>(STORAGE_KEYS.COMMENTS, initialComments);
        const newId = comments.length > 0 ? Math.max(...comments.map(c => c.id)) + 1 : 1;
        // @ts-ignore
        const newComment: JobComment = { ...newCommentData, id: newId };
        saveToStorage(STORAGE_KEYS.COMMENTS, [...comments, newComment]);
        return newComment;
    },

    async updateJobCommentStatus(id: number, status: 'approved' | 'rejected'): Promise<void> {
        const db = getFirebaseDb();
        if (db) {
             const comments = await fbGetAll<JobComment>('comments');
             const comment = comments.find(c => c.id === id);
             if (comment) {
                 await fbUpdate('comments', { ...comment, status });
             }
        } else {
            await delay(500);
            const comments = getFromStorage<JobComment[]>(STORAGE_KEYS.COMMENTS, initialComments);
            const updatedComments = comments.map(c => c.id === id ? { ...c, status } : c);
            saveToStorage(STORAGE_KEYS.COMMENTS, updatedComments);
        }
    },

    async deleteJobComment(id: number): Promise<void> {
        const db = getFirebaseDb();
        if (db) {
            await fbDelete('comments', id);
            return;
        }

        await delay(500);
        const comments = getFromStorage<JobComment[]>(STORAGE_KEYS.COMMENTS, initialComments);
        const filtered = comments.filter(c => c.id !== id);
        saveToStorage(STORAGE_KEYS.COMMENTS, filtered);
    },

    // --- Chat API ---
    async getChatMessages(): Promise<ChatMessage[]> {
        const db = getFirebaseDb();
        if (db) return await fbGetAll<ChatMessage>('chats');

        await delay(500);
        return getFromStorage<ChatMessage[]>(STORAGE_KEYS.CHATS, initialChats);
    },

    async sendChatMessage(message: Omit<ChatMessage, 'id' | 'timestamp' | 'isRead'>): Promise<ChatMessage> {
        const db = getFirebaseDb();
        const newMessageData = {
            ...message,
            timestamp: new Date().toISOString(),
            isRead: false
        };

        if (db) {
            const chats = await fbGetAll<ChatMessage>('chats');
            const newId = chats.length > 0 ? Math.max(...chats.map(c => c.id)) + 1 : 1;
            const newMessage = { ...newMessageData, id: newId };
            // @ts-ignore
            await fbAdd('chats', newMessage);
            // @ts-ignore
            return newMessage;
        }

        await delay(500);
        const chats = getFromStorage<ChatMessage[]>(STORAGE_KEYS.CHATS, initialChats);
        const newId = chats.length > 0 ? Math.max(...chats.map(c => c.id)) + 1 : 1;
        // @ts-ignore
        const newMessage: ChatMessage = { ...newMessageData, id: newId };
        saveToStorage(STORAGE_KEYS.CHATS, [...chats, newMessage]);
        return newMessage;
    }
};
