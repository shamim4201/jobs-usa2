
export interface Job {
  id: number;
  title: string;
  description: string;
  salary: string;
  imageUrl: string;
  company: string;
  applyUrl: string;
  clicks: number;
  showOnHome?: boolean; // New field to control homepage visibility
}

export type Page = 'home' | 'jobs' | 'invite' | 'settings' | 'register' | 'job-details' | 'ads-plan';

export interface AdCompany {
  id: number;
  name: string;
}

export interface Advertisement {
  id: number;
  title: string;
  imageUrl: string;
  link: string;
  companyId: number;
}

export interface User {
  id: number;
  name: string;
  email: string;
  password?: string; // New: Allow storing password
  role: 'admin' | 'user';
  accountType?: 'job_seeker' | 'employer'; // New Field
  countryId: number;
  joinedDate?: string;
  // Subscription Info (For Employers)
  subscriptionPlan?: string; // e.g., "Premium", "Free"
  subscriptionStatus?: 'active' | 'expired' | 'none';
  subscriptionStartDate?: string; // ISO Date String
  subscriptionEndDate?: string; // ISO Date String
}

export interface Country {
  id: number;
  name: string;
  flag: string;
}

export interface PricingPlan {
  title: string;
  price: string;
  unit: string;
  yearlyPrice?: string; // New: Yearly Price
  yearlyUnit?: string;  // New: Yearly Unit (e.g. /yr)
  features: string[];
  buttonText: string;
  buttonLink: string;
  isPopular?: boolean;
}

export interface FaqItem {
  question: string;
  answer: string;
}

export interface PaymentMethod {
  id: string; // 'bkash', 'nagad', 'rocket', 'bank'
  name: string;
  number: string; // The phone number or account number
  instruction: string; // e.g., "Send Money (Personal)"
  logoBg: string; // Tailwind color class
  isEnabled: boolean;
  currency: 'BDT' | 'USD'; // Added currency field
}

export interface PaymentTransaction {
    id: number;
    userId?: number; // Linked User ID
    userName: string; // Name of the user (or "Guest")
    planTitle: string;
    amount: number;
    currency: 'BDT' | 'USD';
    methodName: string;
    senderNumber: string;
    trxId: string;
    screenshotName?: string;
    screenshotDataUrl?: string; // Base64 string of the image
    status: 'pending' | 'approved' | 'rejected';
    date: string;
}

export interface UserAdRequest {
    id: number;
    userId: number;
    userName: string;
    title: string;
    description?: string;
    targetUrl: string;
    bannerImageName: string;
    bannerImageDataUrl: string; // Base64 image
    status: 'pending' | 'approved' | 'rejected';
    submittedDate: string;
    startDate?: string; // When the ad was approved
    endDate?: string;   // When the ad expires
}

export interface UserNotification {
    id: number;
    userId: number; // 0 means 'All Users' or specific ID
    message: string;
    type: 'info' | 'success' | 'warning' | 'error';
    isRead: boolean;
    date: string;
    link?: string;
}

export interface JobComment {
    id: number;
    jobId: number;
    userId: number;
    userName: string;
    text: string;
    date: string;
    status: 'pending' | 'approved' | 'rejected'; // New status field
}

export interface SupportBotConfig {
    greeting: string;
    askName: string;
    askCountry: string;
    successMsg: string;
    errorName: string;
    errorCountry: string;
}

// New Chat Message Type
export interface ChatMessage {
    id: number;
    userId: number; // The user communicating with admin (0 or negative for guest)
    userName: string;
    text: string;
    sender: 'user' | 'admin';
    timestamp: string;
    isRead: boolean;
}

export interface AppSettings {
  googleAnalyticsId: string;
  siteTitle: string;
  siteLogoUrl?: string;
  inviteReferralUrl?: string; // NEW: Editable Invite Link

  // Firebase Settings (NEW)
  enableFirebase?: boolean;
  firebaseApiKey?: string;
  firebaseAuthDomain?: string;
  firebaseProjectId?: string;
  firebaseStorageBucket?: string;
  firebaseMessagingSenderId?: string;
  firebaseAppId?: string;

  // SEO Settings
  seoTitle?: string;
  seoDescription?: string;
  seoKeywords?: string;
  
  // Plans
  freePlan?: PricingPlan;
  premiumPlan?: PricingPlan;
  billingCycleMonthLabel?: string; // New: Label for 'Month' button
  billingCycleYearLabel?: string;  // New: Label for 'Year' button

  // FAQs
  faqs?: FaqItem[];

  // Support Bot
  supportBot?: SupportBotConfig;

  // Payment Gateway
  paymentMethods?: PaymentMethod[];

  // Home Page Ads
  homeTopAdCode?: string;
  homeBottomAdCode?: string;
  homeMiddleAdCode?: string;
  // Jobs Page Ads
  jobsTopAdCode?: string;
  jobsMiddleAdCode?: string;
  jobsBottomAdCode?: string;
  jobsAdInterval?: number; // How many jobs between ads
  // Invite Page Ads
  inviteTopAdCode?: string;
  inviteBottomAdCode?: string;
  // Login/Account Page Ads
  loginTopAdCode?: string;
  loginBottomAdCode?: string;
}
