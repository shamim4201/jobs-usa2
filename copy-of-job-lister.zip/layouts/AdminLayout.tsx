
import React, { useState } from 'react';
import type { User } from '../types';
import Sidebar from '../components/admin/Sidebar';
import Header from '../components/admin/Header';
import AdminDashboardPage from '../pages/AdminDashboardPage';
import JobManagementPage from '../pages/JobManagementPage';
import UserManagementPage from '../pages/UserManagementPage';
import CountryManagementPage from '../pages/CountryManagementPage';
import PaymentHistoryPage from '../pages/PaymentHistoryPage';
import AdManagementPage from '../pages/AdManagementPage';
import PlanManagementPage from '../pages/PlanManagementPage';
import SettingsPage from '../pages/SettingsPage';
import AdRequestsPage from '../pages/AdRequestsPage'; 
import NotificationManagementPage from '../pages/NotificationManagementPage';
import CommentManagementPage from '../pages/CommentManagementPage'; 
import BotManagementPage from '../pages/BotManagementPage';
import DatabaseManagementPage from '../pages/DatabaseManagementPage'; // New Import
import { useData } from '../context/DataContext';

interface AdminLayoutProps {
  user: User;
  onLogout: () => void;
}

const AdminLayout: React.FC<AdminLayoutProps> = ({ user, onLogout }) => {
    const [currentPage, setCurrentPage] = useState('dashboard');
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);

    // Use Global Data Context
    const { 
        jobs, addJob, updateJob, deleteJob,
        users, addUser, updateUser, deleteUser,
        countries, addCountry, updateCountry, deleteCountry,
        payments, updatePaymentStatus,
        isLoading,
        chats // Get chats from context
    } = useData();

    const renderPage = () => {
        switch (currentPage) {
            case 'dashboard':
                return <AdminDashboardPage 
                            jobs={jobs} 
                            users={users} 
                            countries={countries} 
                            payments={payments} 
                            chats={chats} // Pass chats prop here
                            isLoading={isLoading} 
                            onNavigate={setCurrentPage}
                       />;
            case 'jobs':
                return <JobManagementPage 
                            jobs={jobs} 
                            onSave={(job) => job.id === 0 ? addJob(job) : updateJob(job)} 
                            onDelete={deleteJob} 
                       />;
            case 'users':
                return <UserManagementPage 
                            users={users} 
                            countries={countries}
                            onSave={(u) => u.id === 0 ? addUser(u) : updateUser(u)}
                            onDelete={deleteUser}
                       />;
            case 'countries':
                return <CountryManagementPage
                            countries={countries}
                            onSave={(c) => c.id === 0 ? addCountry(c) : updateCountry(c)}
                            onDelete={deleteCountry}
                        />;
            case 'payments':
                return <PaymentHistoryPage 
                            payments={payments}
                            onUpdateStatus={updatePaymentStatus}
                        />;
            case 'ad-requests':
                return <AdRequestsPage />;
            case 'notifications':
                return <NotificationManagementPage />;
            case 'comments':
                return <CommentManagementPage />;
            case 'bot-chat':
                return <BotManagementPage />;
            case 'ads':
                return <AdManagementPage />;
            case 'plans':
                return <PlanManagementPage />;
            case 'database':
                return <DatabaseManagementPage />;
            case 'settings':
                return <SettingsPage />;
            default:
                return <AdminDashboardPage 
                            jobs={jobs} 
                            users={users} 
                            countries={countries}
                            payments={payments}
                            chats={chats}
                            isLoading={isLoading} 
                            onNavigate={setCurrentPage}
                       />;
        }
    };

    return (
        <div className="flex h-screen bg-gray-50 overflow-hidden font-sans">
            <Sidebar 
                currentPage={currentPage} 
                setCurrentPage={(page) => {
                    setCurrentPage(page);
                    setIsSidebarOpen(false); // Close sidebar on mobile on navigation
                }}
                isSidebarOpen={isSidebarOpen}
            />
            
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header 
                    user={user} 
                    onLogout={onLogout} 
                    onMenuButtonClick={() => setIsSidebarOpen(!isSidebarOpen)}
                />
                
                <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-6">
                    {renderPage()}
                </main>
            </div>

            {/* Overlay for mobile sidebar */}
            {isSidebarOpen && (
                <div 
                    className="fixed inset-0 bg-black opacity-50 z-20 lg:hidden"
                    onClick={() => setIsSidebarOpen(false)}
                ></div>
            )}
        </div>
    );
};

export default AdminLayout;
